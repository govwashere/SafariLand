<?php
/**
 * VISITOR -> CUSTOMER - Log in.
 * Security: CSRF token, prepared statements, password_verify, generic error
 * message, account lock after 5 failed attempts, session id regenerated on
 * success, safe "next" redirect, page not indexed by search engines.
 */
require __DIR__ . '/includes/bootstrap.php';
no_index();

if (is_customer()) {
    redirect('customer/dashboard.php');
}

$errors = [];
$email  = '';
$next   = safe_next($_GET['next'] ?? $_POST['next'] ?? null, 'customer/dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $v = new Validator($_POST);
    $v->required('email', 'Email')->email('email')
      ->required('password', 'Password');
    $email = $v->get('email');

    if (!$v->fails()) {
        [$user, $error] = attempt_login($email, (string)$_POST['password'], 'customer');
        if ($user) {
            login_user($user);
            redirect($next);
        }
        $errors['form'] = $error;
    } else {
        $errors = $v->errors();
    }
}

$pageTitle = 'Log in';
include __DIR__ . '/includes/partials/auth_header.php';
?>
    <h1 class="auth-title">Welcome back</h1>
    <p class="auth-sub">Log in to book tickets and manage your visits.</p>

    <?php if ($m = get_flash('info')): ?><p class="auth-alert info" role="status"><?= e($m) ?></p><?php endif; ?>
    <?php if ($m = get_flash('success')): ?><p class="auth-alert ok" role="status"><?= e($m) ?></p><?php endif; ?>
    <?php if (!empty($errors['form'])): ?><p class="auth-alert error" role="alert"><?= e($errors['form']) ?></p><?php endif; ?>

    <form class="auth-form" method="post" action="login.php" novalidate data-validate>
      <?= csrf_field() ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">

      <div class="auth-field<?= isset($errors['email']) ? ' has-error' : '' ?>">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" required maxlength="150" autocomplete="email" value="<?= e($email) ?>">
        <?php if (isset($errors['email'])): ?><small class="auth-error"><?= e($errors['email']) ?></small><?php endif; ?>
      </div>

      <div class="auth-field<?= isset($errors['password']) ? ' has-error' : '' ?>">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required autocomplete="current-password">
        <?php if (isset($errors['password'])): ?><small class="auth-error"><?= e($errors['password']) ?></small><?php endif; ?>
      </div>

      <button class="green-pill auth-submit" type="submit">Log in</button>
    </form>

    <p class="auth-switch">New to SafariLand? <a href="register.php<?= $next !== 'customer/dashboard.php' ? '?next=' . urlencode($next) : '' ?>">Create an account</a></p>
<?php include __DIR__ . '/includes/partials/auth_footer.php'; ?>
