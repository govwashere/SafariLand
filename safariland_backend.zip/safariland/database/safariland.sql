-- =====================================================================
--  SafariLand Nature Park - database schema + sample data
--  Import in phpMyAdmin (Import tab) or:  mysql -u root -p < safariland.sql
-- =====================================================================

DROP DATABASE IF EXISTS safariland;
CREATE DATABASE safariland CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE safariland;

-- ---------------------------------------------------------------------
-- USERS: one table, two user groups (role = customer | admin).
-- Passwords are stored as password_hash() (bcrypt) - never plain text.
-- failed_logins / locked_until give brute-force protection on login.
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name      VARCHAR(100) NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  phone          VARCHAR(20)  NULL,
  dob            DATE         NULL,
  address        VARCHAR(200) NULL,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  status         ENUM('Active','Blocked') NOT NULL DEFAULT 'Active',
  profile_photo  VARCHAR(255) NULL,
  failed_logins  TINYINT UNSIGNED NOT NULL DEFAULT 0,
  locked_until   DATETIME NULL,
  last_login_at  DATETIME NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ATTRACTIONS (managed by admin, displayed to visitors)
-- ---------------------------------------------------------------------
CREATE TABLE attractions (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100) NOT NULL,
  category     ENUM('Adventure','Animal') NOT NULL,
  price        DECIMAL(10,2) NOT NULL DEFAULT 0,
  min_age      TINYINT UNSIGNED NOT NULL DEFAULT 0,
  min_height   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  duration     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  status       ENUM('Open','Closed') NOT NULL DEFAULT 'Open',
  description  TEXT NULL,
  image        VARCHAR(255) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TICKET TYPES (General / Family / VIP ...)
-- ---------------------------------------------------------------------
CREATE TABLE ticket_types (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(60) NOT NULL UNIQUE,
  price        DECIMAL(10,2) NOT NULL,
  guests       TINYINT UNSIGNED NOT NULL DEFAULT 1,
  description  TEXT NOT NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- EVENTS (Halloween, New Year ...)
-- ---------------------------------------------------------------------
CREATE TABLE events (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(120) NOT NULL,
  tagline      VARCHAR(160) NULL,
  description  TEXT NULL,
  event_date   DATE NOT NULL,
  location     VARCHAR(120) NOT NULL DEFAULT 'SafariLand',
  status       ENUM('Published','Draft') NOT NULL DEFAULT 'Published',
  image        VARCHAR(255) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- BOOKINGS -> BOOKING_ITEMS -> TICKETS
-- Card details are NEVER stored: only the holder name and last 4 digits.
-- booking_items keep a snapshot of name + price so history stays correct
-- even if the admin later edits or deletes the ticket type.
-- ---------------------------------------------------------------------
CREATE TABLE bookings (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference    VARCHAR(20) NULL UNIQUE,
  user_id      INT UNSIGNED NOT NULL,
  visit_date   DATE NOT NULL,
  subtotal     DECIMAL(10,2) NOT NULL,
  service_fee  DECIMAL(10,2) NOT NULL,
  total        DECIMAL(10,2) NOT NULL,
  status       ENUM('Paid','Cancelled','Refunded') NOT NULL DEFAULT 'Paid',
  card_holder  VARCHAR(100) NOT NULL,
  card_last4   CHAR(4) NOT NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE booking_items (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_id      INT UNSIGNED NOT NULL,
  ticket_type_id  INT UNSIGNED NULL,
  ticket_name     VARCHAR(60) NOT NULL,
  unit_price      DECIMAL(10,2) NOT NULL,
  quantity        TINYINT UNSIGNED NOT NULL,
  line_total      DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_item_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT fk_item_type    FOREIGN KEY (ticket_type_id) REFERENCES ticket_types(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE tickets (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_item_id  INT UNSIGNED NOT NULL,
  ticket_code      CHAR(12) NOT NULL UNIQUE,
  CONSTRAINT fk_ticket_item FOREIGN KEY (booking_item_id) REFERENCES booking_items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- REVIEWS written by customers ("My review"), moderated by admin
-- ---------------------------------------------------------------------
CREATE TABLE reviews (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  rating      TINYINT UNSIGNED NOT NULL,
  title       VARCHAR(100) NOT NULL,
  comment     TEXT NOT NULL,
  status      ENUM('Visible','Hidden') NOT NULL DEFAULT 'Visible',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_review_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- MESSAGES sent by visitors through the Contact form
-- ---------------------------------------------------------------------
CREATE TABLE messages (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL,
  subject     VARCHAR(120) NOT NULL,
  message     TEXT NOT NULL,
  is_read     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- SETTINGS (key/value) - park status, closing time, service fee ...
-- ---------------------------------------------------------------------
CREATE TABLE settings (
  setting_key    VARCHAR(50) PRIMARY KEY,
  setting_value  VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- =====================================================================
--  SAMPLE DATA
--  Admin login:     admin@safariland.mu / Admin@123
--  Customer login:  jp@gmail.com        / Customer@123
-- =====================================================================

INSERT INTO users (full_name, email, phone, dob, address, password_hash, role, status) VALUES
('SafariLand Admin', 'admin@safariland.mu', '+230 5000 0000', NULL, NULL,
 '$2y$10$9qo76xD0ea55gV0bMJ2GmejSiXtPafL2212Nc3A2VKtruMg1l9EtC', 'admin', 'Active'),
('John Pierre', 'jp@gmail.com', '+230 5712 3456', '1995-08-14', '24 Royal Road, Rose Hill',
 '$2y$10$EM8hICRMOO2FlLiguoFs3.rUxo7V7iqg8WhjLw9aTa5WFT.7pfjfO', 'customer', 'Active'),
('Sarah Khan', 'sk@gmail.com', '+230 5321 6500', NULL, NULL,
 '$2y$10$EM8hICRMOO2FlLiguoFs3.rUxo7V7iqg8WhjLw9aTa5WFT.7pfjfO', 'customer', 'Active'),
('Maria Fernando', 'mf@gmail.com', '+230 5689 7000', NULL, NULL,
 '$2y$10$EM8hICRMOO2FlLiguoFs3.rUxo7V7iqg8WhjLw9aTa5WFT.7pfjfO', 'customer', 'Blocked');

INSERT INTO attractions (name, category, price, min_age, min_height, duration, status, description, image) VALUES
('Karting', 'Adventure', 450, 8, 120, 15, 'Open', 'Take the wheel and enjoy a fast-paced karting experience on our downhill track.', 'uploads/attractions/karting.png'),
('Bird Aviaries', 'Animal', 300, 0, 0, 30, 'Open', 'Meet colourful birds and discover the walk-in aviaries, with daily feeding sessions.', 'uploads/attractions/bird_avaries.png'),
('Nepalese Bridge', 'Adventure', 450, 8, 120, 20, 'Open', 'Cross the suspended bridge high above the valley.', 'uploads/attractions/nepalese_bridge.png'),
('Ziplining', 'Adventure', 300, 10, 130, 30, 'Open', 'Experience the ultimate rush with a scenic zipline ride over the green slopes.', 'uploads/attractions/ziplining.png');

INSERT INTO ticket_types (name, price, guests, description) VALUES
('General Pass', 400, 1, 'Access 1 person\nWildlife viewing\nKids Park\n1 bird aviary'),
('Family Pass', 2250, 4, 'General pass activities\nPark Access 4 persons\nBig cat Drive Thru'),
('VIP Pass', 1800, 1, 'VIP Access 1 person\nFeed baby Crocodile\nNepalese Bridge\n2 Ziplines\nWalk with Lion');

INSERT INTO events (title, tagline, description, event_date, location, status, image) VALUES
('Halloween at SafariLand', 'A wildly spooky adventure awaits!',
 'Experience the magic of Halloween surrounded by nature. Enjoy festive decorations, exciting activities and unforgettable moments with family and friends.',
 '2026-10-31', 'SafariLand', 'Published', 'uploads/events/halloween-event.png'),
('New Year Eve at SafariLand', 'Ring in 2027 under the stars',
 'Celebrate the New Year with music, food stalls and fireworks over the river.',
 '2026-12-31', 'SafariLand', 'Published', 'uploads/events/event-newyear.png');

INSERT INTO settings (setting_key, setting_value) VALUES
('park_status', 'Open'),
('closing_time', '20:00'),
('service_fee', '100'),
('contact_email', 'hello@safariland.example');

-- Sample bookings for John Pierre (user 2) and Sarah Khan (user 3)
INSERT INTO bookings (reference, user_id, visit_date, subtotal, service_fee, total, status, card_holder, card_last4, created_at) VALUES
('SL-2026-00001', 2, '2026-11-15', 1800, 100, 1900, 'Paid', 'John Pierre', '4242', '2026-10-15 10:12:00'),
('SL-2026-00002', 2, '2026-10-20', 400, 100, 500, 'Paid', 'John Pierre', '4242', '2026-10-15 10:30:00'),
('SL-2026-00003', 3, '2026-11-02', 800, 100, 900, 'Paid', 'Sarah Khan', '1881', '2026-10-14 16:05:00');

INSERT INTO booking_items (booking_id, ticket_type_id, ticket_name, unit_price, quantity, line_total) VALUES
(1, 3, 'VIP Pass', 1800, 1, 1800),
(2, 1, 'General Pass', 400, 1, 400),
(3, 1, 'General Pass', 400, 2, 800);

INSERT INTO tickets (booking_item_id, ticket_code) VALUES
(1, 'VIP7K2M9QX4A'),
(2, 'GEN3H8D2LP6Z'),
(3, 'GEN9T4W7RB2C'),
(3, 'GEN5N1V8YK3E');

INSERT INTO reviews (user_id, rating, title, comment, status) VALUES
(2, 5, 'Amazing day out', 'The zipline was incredible and the kids loved the bird aviaries. We will be back!', 'Visible'),
(3, 4, 'Lovely park', 'Beautiful waterfall and friendly staff. Karting queue was a bit long.', 'Visible');

INSERT INTO messages (name, email, subject, message) VALUES
('Priya Ramgoolam', 'priya@example.com', 'Group booking', 'Hello, do you offer discounts for a school group of 30 children?');
