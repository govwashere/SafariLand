<?php
/**
 * VISITOR - Home page.
 * Public page (indexable). Park status, closing time, "tickets from" price,
 * featured activities, upcoming events and reviews all come from the database.
 */
require __DIR__ . '/includes/bootstrap.php';

$parkOpen    = setting('park_status', 'Open') === 'Open';
$closingTime = date('g a', strtotime(setting('closing_time', '20:00')));
$fromPrice   = db()->query('SELECT MIN(price) FROM ticket_types')->fetchColumn();

// Featured activities on the home page (looked up by name so the links go to the right detail page)
$featured = db()->query("SELECT id, name, description, image FROM attractions
                         WHERE status = 'Open' AND name IN ('Ziplining', 'Karting')
                         ORDER BY FIELD(name, 'Ziplining', 'Karting')")->fetchAll();

// Upcoming, published events (today or later)
$events = db()->query("SELECT * FROM events WHERE status = 'Published' AND event_date >= CURDATE()
                       ORDER BY event_date LIMIT 3")->fetchAll();

// Latest visible reviews
$reviews = db()->query("SELECT r.rating, r.title, r.comment, u.full_name
                        FROM reviews r JOIN users u ON u.id = r.user_id
                        WHERE r.status = 'Visible' ORDER BY r.created_at DESC LIMIT 3")->fetchAll();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Discover wildlife, nature and adventure at SafariLand.">
  <title>SafariLand | Nature Park</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bayon&family=Baskervville+SC&family=Irish+Grover&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
</head>
<body class="home-page">
  <section class="home-hero" aria-labelledby="welcome-title">
    <header class="home-header">
      <a class="home-logo" href="index.php" aria-label="SafariLand home">
        <img src="images/safariland-logo.png" alt="SafariLand Nature Park">
      </a>
      <button class="menu-toggle" aria-expanded="false" aria-controls="main-nav">Menu</button>
      <nav id="main-nav" class="home-nav" aria-label="Main navigation">
        <a href="index.php">Home</a>
        <a href="#park-info">Plan Your Visit</a>
        <a href="attractions.php">Attractions</a>
        <a href="park.php">The Park</a>
        <?php include __DIR__ . '/includes/partials/visitor_account_link.php'; ?>
        <a class="login-pill" href="customer/park-tickets.php">Buy Ticket</a>
      </nav>
    </header>

    <div class="welcome-panel">
      <h1 id="welcome-title">Welcome to<br><span>SafariLand</span></h1>
      <p>Set by the river and surrounded by mountains, SafariLand is the<br class="desktop-break"> perfect place for family adventures.</p>
      <a class="home-pill" href="customer/park-tickets.php">Buy Ticket</a>
    </div>

    <div class="hero-info-bar">
      <div class="park-status">
        <span class="open-indicator<?= $parkOpen ? '' : ' is-closed' ?>" aria-hidden="true"></span>
        <p><strong>Park status: <?= $parkOpen ? 'Open' : 'Closed' ?></strong><br>Close: <?= e($closingTime) ?></p>
      </div>
      <a class="ticket-from" href="customer/park-tickets.php">
        Tickets as from<br><strong><?= money($fromPrice ?: 0) ?></strong>
      </a>
    </div>
  </section>

  <main>
    <section class="home-about" id="park-info">
      <div class="about-copy">
        <h2>More than a Park.</h2>
        <h3>A Wild Adventure Awaits</h3>
        <p>SafariLand brings together wildlife, adventure and nature in one unforgettable destination. Explore scenic trails, discover a stunning waterfall, and encounter incredible animals including lions, giraffes, elephants, monkeys, birds, and more.</p>
        <p class="about-tags">Nature Trails · Waterfall · Kids Park · Wildlife Encounters</p>
        <a class="green-pill" href="park.php">Read Our Story</a>
      </div>
      <div class="about-collage" aria-label="SafariLand nature and adventure">
        <img class="collage-waterfall" src="images/waterfall.png" alt="Waterfall surrounded by forest">
        <img class="collage-zipline" src="images/zipline-mountain.png" alt="Visitor ziplining above a mountain valley">
        <img class="collage-giraffes" src="images/giraffes.png" alt="Two giraffes at SafariLand">
      </div>
    </section>

    <section class="activities-feature">
      <div class="activities-heading">
        <h2>Fun For Everyone!</h2>
        <p>Looking For some Thrills?</p>
      </div>
      <div class="activity-pair">
        <?php foreach ($featured as $a): ?>
        <article class="activity-preview">
          <img src="<?= e($a['name'] === 'Ziplining' ? 'images/zipline-activity.png' : upload_url($a['image'])) ?>" alt="<?= e($a['name']) ?> at SafariLand">
          <div>
            <p><?= e($a['description']) ?></p>
            <a class="green-pill" href="attraction.php?id=<?= (int)$a['id'] ?>">More Details</a>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <a class="other-activities" href="attractions.php">Other Activities</a>
    </section>

    <section class="species-feature" id="animals">
      <h2>Our Remarkable Species <span>- Get closer to wildlife</span></h2>
      <div class="species-banner crocodile-banner">
        <img src="images/lucy-crocodile.png" alt="Lucy the crocodile in the water">
        <strong>Lucy The Crocodile</strong>
      </div>
      <div class="species-banner tortoise-banner">
        <img src="images/tortoise.png" alt="A tortoise at SafariLand">
        <strong>Animal Encounters</strong>
      </div>
      <a class="green-pill species-link" href="attractions.php?category=animals">Animal Encounters</a>
    </section>

    <section class="upcoming-section" id="events">
      <h2>Upcoming Events</h2>
      <?php if (!$events): ?>
        <p class="empty-note">No upcoming events right now - check back soon!</p>
      <?php endif; ?>
      <?php foreach ($events as $ev): ?>
      <article class="home-event">
        <img src="<?= e(upload_url($ev['image']) ?: 'images/halloween-event.png') ?>" alt="<?= e($ev['title']) ?>">
        <div class="event-copy">
          <p class="event-kicker">Special Event</p>
          <h3><?= e($ev['title']) ?></h3>
          <?php if ($ev['tagline']): ?><h4><?= e($ev['tagline']) ?></h4><?php endif; ?>
          <p><?= nl2br(e($ev['description'])) ?></p>
          <p>Event Date: <?= nice_date($ev['event_date'], 'd/m/y') ?><br>Location: <?= e($ev['location']) ?></p>
        </div>
      </article>
      <?php endforeach; ?>
    </section>

    <?php if ($reviews): ?>
    <section class="reviews-section" aria-labelledby="reviews-title">
      <h2 id="reviews-title">What Our Visitors Say</h2>
      <div class="review-grid">
        <?php foreach ($reviews as $r): ?>
        <figure class="review-card">
          <p class="review-stars" aria-label="<?= (int)$r['rating'] ?> out of 5 stars"><?= str_repeat('★', (int)$r['rating']) . str_repeat('☆', 5 - (int)$r['rating']) ?></p>
          <blockquote>
            <strong><?= e($r['title']) ?></strong>
            <p><?= e($r['comment']) ?></p>
          </blockquote>
          <figcaption>- <?= e($r['full_name']) ?></figcaption>
        </figure>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <?php $contactTag = 'section'; $contactClass = ''; include __DIR__ . '/includes/partials/visitor_contact.php'; ?>
  </main>

  <footer class="home-footer">
    <span>© <span data-year></span> SafariLand Nature Park</span>
  </footer>
</body>
</html>
