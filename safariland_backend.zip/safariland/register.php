<?php
/**
 * VISITOR -> CUSTOMER - Create an account (CREATE in users table).
 * Every new account gets role = 'customer' on the server; a visitor can
 * never make themselves an admin, whatever they post.
 */
require __DIR__ . '/includes/bootstrap.php';
no_index();

if (is_customer()) {
    redirect('customer/dashboard.php');
}

$errors = [];
$old    = ['full_name' => '', 'email' => '', 'phone' => ''];
$next   = safe_next($_GET['next'] ?? $_POST['next'] ?? null, 'customer/dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $v = new Validator($_POST);
    $v->required('full_name', 'Full name')->name('full_name')
      ->required('email', 'Email')->email('email')
      ->unique('email', 'users', 'email', null, 'An account with this email already exists.')
      ->required('phone', 'Phone number')->phone('phone')
      ->required('password', 'Password')->strongPassword('password')
      ->required('confirm_password', 'Confirm password')
      ->matches('confirm_password', 'password', 'Passwords do not match.');
    if (empty($_POST['terms'])) {
        $v->addError('terms', 'You must accept the park rules and privacy policy.');
    }
    foreach ($old as $k => $_) {
        $old[$k] = $v->get($k);
    }

    if (!$v->fails()) {
        $stmt = db()->prepare("INSERT INTO users (full_name, email, phone, password_hash, role, status)
                               VALUES (?, ?, ?, ?, 'customer', 'Active')");
        $stmt->execute([$old['full_name'], $old['email'], $old['phone'], password_hash($_POST['password'], PASSWORD_DEFAULT)]);

        $user = ['id' => db()->lastInsertId(), 'role' => 'customer'];
        login_user($user);
        flash('success', 'Welcome to SafariLand, ' . $old['full_name'] . '! Your account has been created.');
        redirect($next);
    }
    $errors = $v->errors();
}

/** Small helper to print one field with its server-side error. */
function field(string $name, string $label, string $type, array $attrs, array $errors, string $value = ''): void
{
    $attrStr = '';
    foreach ($attrs as $k => $val) {
        $attrStr .= $val === true ? " $k" : " $k=\"" . e($val) . '"';
    }
    echo '<div class="auth-field' . (isset($errors[$name]) ? ' has-error' : '') . '">';
    echo '<label for="' . $name . '">' . e($label) . '</label>';
    echo '<input id="' . $name . '" name="' . $name . '" type="' . $type . '" value="' . e($value) . '"' . $attrStr . '>';
    if (isset($errors[$name])) {
        echo '<small class="auth-error">' . e($errors[$name]) . '</small>';
    }
    echo '</div>';
}

$pageTitle = 'Create account';
include __DIR__ . '/includes/partials/auth_header.php';
?>
    <h1 class="auth-title">Create your account</h1>
    <p class="auth-sub">Book park tickets online and keep all your visits in one place.</p>

    <form class="auth-form" method="post" action="register.php" novalidate data-validate>
      <?= csrf_field() ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">
      <?php
      field('full_name', 'Full name', 'text', ['required' => true, 'maxlength' => 100, 'minlength' => 2,
            'pattern' => "[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .'\\-]{1,99}", 'autocomplete' => 'name',
            'title' => 'Letters, spaces, apostrophes or hyphens'], $errors, $old['full_name']);
      field('email', 'Email', 'email', ['required' => true, 'maxlength' => 150, 'autocomplete' => 'email'], $errors, $old['email']);
      field('phone', 'Phone number', 'tel', ['required' => true, 'pattern' => '\+?[0-9 ]{7,20}', 'autocomplete' => 'tel',
            'placeholder' => '+230 5712 3456', 'title' => 'Digits and spaces, optional + at the start'], $errors, $old['phone']);
      field('password', 'Password', 'password', ['required' => true, 'minlength' => 8, 'maxlength' => 72, 'autocomplete' => 'new-password',
            'pattern' => '(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,72}', 'title' => 'At least 8 characters with upper-case, lower-case and a number'], $errors);
      field('confirm_password', 'Confirm password', 'password', ['required' => true, 'autocomplete' => 'new-password', 'data-match' => 'password'], $errors);
      ?>
      <p class="auth-hint">At least 8 characters, with an upper-case letter, a lower-case letter and a number.</p>

      <div class="auth-check<?= isset($errors['terms']) ? ' has-error' : '' ?>">
        <input id="terms" name="terms" type="checkbox" value="1" required>
        <label for="terms">I accept the park rules and privacy policy.</label>
        <?php if (isset($errors['terms'])): ?><small class="auth-error"><?= e($errors['terms']) ?></small><?php endif; ?>
      </div>

      <button class="green-pill auth-submit" type="submit">Create account</button>
    </form>

    <p class="auth-switch">Already have an account? <a href="login.php">Log in</a></p>
<?php include __DIR__ . '/includes/partials/auth_footer.php'; ?>
