<?php
/**
 * SafariLand - server-side validation.
 *
 * Client-side (HTML5 / jQuery) checks are only for user comfort: anyone can
 * switch off JavaScript or send a request with Postman/curl. EVERYTHING is
 * validated again here before it reaches the database.
 *
 * Usage:
 *   $v = new Validator($_POST);
 *   $v->required('email', 'Email')->email('email');
 *   if ($v->fails()) { $errors = $v->errors(); }
 *   $clean = $v->get('email');   // trimmed value
 */
class Validator
{
    public const NAME_PATTERN  = "/^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .'\-]{1,99}$/u";
    public const PHONE_PATTERN = '/^\+?[0-9 ]{7,20}$/';

    private array $data;
    private array $errors = [];

    public function __construct(array $data)
    {
        // Trim every string field once, so "  John " becomes "John"
        $this->data = array_map(fn($v) => is_string($v) ? trim($v) : $v, $data);
    }

    public function get(string $field, $default = '')
    {
        $v = $this->data[$field] ?? $default;
        return is_string($v) || is_numeric($v) ? $v : $default;
    }

    public function errors(): array { return $this->errors; }
    public function fails(): bool   { return !empty($this->errors); }
    public function addError(string $field, string $msg): self
    {
        $this->errors[$field] ??= $msg;   // keep the first error per field
        return $this;
    }

    private function has(string $field): bool
    {
        return $this->get($field) !== '' && !isset($this->errors[$field]);
    }

    /* ---------------- rules ---------------- */

    public function required(string $field, string $label): self
    {
        if ($this->get($field) === '') {
            $this->addError($field, "$label is required.");
        }
        return $this;
    }

    public function maxLength(string $field, int $max, string $label): self
    {
        if ($this->has($field) && mb_strlen($this->get($field)) > $max) {
            $this->addError($field, "$label must be at most $max characters.");
        }
        return $this;
    }

    public function minLength(string $field, int $min, string $label): self
    {
        if ($this->has($field) && mb_strlen($this->get($field)) < $min) {
            $this->addError($field, "$label must be at least $min characters.");
        }
        return $this;
    }

    public function name(string $field): self
    {
        if ($this->has($field) && !preg_match(self::NAME_PATTERN, $this->get($field))) {
            $this->addError($field, 'Use letters, spaces, apostrophes or hyphens only (2-100 characters).');
        }
        return $this;
    }

    public function email(string $field): self
    {
        if ($this->has($field) && (!filter_var($this->get($field), FILTER_VALIDATE_EMAIL) || mb_strlen($this->get($field)) > 150)) {
            $this->addError($field, 'Enter a valid email address.');
        }
        return $this;
    }

    public function phone(string $field): self
    {
        if ($this->has($field) && !preg_match(self::PHONE_PATTERN, $this->get($field))) {
            $this->addError($field, 'Enter a valid phone number (digits, spaces and an optional +).');
        }
        return $this;
    }

    /** At least 8 chars with an upper-case letter, a lower-case letter and a digit. */
    public function strongPassword(string $field): self
    {
        $p = (string)($this->data[$field] ?? '');   // passwords are NOT trimmed
        if ($p !== '' && (strlen($p) < 8 || strlen($p) > 72 || !preg_match('/[A-Z]/', $p) || !preg_match('/[a-z]/', $p) || !preg_match('/\d/', $p))) {
            $this->addError($field, 'Password must be 8-72 characters with an upper-case letter, a lower-case letter and a number.');
        }
        return $this;
    }

    public function matches(string $field, string $other, string $msg): self
    {
        if (($this->data[$field] ?? '') !== ($this->data[$other] ?? '')) {
            $this->addError($field, $msg);
        }
        return $this;
    }

    public function integer(string $field, int $min, int $max, string $label): self
    {
        if ($this->has($field)) {
            $ok = filter_var($this->get($field), FILTER_VALIDATE_INT, ['options' => ['min_range' => $min, 'max_range' => $max]]);
            if ($ok === false) {
                $this->addError($field, "$label must be a whole number between $min and $max.");
            }
        }
        return $this;
    }

    public function decimal(string $field, float $min, float $max, string $label): self
    {
        if ($this->has($field)) {
            $val = $this->get($field);
            if (!is_numeric($val) || !preg_match('/^\d+(\.\d{1,2})?$/', (string)$val) || $val < $min || $val > $max) {
                $this->addError($field, "$label must be a number between $min and $max (max 2 decimals).");
            }
        }
        return $this;
    }

    /** Value must be one of a fixed list (stops tampered <select> values). */
    public function in(string $field, array $allowed, string $label): self
    {
        if ($this->has($field) && !in_array($this->get($field), $allowed, true)) {
            $this->addError($field, "Choose a valid $label.");
        }
        return $this;
    }

    /** Y-m-d date, optionally within [min, max]. */
    public function date(string $field, ?string $min = null, ?string $max = null, string $label = 'Date'): self
    {
        if (!$this->has($field)) return $this;
        $d = DateTime::createFromFormat('!Y-m-d', $this->get($field));
        if (!$d || $d->format('Y-m-d') !== $this->get($field)) {
            return $this->addError($field, "$label must be a valid date.");
        }
        if ($min && $this->get($field) < $min) {
            $this->addError($field, "$label cannot be before " . date('j M Y', strtotime($min)) . '.');
        } elseif ($max && $this->get($field) > $max) {
            $this->addError($field, "$label cannot be after " . date('j M Y', strtotime($max)) . '.');
        }
        return $this;
    }

    public function time(string $field, string $label): self
    {
        if ($this->has($field) && !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $this->get($field))) {
            $this->addError($field, "$label must be a valid time (HH:MM).");
        }
        return $this;
    }

    /** Unique value in a DB table (e.g. email), ignoring the row being edited. */
    public function unique(string $field, string $table, string $column, ?int $ignoreId, string $msg): self
    {
        if (!$this->has($field)) return $this;
        // $table/$column are hard-coded by the developer, never user input
        $sql  = "SELECT COUNT(*) FROM `$table` WHERE `$column` = ?" . ($ignoreId ? ' AND id <> ?' : '');
        $stmt = db()->prepare($sql);
        $stmt->execute($ignoreId ? [$this->get($field), $ignoreId] : [$this->get($field)]);
        if ($stmt->fetchColumn() > 0) {
            $this->addError($field, $msg);
        }
        return $this;
    }

    /* ---------------- payment card rules ---------------- */

    /** 16-digit card number that passes the Luhn checksum. */
    public function cardNumber(string $field): self
    {
        if (!$this->has($field)) return $this;
        $digits = preg_replace('/\s+/', '', $this->get($field));
        if (!preg_match('/^\d{16}$/', $digits)) {
            return $this->addError($field, 'Card number must be 16 digits.');
        }
        if (!self::luhn($digits)) {
            $this->addError($field, 'This card number is not valid.');
        }
        return $this;
    }

    public static function luhn(string $digits): bool
    {
        $sum = 0;
        $alt = false;
        for ($i = strlen($digits) - 1; $i >= 0; $i--) {
            $n = (int)$digits[$i];
            if ($alt) { $n *= 2; if ($n > 9) $n -= 9; }
            $sum += $n;
            $alt = !$alt;
        }
        return $sum % 10 === 0;
    }

    public function cardExpiry(string $field): self
    {
        if (!$this->has($field)) return $this;
        if (!preg_match('/^(0[1-9]|1[0-2])\/(\d{2})$/', $this->get($field), $m)) {
            return $this->addError($field, 'Use the format MM/YY.');
        }
        $lastDay = date('Y-m-t', strtotime('20' . $m[2] . '-' . $m[1] . '-01'));
        if ($lastDay < date('Y-m-d')) {
            $this->addError($field, 'This card has expired.');
        }
        return $this;
    }

    public function cvv(string $field): self
    {
        if ($this->has($field) && !preg_match('/^\d{3,4}$/', $this->get($field))) {
            $this->addError($field, 'CVV must be 3 or 4 digits.');
        }
        return $this;
    }
}
