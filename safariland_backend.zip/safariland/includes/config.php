<?php
/**
 * SafariLand - configuration.
 * Change these values to match your XAMPP / WAMP / server setup.
 */

define('DB_HOST', getenv('SAFARI_DB_HOST') ?: '127.0.0.1');
define('DB_NAME', 'safariland');
define('DB_USER', getenv('SAFARI_DB_USER') ?: 'root');   // XAMPP default user
define('DB_PASS', getenv('SAFARI_DB_PASS') ?: '');       // XAMPP default has no password

// Set to false on a live server so PHP errors are logged, not shown to users.
define('APP_DEBUG', true);

// Session lifetime: log the user out after 30 minutes of inactivity.
define('SESSION_IDLE_SECONDS', 30 * 60);

// Brute-force protection: lock an account for 15 minutes after 5 bad passwords.
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_MINUTES', 15);

// Uploads
define('UPLOAD_MAX_BYTES', 2 * 1024 * 1024);   // 2 MB
define('UPLOAD_DIR', dirname(__DIR__) . '/uploads');

// Booking rules
define('MAX_TICKETS_PER_TYPE', 10);
define('MAX_DAYS_AHEAD', 365);
