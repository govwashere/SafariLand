<?php
/**
 * Loaded at the top of every admin PAGE: bootstrap + layout + admins only.
 */
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/partials/admin_layout.php';

$admin = require_admin();   // redirects to admin/login.php (or 403 for customers)
