<?php
/**
 * ADMIN - turn a database row into the data-* values used by the tables.
 * Used by the pages (first render) AND the API (after add/edit), so the
 * row looks exactly the same either way.
 */

function attraction_row(array $a): array
{
    return [
        'id' => $a['id'], 'name' => $a['name'], 'category' => $a['category'],
        'price' => (float)$a['price'] == (int)$a['price'] ? (int)$a['price'] : $a['price'],
        'minage' => $a['min_age'], 'minheight' => $a['min_height'], 'duration' => $a['duration'],
        'status' => $a['status'], 'description' => (string)$a['description'],
        'image' => $a['image'] ? '../' . $a['image'] : '',
    ];
}

function ticket_row(array $t): array
{
    return [
        'id' => $t['id'], 'name' => $t['name'],
        'price' => (float)$t['price'] == (int)$t['price'] ? (int)$t['price'] : $t['price'],
        'guests' => $t['guests'], 'description' => $t['description'],
    ];
}

function event_row(array $ev): array
{
    return [
        'id' => $ev['id'], 'title' => $ev['title'], 'tagline' => (string)$ev['tagline'],
        'eventdate' => $ev['event_date'], 'datelabel' => date('d/m/y', strtotime($ev['event_date'])),
        'location' => $ev['location'], 'status' => $ev['status'],
        'description' => (string)$ev['description'], 'image' => $ev['image'] ? '../' . $ev['image'] : '',
    ];
}

/** Customer row = user + purchase count + last purchase date (from bookings). */
function customer_row(array $c): array
{
    return [
        'id' => $c['id'], 'name' => $c['full_name'], 'email' => $c['email'], 'contact' => (string)$c['phone'],
        'purchases' => (int)($c['purchases'] ?? 0), 'status' => $c['status'],
        'last' => (string)($c['last_purchase'] ?? ''), 'order' => $c['id'],
    ];
}

function customer_query(string $where = '1=1'): string
{
    return "SELECT u.*, COUNT(b.id) AS purchases, MAX(DATE(b.created_at)) AS last_purchase
            FROM users u LEFT JOIN bookings b ON b.user_id = u.id AND b.status = 'Paid'
            WHERE u.role = 'customer' AND $where
            GROUP BY u.id ORDER BY u.id";
}

function booking_row(array $b): array
{
    return [
        'id' => $b['id'], 'reference' => $b['reference'], 'customer' => $b['full_name'], 'email' => $b['email'],
        'visitdate' => $b['visit_date'], 'visitlabel' => date('d/m/y', strtotime($b['visit_date'])),
        'items' => (string)$b['items'], 'total' => number_format((float)$b['total'], 0, '.', ','),
        'status' => $b['status'], 'created' => date('d/m/y', strtotime($b['created_at'])),
    ];
}

function booking_query(string $where = '1=1'): string
{
    return "SELECT b.*, u.full_name, u.email,
                   GROUP_CONCAT(CONCAT(i.ticket_name, ' x', i.quantity) ORDER BY i.id SEPARATOR ', ') AS items
            FROM bookings b
            JOIN users u ON u.id = b.user_id
            LEFT JOIN booking_items i ON i.booking_id = b.id
            WHERE $where
            GROUP BY b.id ORDER BY b.created_at DESC";
}

function review_row(array $r): array
{
    return [
        'id' => $r['id'], 'customer' => $r['full_name'], 'rating' => $r['rating'], 'title' => $r['title'],
        'comment' => $r['comment'], 'status' => $r['status'], 'date' => date('d/m/y', strtotime($r['created_at'])),
    ];
}

/** Print data-* attributes for a row array. */
function data_attrs(array $row): string
{
    $out = '';
    foreach ($row as $k => $v) {
        $out .= ' data-' . $k . '="' . e($v) . '"';
    }
    return $out;
}
