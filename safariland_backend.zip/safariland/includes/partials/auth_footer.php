    </section>
  </main>
  <?php $contactTag = 'footer'; $contactClass = 'attractions-contact'; include __DIR__ . '/visitor_contact.php'; ?>
</body>
</html>
