<?php
/**
 * CUSTOMER area - shared layout pieces (head, top bar, sidebar, checkout header).
 * Each customer page calls these so the HTML from the designs is written once.
 */

const AVATAR_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4.2"/><path d="M3.5 22c0-4.7 3.8-8 8.5-8s8.5 3.3 8.5 8z"/></svg>';

function customer_head(string $title): void
{
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="robots" content="noindex, nofollow, noarchive" />
  <title>SafariLand – <?= e($title) ?></title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
<?php
}

/** Avatar circle: uploaded photo if any, otherwise the blank person icon. */
function customer_avatar(array $user, string $class = 'avatar', string $id = ''): string
{
    $idAttr = $id ? ' id="' . e($id) . '"' : '';
    if (!empty($user['profile_photo'])) {
        return '<span class="' . $class . ' avatar-blank has-photo"' . $idAttr
             . ' style="background-image:url(\'../' . e($user['profile_photo']) . '\')">' . AVATAR_SVG . '</span>';
    }
    return '<span class="' . $class . ' avatar-blank"' . $idAttr . '>' . AVATAR_SVG . '</span>';
}

/** Search box + Book Tickets + avatar + name (used in both header styles). */
function customer_topbar_right(array $user): void
{
    ?>
      <form class="search-form" action="booking-history.php" method="get" role="search">
        <input class="search" type="search" name="q" placeholder="Search bookings..." maxlength="40"
               value="<?= e($_GET['q'] ?? '') ?>" aria-label="Search your bookings" />
      </form>
      <div class="topbar-right">
        <a class="btn-book" href="park-tickets.php">Book Tickets</a>
        <a href="my-profile.php" aria-label="Profile"><?= customer_avatar($user, 'avatar', 'topbar-avatar') ?></a>
        <span class="username" id="topbar-name"><?= e($user['full_name']) ?></span>
      </div>
<?php
}

function customer_topbar(array $user): void
{
    ?>
  <header class="topbar">
    <a class="logo" href="dashboard.php"><img src="assets/logo.png" alt="SafariLand Nature Park" /></a>
    <div class="topbar-content">
<?php customer_topbar_right($user); ?>
    </div>
  </header>
<?php
}

function customer_sidebar(string $active): void
{
    $links = [
        'dashboard'       => ['dashboard.php', 'Dashboard'],
        'my-tickets'      => ['my-tickets.php', 'My Tickets'],
        'booking-history' => ['booking-history.php', 'Booking History'],
        'my-review'       => ['my-review.php', 'My review'],
        'my-profile'      => ['my-profile.php', 'My Profile'],
    ];
    echo '    <nav class="sidebar">' . "\n";
    foreach ($links as $key => [$href, $label]) {
        $cls = $key === $active ? ' class="active" aria-current="page"' : '';
        echo "      <a href=\"$href\"$cls>$label</a>\n";
    }
    echo '      <a href="../index.php">Visit Website</a>' . "\n";
    echo '      <a href="../logout.php?token=' . e(csrf_token()) . '">Log out</a>' . "\n";
    echo "    </nav>\n";
}

/** Header of the 3-step checkout (Tickets -> Payment -> Confirmation). */
function checkout_header(array $user, int $step, string $backHref): void
{
    $steps = [1 => 'Tickets', 2 => 'Payment', 3 => 'Confirmation'];
    ?>
  <header class="checkout-header">
    <div class="ch-left">
      <a href="dashboard.php"><img src="assets/logo.png" alt="SafariLand Nature Park" /></a>
      <a class="btn-back" href="<?= e($backHref) ?>">Back</a>
    </div>
    <div class="ch-right">
      <div class="ch-top">
<?php customer_topbar_right($user); ?>
      </div>

      <ol class="stepper">
<?php $i = 0; foreach ($steps as $n => $label): ?>
<?php if ($i++): ?>
        <li class="step-line" aria-hidden="true"></li>
<?php endif; ?>
        <li class="step<?= $n <= $step ? ' done' : '' ?>"<?= $n === $step ? ' aria-current="step"' : '' ?>><span class="dot"><?= $n ?></span><span class="label"><?= $label ?></span></li>
<?php endforeach; ?>
      </ol>
    </div>
  </header>
<?php
}

/** Success / error banner shown after a redirect. */
function customer_flash(): void
{
    foreach (['success' => 'ok', 'error' => 'error', 'info' => 'info'] as $type => $cls) {
        if ($m = get_flash($type)) {
            echo '<p class="alert alert-' . $cls . '" role="status">' . e($m) . '</p>';
        }
    }
}

function customer_foot(bool $withScripts = true): void
{
    if ($withScripts) {
        echo '  <script src="assets/jquery.min.js"></script>' . "\n";
        echo '  <script src="script.js"></script>' . "\n";
    }
    echo "</body>\n</html>\n";
}
