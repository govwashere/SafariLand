<?php
/**
 * Contact strip used at the bottom of every visitor page.
 * Expects: $contactTag ('section' or 'footer'), $contactClass (extra CSS classes).
 */
$contactTag   = $contactTag ?? 'footer';
$contactClass = $contactClass ?? '';
$contactEmail = setting('contact_email', 'hello@safariland.example');
?>
<<?= $contactTag ?> class="home-contact <?= e($contactClass) ?>">
  <div>
    <h2>Contact us</h2>
    <p>We'd love to hear from you! Plan your visit, ask a question or learn more about SafariLand.</p>
  </div>
  <div class="contact-actions">
    <div class="contact-links">
      <span class="contact-envelope" aria-hidden="true">✉</span>
      <a href="mailto:<?= e($contactEmail) ?>"><?= e($contactEmail) ?></a>
      <a href="contact.php">Send us a message</a>
      <a href="https://social.example/safariland" target="_blank" rel="noopener noreferrer">Social</a>
    </div>
    <a class="book-adventure" href="customer/park-tickets.php">Book Your Adventure</a>
  </div>
</<?= $contactTag ?>>
