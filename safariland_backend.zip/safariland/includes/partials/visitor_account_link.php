<?php
/** "Log in" for guests, "My Account" for a logged-in customer/admin. */
$navUser = current_user();
if (!$navUser): ?>
        <a href="login.php">Log in</a>
<?php elseif ($navUser['role'] === 'admin'): ?>
        <a href="admin/index.php">Admin</a>
<?php else: ?>
        <a href="customer/dashboard.php">My Account</a>
<?php endif; ?>
