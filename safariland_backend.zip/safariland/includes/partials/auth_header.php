<?php /** Shared top of the visitor auth/contact pages. Expects $pageTitle. Pages are noindex. */ ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="<?= !empty($indexable) ? 'index, follow' : 'noindex, nofollow' ?>">
  <title><?= e($pageTitle) ?> | SafariLand Nature Park</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bayon&family=Baskervville+SC&family=Irish+Grover&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
</head>
<body class="attractions-page auth-page">
  <header class="home-header attractions-header">
    <a class="home-logo" href="index.php" aria-label="SafariLand home">
      <img src="images/safariland-logo.png" alt="SafariLand Nature Park">
    </a>
    <button class="menu-toggle" aria-expanded="false" aria-controls="main-nav">Menu</button>
    <nav id="main-nav" class="home-nav" aria-label="Main navigation">
      <a href="index.php">Home</a>
      <a href="attractions.php">Attractions</a>
      <a href="park.php">The Park</a>
      <a href="index.php#park-info">Plan Your Visit</a>
      <a class="login-pill" href="customer/park-tickets.php">Buy Ticket</a>
    </nav>
  </header>

  <main class="auth-main">
    <section class="auth-card">
