<?php
/**
 * ADMIN area - shared layout (head, top bar, sidebar, footer).
 * The CSRF token is printed in a <meta> tag so the jQuery AJAX calls
 * (add / edit / delete) can send it in the X-CSRF-Token header.
 */

function admin_head(string $title): void
{
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow, noarchive">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <title><?= e($title) ?> | SafariLand Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Baskervville:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php
}

function admin_topbar(array $admin): void
{
    $unread = (int)db()->query('SELECT COUNT(*) FROM messages WHERE is_read = 0')->fetchColumn();
    ?>
<header class="topbar">
  <a class="brand" href="index.php">
    <img src="assets/images/SafariLand_Toucan_Nature_Park_Logo.png" alt="SafariLand Nature Park">
  </a>
  <div class="topbar-main">
    <label class="pill-input search">
      <span class="sr-only">Search this page</span>
      <input type="search" class="js-search" id="globalSearch" placeholder="Search...">
    </label>
    <a href="messages.php" class="icon-box" aria-label="Messages (<?= $unread ?> unread)">
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9a6 6 0 0 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>
      <?php if ($unread): ?><span class="badge"><?= $unread ?></span><?php endif; ?>
    </a>
    <div class="user"><span class="avatar" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($admin['full_name'], 0, 1))) ?></span><span><?= e($admin['full_name']) ?></span></div>
  </div>
</header>
<?php
}

function admin_sidebar(string $active): void
{
    $links = [
        'index'       => 'Dashboard',
        'attractions' => 'Attraction',
        'tickets'     => 'Ticket Type',
        'events'      => 'Events',
        'customers'   => 'Customer',
        'bookings'    => 'Bookings',
        'reviews'     => 'Reviews',
        'messages'    => 'Messages',
        'settings'    => 'Settings',
    ];
    echo "<div class=\"shell\">\n  <nav class=\"sidebar\" aria-label=\"Main\">\n    <ul>\n";
    foreach ($links as $page => $label) {
        $cls = $page === $active ? ' class="is-active" aria-current="page"' : '';
        echo "        <li><a href=\"$page.php\"$cls>$label</a></li>\n";
    }
    echo '        <li><a href="../logout.php?token=' . e(csrf_token()) . "\">Log out</a></li>\n";
    echo "    </ul>\n  </nav>\n";
}

/** Flash banner after a redirect (settings page). */
function admin_flash(): void
{
    foreach (['success' => 'ok', 'error' => 'error'] as $type => $cls) {
        if ($m = get_flash($type)) {
            echo '<p class="alert alert-' . $cls . '" role="status">' . e($m) . '</p>';
        }
    }
}

function admin_foot(array $scripts = []): void
{
    echo "</div>\n\n<div class=\"toast\" id=\"toast\" role=\"status\" aria-live=\"polite\"></div>\n\n";
    echo "<script src=\"assets/js/jquery.min.js\"></script>\n";
    echo "<script src=\"assets/js/common.js\"></script>\n";
    foreach ($scripts as $s) {
        echo "<script src=\"assets/js/$s\"></script>\n";
    }
    echo "</body>\n</html>\n";
}

/** Delete-confirmation modal (same markup as the designs). */
function admin_delete_modal(string $id, string $noun): void
{
    ?>
<div class="modal-overlay" id="<?= $id ?>" aria-hidden="true">
  <div class="modal modal--confirm" role="alertdialog" aria-modal="true" aria-labelledby="<?= $id ?>Title" aria-describedby="<?= $id ?>Text">
    <h2 id="<?= $id ?>Title">Delete <?= e($noun) ?>?</h2>
    <p id="<?= $id ?>Text">Are you sure you want to remove this <?= e(strtolower($noun)) ?>?</p>
    <div class="modal-actions modal-actions--split">
      <button type="button" class="btn btn-outline js-close">Cancel</button>
      <button type="button" class="btn btn-danger js-confirm-delete">Delete <?= e($noun) ?></button>
    </div>
  </div>
</div>
<?php
}

/** Edit / Delete links in a table row. */
function admin_row_actions(bool $canDelete = true, string $editLabel = 'Edit'): string
{
    $html = '<button type="button" class="link-btn js-edit">' . $editLabel . '</button>';
    if ($canDelete) {
        $html .= '<span aria-hidden="true">/</span><button type="button" class="link-btn js-delete">Delete</button>';
    }
    return $html;
}
