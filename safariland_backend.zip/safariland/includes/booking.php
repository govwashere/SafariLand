<?php
/**
 * CUSTOMER - booking logic shared by park-tickets.php and payment.php.
 *
 * Key security decision: the browser only sends WHICH tickets and HOW MANY.
 * Prices, service fee and totals are ALWAYS recalculated here from the
 * database, so nobody can change the price by editing the page or the URL.
 */

/** All ticket types, keyed by id. */
function ticket_types(): array
{
    $rows = db()->query('SELECT * FROM ticket_types ORDER BY price')->fetchAll();
    return array_column($rows, null, 'id');
}

/**
 * Validate the quantities + visit date sent by the Park Tickets form.
 * Returns [cart, errorMessage]. cart = ['visit_date' => 'Y-m-d', 'items' => [typeId => qty]]
 */
function validate_cart($qtyInput, $visitDate): array
{
    $types = ticket_types();
    $items = [];
    $count = 0;

    if (!is_array($qtyInput)) {
        return [null, 'Please choose at least one ticket to continue.'];
    }
    foreach ($qtyInput as $typeId => $qty) {
        $typeId = filter_var($typeId, FILTER_VALIDATE_INT);
        $qty    = filter_var($qty, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => MAX_TICKETS_PER_TYPE]]);
        if ($typeId === false || !isset($types[$typeId])) {
            return [null, 'One of the selected tickets does not exist any more. Please choose again.'];
        }
        if ($qty === false) {
            return [null, 'You can buy between 0 and ' . MAX_TICKETS_PER_TYPE . ' tickets of each type.'];
        }
        if ($qty > 0) {
            $items[$typeId] = $qty;
            $count += $qty;
        }
    }
    if ($count === 0) {
        return [null, 'Please choose at least one ticket to continue.'];
    }

    $v = new Validator(['visit_date' => is_string($visitDate) ? $visitDate : '']);
    $v->required('visit_date', 'Visit date')
      ->date('visit_date', date('Y-m-d'), date('Y-m-d', strtotime('+' . MAX_DAYS_AHEAD . ' days')), 'Visit date');
    if ($v->fails()) {
        return [null, $v->errors()['visit_date']];
    }

    return [['visit_date' => $v->get('visit_date'), 'items' => $items], null];
}

/** Lines + totals for a cart, priced from the database. */
function price_cart(array $cart): array
{
    $types = ticket_types();
    $lines = [];
    $subtotal = 0;
    foreach ($cart['items'] as $typeId => $qty) {
        if (!isset($types[$typeId])) {
            continue;                                   // type deleted meanwhile
        }
        $t = $types[$typeId];
        $lineTotal = $t['price'] * $qty;
        $subtotal += $lineTotal;
        $lines[] = ['type_id' => $typeId, 'name' => $t['name'], 'unit_price' => $t['price'], 'qty' => $qty, 'total' => $lineTotal];
    }
    $fee = $lines ? (float)setting('service_fee', '100') : 0;
    return ['lines' => $lines, 'subtotal' => $subtotal, 'fee' => $fee, 'total' => $subtotal + $fee];
}

/** Random, hard-to-guess ticket code, e.g. VIP7K2M9QX4A */
function new_ticket_code(string $typeName): string
{
    $prefix = ['vip' => 'VIP', 'family' => 'FAM', 'general' => 'GEN'][ticket_class($typeName)];
    $chars  = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';        // no 0/O/1/I to avoid confusion
    $code   = $prefix;
    while (strlen($code) < 12) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $code;
}

/**
 * Save the booking, its items and one ticket per person - all or nothing
 * (database transaction). Only the last 4 card digits are stored.
 * Returns the booking reference.
 */
function create_booking(int $userId, array $cart, string $cardHolder, string $cardNumber): string
{
    $priced = price_cart($cart);
    if (!$priced['lines']) {
        throw new RuntimeException('Your basket is empty.');
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare('INSERT INTO bookings (user_id, visit_date, subtotal, service_fee, total, status, card_holder, card_last4)
                       VALUES (?, ?, ?, ?, ?, \'Paid\', ?, ?)')
            ->execute([$userId, $cart['visit_date'], $priced['subtotal'], $priced['fee'], $priced['total'],
                       $cardHolder, substr($cardNumber, -4)]);
        $bookingId = (int)$pdo->lastInsertId();
        $reference = sprintf('SL-%s-%05d', date('Y'), $bookingId);
        $pdo->prepare('UPDATE bookings SET reference = ? WHERE id = ?')->execute([$reference, $bookingId]);

        $itemStmt   = $pdo->prepare('INSERT INTO booking_items (booking_id, ticket_type_id, ticket_name, unit_price, quantity, line_total)
                                     VALUES (?, ?, ?, ?, ?, ?)');
        $ticketStmt = $pdo->prepare('INSERT INTO tickets (booking_item_id, ticket_code) VALUES (?, ?)');

        foreach ($priced['lines'] as $line) {
            $itemStmt->execute([$bookingId, $line['type_id'], $line['name'], $line['unit_price'], $line['qty'], $line['total']]);
            $itemId = (int)$pdo->lastInsertId();
            for ($i = 0; $i < $line['qty']; $i++) {
                $ticketStmt->execute([$itemId, new_ticket_code($line['name'])]);
            }
        }
        $pdo->commit();
        return $reference;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/** Fetch one booking that BELONGS to this user (stops users opening other people's bookings). */
function find_user_booking(int $userId, string $reference): ?array
{
    $stmt = db()->prepare('SELECT * FROM bookings WHERE reference = ? AND user_id = ?');
    $stmt->execute([$reference, $userId]);
    $b = $stmt->fetch();
    if (!$b) {
        return null;
    }
    $items = db()->prepare('SELECT * FROM booking_items WHERE booking_id = ?');
    $items->execute([$b['id']]);
    $b['items'] = $items->fetchAll();
    return $b;
}

/** A booking can be cancelled by the customer up to the day before the visit. */
function can_cancel(array $booking): bool
{
    return $booking['status'] === 'Paid' && $booking['visit_date'] > date('Y-m-d');
}
