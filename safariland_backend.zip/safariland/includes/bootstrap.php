<?php
/**
 * SafariLand - bootstrap.
 * Every PHP page starts with:  require __DIR__ . '/includes/bootstrap.php';
 * It loads config, opens the database, starts a secure session and sends
 * security headers. Helpers for auth, CSRF, flash messages and output
 * escaping live here too.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/Validator.php';
require_once __DIR__ . '/upload.php';

error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
date_default_timezone_set('Indian/Mauritius');

/* ---------------------------------------------------------------------
 * Security headers (sent on every page)
 * ------------------------------------------------------------------- */
header('X-Content-Type-Options: nosniff');           // no MIME sniffing
header('X-Frame-Options: SAMEORIGIN');               // no clickjacking via iframes
header('Referrer-Policy: strict-origin-when-cross-origin');

/* ---------------------------------------------------------------------
 * Secure session
 * ------------------------------------------------------------------- */
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');         // reject unknown session ids
    ini_set('session.use_only_cookies', '1');        // never put the id in the URL
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),     // HTTPS-only cookie when on HTTPS
        'httponly' => true,                          // JavaScript cannot read the cookie
        'samesite' => 'Lax',                         // basic CSRF protection
    ]);
    session_name('SAFARISESSID');
    session_start();
}

// Idle timeout
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > SESSION_IDLE_SECONDS) {
    $_SESSION = [];
    session_regenerate_id(true);
    $_SESSION['flash']['info'] = 'You were logged out after 30 minutes of inactivity.';
}
$_SESSION['last_activity'] = time();

/* ---------------------------------------------------------------------
 * Database (PDO with real prepared statements)
 * ------------------------------------------------------------------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false, // true server-side prepared statements
                ]
            );
        } catch (PDOException $e) {
            error_log($e->getMessage());
            http_response_code(500);
            exit(APP_DEBUG ? 'Database connection failed: ' . $e->getMessage()
                           : 'The site is temporarily unavailable. Please try again later.');
        }
    }
    return $pdo;
}

/* ---------------------------------------------------------------------
 * Output helpers
 * ------------------------------------------------------------------- */

/** Escape for HTML output - use on EVERY value printed into a page (XSS protection). */
function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function money($amount): string
{
    return 'Rs ' . number_format((float)$amount, 0, '.', ',');
}

function nice_date(?string $date, string $format = 'j M Y'): string
{
    return $date ? date($format, strtotime($date)) : '';
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** Only allow redirects to pages on this site (prevents open-redirect attacks). */
function safe_next(?string $next, string $fallback): string
{
    if ($next && preg_match('#^[a-zA-Z0-9_\-/]+\.php(\?[a-zA-Z0-9_=&%\-]*)?$#', $next) && strpos($next, '//') === false) {
        return $next;
    }
    return $fallback;
}

/* ---------------------------------------------------------------------
 * Flash messages (shown once after a redirect - Post/Redirect/Get)
 * ------------------------------------------------------------------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][$type] = $message;
}

function get_flash(string $type): ?string
{
    $msg = $_SESSION['flash'][$type] ?? null;
    unset($_SESSION['flash'][$type]);
    return $msg;
}

/* ---------------------------------------------------------------------
 * CSRF protection: every POST form carries a secret token that an
 * attacker's site cannot know.
 * ------------------------------------------------------------------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $sent = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_GET['token'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        if (is_ajax()) {
            json_response(['ok' => false, 'message' => 'Your session expired. Please refresh the page.'], 419);
        }
        exit('Security check failed (invalid CSRF token). Please go back, refresh the page and try again.');
    }
}

function is_ajax(): bool
{
    return ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

/* ---------------------------------------------------------------------
 * Search-engine privacy: private pages must never be indexed.
 * (Also covered by robots.txt, .htaccess and <meta name="robots">.)
 * ------------------------------------------------------------------- */
function no_index(): void
{
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('Cache-Control: no-store, no-cache, must-revalidate, private'); // no "Back" after logout
}

/* ---------------------------------------------------------------------
 * Authentication + user groups (customer / admin)
 * ------------------------------------------------------------------- */

/** The logged-in user, re-read from the DB on every request so a block/role change applies instantly. */
function current_user(): ?array
{
    static $user = false;
    if ($user === false) {
        $user = null;
        if (!empty($_SESSION['user_id'])) {
            $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch() ?: null;
            if ($user && $user['status'] !== 'Active') {   // blocked while logged in
                logout_user();
                $user = null;
            }
        }
    }
    return $user;
}

function is_customer(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'customer';
}

function require_customer(): array
{
    no_index();
    $u = current_user();
    if (!$u) {
        flash('info', 'Please log in to continue.');
        $next = 'customer/' . basename($_SERVER['PHP_SELF']) . (empty($_SERVER['QUERY_STRING']) ? '' : '?' . $_SERVER['QUERY_STRING']);
        redirect('../login.php?next=' . urlencode($next));
    }
    if ($u['role'] !== 'customer') {               // an admin cannot use customer pages
        redirect('../admin/index.php');
    }
    return $u;
}

function require_admin(): array
{
    no_index();
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') {
        if (is_ajax()) {
            json_response(['ok' => false, 'message' => 'Not authorised.'], 403);
        }
        if ($u) {                                   // logged in but a customer -> forbidden
            http_response_code(403);
            exit('403 - You do not have permission to view the admin area.');
        }
        redirect(admin_base() . 'login.php');
    }
    return $u;
}

function admin_base(): string
{
    return strpos($_SERVER['PHP_SELF'], '/api/') !== false ? '../' : '';
}

/**
 * Check email + password. Returns [user, null] or [null, error message].
 * Same generic message for unknown email or wrong password (no user enumeration).
 */
function attempt_login(string $email, string $password, string $role): array
{
    $generic = 'Invalid email or password.';
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? AND role = ?');
    $stmt->execute([$email, $role]);
    $user = $stmt->fetch();

    if (!$user) {
        password_verify($password, '$2y$10$EM8hICRMOO2FlLiguoFs3.rUxo7V7iqg8WhjLw9aTa5WFT.7pfjfO'); // equal timing
        return [null, $generic];
    }
    if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
        $mins = ceil((strtotime($user['locked_until']) - time()) / 60);
        return [null, "Too many failed attempts. Try again in $mins minute(s)."];
    }
    if (!password_verify($password, $user['password_hash'])) {
        $fails = $user['failed_logins'] + 1;
        $lock  = $fails >= MAX_LOGIN_ATTEMPTS ? date('Y-m-d H:i:s', time() + LOCKOUT_MINUTES * 60) : null;
        db()->prepare('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?')
            ->execute([$lock ? 0 : $fails, $lock, $user['id']]);
        return [null, $lock ? 'Too many failed attempts. Account locked for ' . LOCKOUT_MINUTES . ' minutes.' : $generic];
    }
    if ($user['status'] !== 'Active') {
        return [null, 'This account has been blocked. Please contact SafariLand.'];
    }
    // Upgrade the hash automatically if PHP's default algorithm changes
    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
    }
    db()->prepare('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = NOW() WHERE id = ?')
        ->execute([$user['id']]);
    return [$user, null];
}

function login_user(array $user): void
{
    session_regenerate_id(true);                    // prevent session fixation
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['role']    = $user['role'];
    unset($_SESSION['csrf_token']);                 // new token for the new session
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/* ---------------------------------------------------------------------
 * Settings table helpers
 * ------------------------------------------------------------------- */
function setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = db()->query('SELECT setting_key, setting_value FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR);
    }
    return $cache[$key] ?? $default;
}

/** Map a ticket type name to the CSS colour class used by the designs. */
function ticket_class(string $name): string
{
    $n = strtolower($name);
    if (strpos($n, 'vip') !== false)    return 'vip';
    if (strpos($n, 'family') !== false) return 'family';
    return 'general';
}

/** Path of an uploaded image relative to the current folder ('' for root, '../' for customer/admin). */
function upload_url(?string $path, string $prefix = ''): string
{
    return $path ? $prefix . $path : '';
}
