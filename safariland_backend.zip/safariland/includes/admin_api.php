<?php
/**
 * Loaded at the top of every admin API endpoint (admin/api/*.php).
 * Rules for every AJAX request:
 *   1. must be a logged-in ADMIN            (require_admin)
 *   2. must be a POST                       (no changes through links)
 *   3. must carry the CSRF token            (verify_csrf)
 * Answers are JSON: { ok: true, row: {...}, message } or { ok: false, errors: {field: msg}, message }
 */
require_once __DIR__ . '/bootstrap.php';

$admin = require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'message' => 'Method not allowed.'], 405);
}
verify_csrf();

$action = $_POST['action'] ?? '';

/** Validation failed -> 422 with one message per field. */
function fail_validation(array $errors): void
{
    json_response(['ok' => false, 'errors' => $errors, 'message' => 'Please correct the highlighted fields.'], 422);
}

/** Optional id from the form: null for "add", int for "edit". */
function posted_id(): ?int
{
    $id = $_POST['id'] ?? '';
    if ($id === '' || $id === null) {
        return null;
    }
    $id = filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$id) {
        json_response(['ok' => false, 'message' => 'Invalid record.'], 400);
    }
    return $id;
}

/** Fetch one row by id from a fixed table, or answer 404. */
function find_or_404(string $table, int $id): array
{
    $stmt = db()->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        json_response(['ok' => false, 'message' => 'This record no longer exists. Please refresh the page.'], 404);
    }
    return $row;
}
