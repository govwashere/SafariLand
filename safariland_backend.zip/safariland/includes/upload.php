<?php
/**
 * SafariLand - safe image upload.
 *
 * Security decisions:
 *  - we check the REAL file type with finfo (the browser-sent type can be faked)
 *  - getimagesize() must succeed, so the file is really an image
 *  - size limit (2 MB)
 *  - the stored file gets a random name, so users cannot overwrite files
 *    or upload "shell.php"
 *  - uploads/.htaccess stops any script from running inside uploads/
 *
 * Returns [relativePath, null] on success, [null, errorMessage] on failure,
 * or [null, null] when no file was chosen (field is optional).
 */
function upload_image(?array $file, string $subfolder): array
{
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return [null, null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [null, $file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE
            ? 'Image is too large (max 2 MB).' : 'Upload failed. Please try again.'];
    }
    if ($file['size'] > UPLOAD_MAX_BYTES) {
        return [null, 'Image is too large (max 2 MB).'];
    }

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $mime    = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime]) || @getimagesize($file['tmp_name']) === false) {
        return [null, 'Only JPG, PNG, WEBP or GIF images are allowed.'];
    }

    $dir = UPLOAD_DIR . '/' . $subfolder;
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        return [null, 'Upload folder is not writable.'];
    }
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], "$dir/$name")) {
        return [null, 'Could not save the image.'];
    }
    return ["uploads/$subfolder/$name", null];
}

/** Delete an old uploaded file when it is replaced (only inside uploads/). */
function delete_upload(?string $path): void
{
    if ($path && strpos($path, 'uploads/') === 0 && strpos($path, '..') === false) {
        $full = dirname(__DIR__) . '/' . $path;
        if (is_file($full)) {
            @unlink($full);
        }
    }
}
