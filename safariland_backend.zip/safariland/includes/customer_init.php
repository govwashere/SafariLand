<?php
/**
 * Loaded at the top of every customer page:
 * bootstrap + layout helpers + access control (customers only).
 */
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/partials/customer_layout.php';

$user = require_customer();   // redirects to login if not a logged-in customer
