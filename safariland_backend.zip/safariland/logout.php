<?php
/**
 * Log out (customers and admins).
 * The link carries the CSRF token so another website cannot log you out.
 */
require __DIR__ . '/includes/bootstrap.php';
no_index();

verify_csrf();                 // token sent as ?token=...
$wasAdmin = ($_SESSION['role'] ?? '') === 'admin';
logout_user();

session_start();               // new empty session just to carry the message
flash('success', 'You have been logged out.');
redirect($wasAdmin ? 'admin/login.php' : 'login.php');
