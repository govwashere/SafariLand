// Homepage-only browser interactions.
document.addEventListener("DOMContentLoaded", () => {
  // Show the current year in the footer.
  document.querySelectorAll("[data-year]").forEach((element) => {
    element.textContent = new Date().getFullYear();
  });

  // Toggle the navigation menu on small screens.
  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector("#main-nav");

  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(isOpen));
    });
  }

  // Filter the attraction cards by their category.
  const filterButtons = document.querySelectorAll("[data-filter]");
  const attractionCards = document.querySelectorAll(".attraction-card");
  const filterStatus = document.querySelector(".filter-status");

  if (filterButtons.length && attractionCards.length) {
    const availableFilters = ["all", "adventure", "animals"];
    const requestedFilter = new URLSearchParams(window.location.search).get("category");
    const startingFilter = availableFilters.includes(requestedFilter) ? requestedFilter : "all";

    const showCategory = (category) => {
      attractionCards.forEach((card) => {
        card.hidden = category !== "all" && card.dataset.category !== category;
      });

      filterButtons.forEach((button) => {
        const selected = button.dataset.filter === category;
        button.classList.toggle("is-active", selected);
        button.setAttribute("aria-pressed", String(selected));
      });

      if (filterStatus) {
        const visibleCount = Array.from(attractionCards).filter((card) => !card.hidden).length;
        filterStatus.textContent = `${visibleCount} attraction${visibleCount === 1 ? "" : "s"} shown`;
      }
    };

    filterButtons.forEach((button) => {
      button.addEventListener("click", () => showCategory(button.dataset.filter));
    });

    showCategory(startingFilter);
  }

  // Links marked as placeholders do nothing until their destination is ready.
  document.querySelectorAll("[data-placeholder-link]").forEach((link) => {
    link.addEventListener("click", (event) => event.preventDefault());
  });
});
/* -----------------------------------------------------------------
   Client-side validation for the PHP forms (login, register, contact).
   Uses the HTML5 rules written on each input (required, pattern,
   minlength, type=email ...) and shows the message under the field.
   The server validates everything again - this is only for comfort.
   ----------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("form[data-validate]").forEach((form) => {
    const showError = (input, message) => {
      const box = input.closest(".auth-field, .auth-check");
      if (!box) return;
      box.classList.add("has-error");
      let small = box.querySelector(".auth-error");
      if (!small) {
        small = document.createElement("small");
        small.className = "auth-error";
        box.appendChild(small);
      }
      small.textContent = message;
    };
    const clearError = (input) => {
      const box = input.closest(".auth-field, .auth-check");
      if (!box) return;
      box.classList.remove("has-error");
      box.querySelector(".auth-error")?.remove();
    };
    const messageFor = (input) => {
      const v = input.validity;
      const label = form.querySelector(`label[for="${input.id}"]`)?.textContent.trim() || "This field";
      if (v.valueMissing) return input.type === "checkbox" ? "Please tick this box to continue." : `${label} is required.`;
      if (v.typeMismatch) return "Enter a valid email address.";
      if (v.tooShort) return `${label} must be at least ${input.minLength} characters.`;
      if (v.tooLong) return `${label} must be at most ${input.maxLength} characters.`;
      if (v.patternMismatch) return input.title || `${label} has an invalid format.`;
      if (v.customError) return input.validationMessage;
      return `${label} is not valid.`;
    };

    form.querySelectorAll("input, textarea").forEach((input) => {
      input.addEventListener("input", () => {
        // "Confirm password" must equal the field named in data-match
        if (input.dataset.match) {
          const other = form.querySelector(`[name="${input.dataset.match}"]`);
          input.setCustomValidity(other && other.value !== input.value ? "Passwords do not match." : "");
        }
        clearError(input);
      });
    });

    form.addEventListener("submit", (event) => {
      let firstBad = null;
      form.querySelectorAll("input:not([type=hidden]):not([tabindex='-1']), textarea").forEach((input) => {
        if (input.dataset.match) {
          const other = form.querySelector(`[name="${input.dataset.match}"]`);
          input.setCustomValidity(other && other.value !== input.value ? "Passwords do not match." : "");
        }
        if (!input.checkValidity()) {
          showError(input, messageFor(input));
          firstBad = firstBad || input;
        } else {
          clearError(input);
        }
      });
      if (firstBad) {
        event.preventDefault();
        firstBad.focus();
      }
    });
  });
});
