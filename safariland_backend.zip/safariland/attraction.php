<?php
/**
 * VISITOR - Attraction detail page (new page behind the "Read More" buttons).
 * The id comes from the URL, so it is validated as an integer and used in a
 * prepared statement (no SQL injection).
 */
require __DIR__ . '/includes/bootstrap.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$a  = null;
if ($id) {
    $stmt = db()->prepare("SELECT * FROM attractions WHERE id = ? AND status = 'Open'");
    $stmt->execute([$id]);
    $a = $stmt->fetch();
}
if (!$a) {
    http_response_code(404);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="<?= $a ? e(mb_strimwidth((string)$a['description'], 0, 150, '…')) : 'Attraction not found' ?>">
  <title><?= $a ? e($a['name']) : 'Not found' ?> | SafariLand Nature Park</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bayon&family=Baskervville+SC&family=Irish+Grover&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
</head>
<body class="attractions-page">
  <header class="home-header attractions-header">
    <a class="home-logo" href="index.php" aria-label="SafariLand home">
      <img src="images/safariland-logo.png" alt="SafariLand Nature Park">
    </a>
    <button class="menu-toggle" aria-expanded="false" aria-controls="main-nav">Menu</button>
    <nav id="main-nav" class="home-nav" aria-label="Main navigation">
      <a href="index.php">Home</a>
      <a class="current-page" href="attractions.php">Attractions</a>
      <a href="park.php">The Park</a>
      <a href="index.php#park-info">Plan Your Visit</a>
      <?php include __DIR__ . '/includes/partials/visitor_account_link.php'; ?>
      <a class="login-pill" href="customer/park-tickets.php">Buy Ticket</a>
    </nav>
  </header>

  <main class="detail-main">
    <a class="detail-back" href="attractions.php">← All attractions</a>
    <?php if (!$a): ?>
      <h1 class="detail-title">Attraction not found</h1>
      <p>This attraction does not exist or is currently closed.</p>
    <?php else: ?>
    <article class="detail-card">
      <img class="detail-image" src="<?= e(upload_url($a['image'])) ?>" alt="<?= e($a['name']) ?>">
      <div class="detail-copy">
        <p class="detail-kicker"><?= e($a['category'] === 'Animal' ? 'Animal Encounter' : 'Adventure') ?></p>
        <h1 class="detail-title"><?= e($a['name']) ?></h1>
        <p><?= nl2br(e($a['description'])) ?></p>
        <dl class="detail-facts">
          <div><dt>Price</dt><dd><?= money($a['price']) ?></dd></div>
          <div><dt>Duration</dt><dd><?= (int)$a['duration'] ?> min</dd></div>
          <div><dt>Minimum age</dt><dd><?= $a['min_age'] ? (int)$a['min_age'] . ' years' : 'All ages' ?></dd></div>
          <div><dt>Minimum height</dt><dd><?= $a['min_height'] ? (int)$a['min_height'] . ' cm' : 'None' ?></dd></div>
        </dl>
        <a class="green-pill" href="customer/park-tickets.php">Buy Ticket</a>
      </div>
    </article>
    <?php endif; ?>
  </main>

  <?php $contactTag = 'footer'; $contactClass = 'attractions-contact'; include __DIR__ . '/includes/partials/visitor_contact.php'; ?>
</body>
</html>
