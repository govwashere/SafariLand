<?php
/**
 * CUSTOMER - My review (full CRUD on the reviews table).
 *   CREATE  : write a new review
 *   READ    : list my reviews
 *   UPDATE  : edit one of my reviews (my-review.php?edit=ID)
 *   DELETE  : delete one of my reviews
 * Every UPDATE/DELETE has "AND user_id = ?" so a customer can only touch
 * their own reviews, even if they change the id in the page.
 * Hidden reviews (moderated by the admin) are shown with a label.
 */
require __DIR__ . '/../includes/customer_init.php';

$errors = [];
$form   = ['id' => '', 'rating' => '5', 'title' => '', 'comment' => ''];

/** Load one review that belongs to the current user. */
function my_review(int $userId, $id): ?array
{
    $id = filter_var($id, FILTER_VALIDATE_INT);
    if (!$id) return null;
    $stmt = db()->prepare('SELECT * FROM reviews WHERE id = ? AND user_id = ?');
    $stmt->execute([$id, $userId]);
    return $stmt->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $stmt = db()->prepare('DELETE FROM reviews WHERE id = ? AND user_id = ?');
        $stmt->execute([(int)($_POST['id'] ?? 0), $user['id']]);
        flash($stmt->rowCount() ? 'success' : 'error', $stmt->rowCount() ? 'Your review has been deleted.' : 'Review not found.');
        redirect('my-review.php');
    }

    if ($action === 'save') {
        $v = new Validator($_POST);
        $v->required('rating', 'Rating')->integer('rating', 1, 5, 'Rating')
          ->required('title', 'Title')->minLength('title', 3, 'Title')->maxLength('title', 100, 'Title')
          ->required('comment', 'Review')->minLength('comment', 10, 'Review')->maxLength('comment', 1000, 'Review');

        $editingId = $_POST['id'] ?? '';
        if ($editingId !== '' && !my_review((int)$user['id'], $editingId)) {
            $v->addError('form', 'Review not found.');
        }

        if (!$v->fails()) {
            if ($editingId !== '') {
                db()->prepare('UPDATE reviews SET rating = ?, title = ?, comment = ? WHERE id = ? AND user_id = ?')
                    ->execute([$v->get('rating'), $v->get('title'), $v->get('comment'), (int)$editingId, $user['id']]);
                flash('success', 'Your review has been updated.');
            } else {
                db()->prepare('INSERT INTO reviews (user_id, rating, title, comment) VALUES (?, ?, ?, ?)')
                    ->execute([$user['id'], $v->get('rating'), $v->get('title'), $v->get('comment')]);
                flash('success', 'Thank you! Your review has been published.');
            }
            redirect('my-review.php');
        }
        $errors = $v->errors();
        $form   = ['id' => $editingId, 'rating' => $v->get('rating'), 'title' => $v->get('title'), 'comment' => $v->get('comment')];
    }
} elseif (isset($_GET['edit']) && ($r = my_review((int)$user['id'], $_GET['edit']))) {
    $form = $r;
}

$stmt = db()->prepare('SELECT * FROM reviews WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([$user['id']]);
$reviews = $stmt->fetchAll();

customer_head('My review');
customer_topbar($user);
?>

  <div class="layout">
<?php customer_sidebar('my-review'); ?>

    <main class="main">
      <h1 class="title">My review</h1>
      <p class="subtitle">Tell other visitors about your day at SafariLand.</p>
      <?php customer_flash(); ?>
      <?php if (!empty($errors['form'])): ?><p class="alert alert-error"><?= e($errors['form']) ?></p><?php endif; ?>

      <div class="profile-grid">
        <section class="card">
          <div class="card-head"><h2><?= $form['id'] ? 'Edit review' : 'Write a review' ?></h2></div>

          <form id="review-form" method="post" action="my-review.php" novalidate>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save" />
            <input type="hidden" name="id" value="<?= e($form['id']) ?>" />

            <fieldset class="field-group rating-group<?= isset($errors['rating']) ? ' invalid' : '' ?>">
              <legend>Rating</legend>
              <div class="stars">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" required <?= (string)$form['rating'] === (string)$i ? 'checked' : '' ?> />
                <label for="star<?= $i ?>" title="<?= $i ?> star<?= $i > 1 ? 's' : '' ?>">★</label>
                <?php endfor; ?>
              </div>
              <?php if (isset($errors['rating'])): ?><small class="field-error"><?= e($errors['rating']) ?></small><?php endif; ?>
            </fieldset>

            <div class="field-group">
              <label for="title">Title</label>
              <input class="field<?= isset($errors['title']) ? ' invalid' : '' ?>" id="title" name="title" type="text" required minlength="3" maxlength="100" value="<?= e($form['title']) ?>" />
              <?php if (isset($errors['title'])): ?><small class="field-error"><?= e($errors['title']) ?></small><?php endif; ?>
            </div>

            <div class="field-group">
              <label for="comment">Your review</label>
              <textarea class="field field-area<?= isset($errors['comment']) ? ' invalid' : '' ?>" id="comment" name="comment" rows="5" required minlength="10" maxlength="1000"><?= e($form['comment']) ?></textarea>
              <?php if (isset($errors['comment'])): ?><small class="field-error"><?= e($errors['comment']) ?></small><?php endif; ?>
            </div>

            <div class="card-actions">
              <?php if ($form['id']): ?><a class="btn-small btn-light" href="my-review.php">Cancel</a><?php endif; ?>
              <button type="submit" class="btn-small"><?= $form['id'] ? 'Save Changes' : 'Publish Review' ?></button>
            </div>
          </form>
        </section>

        <div class="profile-side">
          <section class="card">
            <h2>Your reviews (<?= count($reviews) ?>)</h2>
            <?php if (!$reviews): ?><p class="subtitle">You haven't written a review yet.</p><?php endif; ?>
            <?php foreach ($reviews as $r): ?>
            <article class="review-item">
              <p class="review-stars" aria-label="<?= (int)$r['rating'] ?> out of 5"><?= str_repeat('★', (int)$r['rating']) . str_repeat('☆', 5 - (int)$r['rating']) ?></p>
              <h3><?= e($r['title']) ?> <?php if ($r['status'] === 'Hidden'): ?><span class="status-badge status-cancelled">Hidden by admin</span><?php endif; ?></h3>
              <p><?= nl2br(e($r['comment'])) ?></p>
              <small><?= nice_date($r['updated_at'], 'j M Y') ?></small>
              <div class="review-actions">
                <a class="view-link" href="my-review.php?edit=<?= (int)$r['id'] ?>">Edit</a>
                <form method="post" action="my-review.php" data-confirm="Delete this review?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete" />
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>" />
                  <button type="submit" class="link-like danger">Delete</button>
                </form>
              </div>
            </article>
            <?php endforeach; ?>
          </section>
        </div>
      </div>
    </main>
  </div>

<?php customer_foot(); ?>
