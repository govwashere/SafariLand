<?php
/**
 * CUSTOMER - Step 2: payment.
 *
 * GET  (from park-tickets.php): validate quantities + date, save them in the
 *      session "cart", show the order summary priced from the database.
 * POST (Pay Now): validate the card on the server, then CREATE the booking,
 *      booking items and tickets in one transaction and redirect (PRG).
 *
 * This is a simulated payment - no real money is taken. Full card numbers
 * and CVV are never stored or logged; only the last 4 digits are kept.
 */
require __DIR__ . '/../includes/customer_init.php';
require __DIR__ . '/../includes/booking.php';

$errors = [];
$holder = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['qty'])) {
    [$cart, $error] = validate_cart($_GET['qty'], $_GET['visit_date'] ?? '');
    if ($error) {
        flash('error', $error);
        redirect('park-tickets.php');
    }
    $_SESSION['cart'] = $cart;
    redirect('payment.php');            // clean URL, so a refresh does not resend the form
}

$cart = $_SESSION['cart'] ?? null;
if (!$cart) {
    flash('info', 'Choose your tickets first.');
    redirect('park-tickets.php');
}
$order = price_cart($cart);
if (!$order['lines']) {
    unset($_SESSION['cart']);
    flash('error', 'The selected tickets are no longer available.');
    redirect('park-tickets.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $v = new Validator($_POST);
    $v->required('holder', 'Cardholder name')->name('holder')
      ->required('card', 'Card number')->cardNumber('card')
      ->required('expiry', 'Expiry date')->cardExpiry('expiry')
      ->required('cvv', 'CVV')->cvv('cvv');
    // the visit date could have passed while the page was open
    if ($cart['visit_date'] < date('Y-m-d')) {
        $v->addError('form', 'Your visit date is in the past. Please choose a new date.');
    }
    $holder = $v->get('holder');

    if (!$v->fails()) {
        try {
            $ref = create_booking((int)$user['id'], $cart, $holder, preg_replace('/\D/', '', $v->get('card')));
            unset($_SESSION['cart']);
            $_SESSION['last_booking'] = $ref;
            redirect('confirmation.php');
        } catch (Throwable $e) {
            error_log('Booking failed: ' . $e->getMessage());
            $v->addError('form', 'Sorry, we could not complete your booking. You have not been charged. Please try again.');
        }
    }
    $errors = $v->errors();
}

customer_head('Payment Details');
checkout_header($user, 2, 'park-tickets.php');

/** Print a card field with its server-side error (if any). */
function pay_field(string $id, string $label, string $type, string $attrs, array $errors, string $value = ''): void
{
    $bad = isset($errors[$id]);
    echo '<div class="pay-field">';
    echo '<label for="' . $id . '">' . $label . '</label>';
    echo '<input class="input-lg' . ($bad ? ' invalid' : '') . '" id="' . $id . '" name="' . $id . '" type="' . $type . '" ' . $attrs
       . ' value="' . e($value) . '"' . ($bad ? ' aria-invalid="true"' : '') . ' />';
    if ($bad) {
        echo '<small class="field-error">' . e($errors[$id]) . '</small>';
    }
    echo '</div>';
}
?>

  <main class="checkout-main">
    <div class="payment-grid">

      <!-- Card details -->
      <div class="payment-main">
        <h1 class="title">Payment Details</h1>

        <?php if (!empty($errors['form'])): ?><p class="alert alert-error" role="alert"><?= e($errors['form']) ?></p><?php endif; ?>

        <div class="method-box">Credit / Debit Card</div>
        <p class="pay-note">Demo payment - use test card 4242 4242 4242 4242, any future expiry and any 3-digit CVV.</p>

        <form id="payment-form" action="payment.php" method="post" novalidate autocomplete="on">
          <?= csrf_field() ?>
          <?php
          pay_field('holder', 'Cardholder Name', 'text', 'autocomplete="cc-name" required maxlength="100"', $errors, $holder);
          pay_field('card', 'Card Number', 'text', 'inputmode="numeric" autocomplete="cc-number" maxlength="19" required', $errors);
          ?>
          <div class="pay-row">
            <?php
            pay_field('expiry', 'Expiry Date', 'text', 'placeholder="MM/YY" autocomplete="cc-exp" maxlength="5" required pattern="(0[1-9]|1[0-2])/\d{2}"', $errors);
            pay_field('cvv', 'CVV', 'password', 'inputmode="numeric" autocomplete="cc-csc" maxlength="4" required pattern="\d{3,4}"', $errors);
            ?>
          </div>
        </form>
      </div>

      <!-- Order summary (calculated on the server) -->
      <aside class="summary">
        <h2>Order Summary</h2>

        <div class="summary-brand">
          <img src="assets/logo.png" alt="SafariLand" />
          <div>
            <strong>SafariLand Tickets</strong>
            <small><?= nice_date($cart['visit_date']) ?></small>
          </div>
        </div>

        <div id="order-lines">
          <?php foreach ($order['lines'] as $line): ?>
          <div class="line"><span><?= e($line['name']) ?> x <?= (int)$line['qty'] ?></span><span><?= money($line['total']) ?></span></div>
          <?php endforeach; ?>
        </div>
        <hr />
        <div class="line"><span>Subtotal</span><span id="subtotal"><?= money($order['subtotal']) ?></span></div>
        <div class="line"><span>Service Fee</span><span id="fee"><?= money($order['fee']) ?></span></div>
        <div class="line total"><span>Total</span><span id="total"><?= money($order['total']) ?></span></div>

        <button type="submit" form="payment-form" class="btn-primary pay">Pay Now →</button>
      </aside>

    </div>
  </main>

<?php customer_foot(); ?>
