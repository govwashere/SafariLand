<?php
/**
 * CUSTOMER - My Profile.
 * Three separate POST forms on one page, told apart by "action":
 *   profile  -> UPDATE name, email, phone, date of birth, address
 *   photo    -> UPDATE profile picture (safe upload)
 *   password -> UPDATE password (current password required)
 * Each one: CSRF check -> server validation -> prepared UPDATE -> redirect (PRG).
 */
require __DIR__ . '/../includes/customer_init.php';

$errors  = ['profile' => [], 'photo' => [], 'password' => []];
$form    = $user;                     // values shown in the personal form
$editing = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    /* ---------- Personal information ---------- */
    if ($action === 'profile') {
        $v = new Validator($_POST);
        $v->required('full_name', 'Full name')->name('full_name')
          ->required('email', 'Email')->email('email')
          ->unique('email', 'users', 'email', (int)$user['id'], 'Another account already uses this email.')
          ->required('phone', 'Phone number')->phone('phone')
          ->date('dob', '1900-01-01', date('Y-m-d', strtotime('-1 day')), 'Date of birth')
          ->maxLength('address', 200, 'Address');

        if (!$v->fails()) {
            db()->prepare('UPDATE users SET full_name = ?, email = ?, phone = ?, dob = ?, address = ? WHERE id = ?')
                ->execute([$v->get('full_name'), $v->get('email'), $v->get('phone'),
                           $v->get('dob') ?: null, $v->get('address') ?: null, $user['id']]);
            flash('success', 'Your personal information has been saved.');
            redirect('my-profile.php');
        }
        $errors['profile'] = $v->errors();
        $editing = true;
        foreach (['full_name', 'email', 'phone', 'dob', 'address'] as $k) {
            $form[$k] = $v->get($k);
        }
    }

    /* ---------- Profile picture ---------- */
    if ($action === 'photo') {
        [$path, $err] = upload_image($_FILES['photo'] ?? null, 'profiles');
        if ($err || !$path) {
            $errors['photo']['photo'] = $err ?: 'Please choose an image.';
        } else {
            db()->prepare('UPDATE users SET profile_photo = ? WHERE id = ?')->execute([$path, $user['id']]);
            delete_upload($user['profile_photo']);          // remove the old file
            flash('success', 'Your profile picture has been updated.');
            redirect('my-profile.php');
        }
    }

    if ($action === 'remove_photo' && $user['profile_photo']) {
        db()->prepare('UPDATE users SET profile_photo = NULL WHERE id = ?')->execute([$user['id']]);
        delete_upload($user['profile_photo']);
        flash('success', 'Your profile picture has been removed.');
        redirect('my-profile.php');
    }

    /* ---------- Password ---------- */
    if ($action === 'password') {
        $v = new Validator($_POST);
        $v->required('current_pw', 'Current password')
          ->required('new_pw', 'New password')->strongPassword('new_pw')
          ->required('confirm_pw', 'Confirm password')
          ->matches('confirm_pw', 'new_pw', 'New password and confirmation do not match.');
        if (!$v->fails() && !password_verify((string)$_POST['current_pw'], $user['password_hash'])) {
            $v->addError('current_pw', 'Current password is incorrect.');
        }
        if (!$v->fails() && password_verify((string)$_POST['new_pw'], $user['password_hash'])) {
            $v->addError('new_pw', 'New password must be different from the current one.');
        }
        if (!$v->fails()) {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($_POST['new_pw'], PASSWORD_DEFAULT), $user['id']]);
            session_regenerate_id(true);
            flash('success', 'Your password has been changed.');
            redirect('my-profile.php');
        }
        $errors['password'] = $v->errors();
    }
}

/** Personal-information input with its server-side error. */
function profile_field(string $name, string $label, string $type, ?string $value, string $attrs, array $errs, bool $editing): void
{
    $bad = isset($errs[$name]);
    echo '<div class="field-group">';
    echo '<label for="' . $name . '">' . $label . '</label>';
    echo '<input class="field' . ($bad ? ' invalid' : '') . '" id="' . $name . '" name="' . $name . '" type="' . $type . '" value="' . e($value) . '" '
       . $attrs . ($editing ? '' : ' readonly') . ' />';
    if ($bad) {
        echo '<small class="field-error">' . e($errs[$name]) . '</small>';
    }
    echo '</div>';
}

customer_head('My Profile');
customer_topbar($user);
?>

  <div class="layout">
<?php customer_sidebar('my-profile'); ?>

    <main class="main">
      <h1 class="title">My Profile</h1>
      <p class="subtitle">Manage your personal information and account settings.</p>
      <?php customer_flash(); ?>

      <div class="profile-grid">

        <!-- Personal information -->
        <section class="card">
          <div class="card-head">
            <h2>Personal Information</h2>
            <button type="button" class="btn-small" id="edit-btn" data-editing="<?= $editing ? '1' : '0' ?>"><?= $editing ? 'Save' : 'Edit' ?></button>
          </div>

          <form id="personal-form" method="post" action="my-profile.php" novalidate>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="profile" />
            <?php
            $pe = $errors['profile'];
            profile_field('full_name', 'Full Name', 'text', $form['full_name'], 'required maxlength="100" pattern="[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .\'\-]{1,99}" autocomplete="name"', $pe, $editing);
            profile_field('email', 'Email', 'email', $form['email'], 'required maxlength="150" autocomplete="email"', $pe, $editing);
            profile_field('phone', 'Phone Number', 'tel', $form['phone'], 'required pattern="\+?[0-9 ]{7,20}" autocomplete="tel"', $pe, $editing);
            profile_field('dob', 'Date Of Birth', 'date', $form['dob'], 'min="1900-01-01" max="' . date('Y-m-d', strtotime('-1 day')) . '"', $pe, $editing);
            profile_field('address', 'Address', 'text', $form['address'], 'maxlength="200" autocomplete="street-address"', $pe, $editing);
            ?>
            <div class="card-actions<?= $editing ? '' : ' is-hidden' ?>" id="profile-actions">
              <a class="btn-small btn-light" href="my-profile.php">Cancel</a>
            </div>
          </form>
        </section>

        <div class="profile-side">

          <!-- Profile picture -->
          <section class="card">
            <h2>Profile Picture</h2>
            <form id="photo-form" method="post" action="my-profile.php" enctype="multipart/form-data">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="photo" />
              <input type="hidden" name="MAX_FILE_SIZE" value="<?= UPLOAD_MAX_BYTES ?>" />
              <div class="photo-row">
                <?= customer_avatar($user, 'big-avatar', 'profile-avatar') ?>
                <button type="button" class="btn-photo">Change Photo</button>
                <input type="file" id="photo-input" name="photo" accept="image/jpeg,image/png,image/webp,image/gif" hidden />
              </div>
              <p class="form-msg error" id="photo-msg" role="status"><?= e($errors['photo']['photo'] ?? '') ?></p>
            </form>
            <?php if ($user['profile_photo']): ?>
            <form method="post" action="my-profile.php">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="remove_photo" />
              <button type="submit" class="link-like">Remove photo</button>
            </form>
            <?php endif; ?>
          </section>

          <!-- Password -->
          <section class="card">
            <form id="password-form" method="post" action="my-profile.php" novalidate>
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="password" />
              <div class="pw-row">
                <label for="current-pw">Current Password</label>
                <input class="field" id="current-pw" name="current_pw" type="password" required autocomplete="current-password" />
              </div>
              <div class="pw-row">
                <label for="new-pw">New Password</label>
                <input class="field" id="new-pw" name="new_pw" type="password" required minlength="8" maxlength="72" autocomplete="new-password" />
              </div>
              <div class="pw-row">
                <label for="confirm-pw">Confirm Password</label>
                <input class="field" id="confirm-pw" name="confirm_pw" type="password" required autocomplete="new-password" />
              </div>
              <p class="form-msg error" id="pw-msg" role="status"><?= e($errors['password'] ? reset($errors['password']) : '') ?></p>
              <div class="card-actions">
                <button type="submit" class="btn-small">Save Changes</button>
              </div>
            </form>
          </section>

        </div>
      </div>
    </main>
  </div>

<?php customer_foot(); ?>
