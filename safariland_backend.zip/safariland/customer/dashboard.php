<?php
/**
 * CUSTOMER - Dashboard.
 * READ: next visit, ticket counts, upcoming events (from the events table).
 */
require __DIR__ . '/../includes/customer_init.php';

// Next upcoming visit for this customer
$stmt = db()->prepare("SELECT reference, visit_date FROM bookings
                       WHERE user_id = ? AND status = 'Paid' AND visit_date >= CURDATE()
                       ORDER BY visit_date LIMIT 1");
$stmt->execute([$user['id']]);
$nextVisit = $stmt->fetch();

$events = db()->query("SELECT title, event_date, image FROM events
                       WHERE status = 'Published' AND event_date >= CURDATE()
                       ORDER BY event_date LIMIT 4")->fetchAll();

customer_head('Dashboard');
customer_topbar($user);
?>

  <div class="layout">
<?php customer_sidebar('dashboard'); ?>

    <main class="main">
      <?php customer_flash(); ?>

      <!-- Welcome banner -->
      <section class="dash-hero">
        <img src="assets/hero-dashboard.png" alt="Savanna landscape with a giraffe and a waterfall" />
        <div class="dash-hero-text">
          <h1>Welcome Back, <?= e(strtok($user['full_name'], ' ')) ?>!</h1>
          <?php if ($nextVisit): ?>
          <p>Your next visit is on <strong><?= nice_date($nextVisit['visit_date'], 'l j F Y') ?></strong> (booking <?= e($nextVisit['reference']) ?>). We can't wait to see you!</p>
          <?php else: ?>
          <p>We're delighted to see you again at SafariLand. Your next adventure, amazing experiences and unforgettable moments are just around the corner!</p>
          <?php endif; ?>
        </div>
      </section>

      <!-- Quick links -->
      <section class="quick-grid">
        <a class="quick-card" href="park-tickets.php">
          <h3>Buy Tickets</h3>
          <p>Book your next adventure</p>
        </a>
        <a class="quick-card" href="booking-history.php">
          <h3>Bookings</h3>
          <p>View and manage your tickets</p>
        </a>
        <a class="quick-card" href="../park.php">
          <h3>Plan Visit</h3>
          <p>Park info, maps and facilities</p>
        </a>
        <a class="quick-card" href="../index.php#events">
          <h3>Explore Events</h3>
          <p>See what's coming to SafariLand</p>
        </a>
      </section>

      <!-- Announcements + events -->
      <section class="dash-panels">
        <div class="panel announcements">
          <div class="panel-head">
            <h2>Announcements</h2>
            <a href="../attractions.php">View all →</a>
          </div>
          <article class="announce">
            <img src="assets/announcement-giraffe.png" alt="Giraffe" />
            <div class="announce-text">
              <h3>New Animal Encounter Zone Opening Soon!</h3>
              <p>Get closer to nature with our exciting new encounters.</p>
            </div>
          </article>
        </div>

        <div class="panel events">
          <div class="panel-head">
            <h2>Upcoming Events</h2>
            <a href="../index.php#events">View all →</a>
          </div>
          <ul class="event-list">
            <?php foreach ($events as $ev): ?>
            <li>
              <div class="event-date"><span><?= nice_date($ev['event_date'], 'd') ?></span><span><?= nice_date($ev['event_date'], 'M') ?></span></div>
              <img src="<?= e(upload_url($ev['image'], '../')) ?>" alt="<?= e($ev['title']) ?>" />
              <span class="event-name"><?= e($ev['title']) ?></span>
            </li>
            <?php endforeach; ?>
            <?php if (!$events): ?><li class="event-name">No upcoming events yet.</li><?php endif; ?>
          </ul>
        </div>
      </section>

    </main>
  </div>

<?php customer_foot(false); ?>
