<?php
/**
 * CUSTOMER - Step 1: choose tickets + visit date.
 * READ ticket types from the DB. The form is sent with GET to payment.php,
 * where it is validated on the server.
 */
require __DIR__ . '/../includes/customer_init.php';
require __DIR__ . '/../includes/booking.php';

$types = ticket_types();
$cart  = $_SESSION['cart'] ?? ['visit_date' => date('Y-m-d'), 'items' => []];
$today = date('Y-m-d');
$max   = date('Y-m-d', strtotime('+' . MAX_DAYS_AHEAD . ' days'));

customer_head('Park Tickets');
checkout_header($user, 1, 'dashboard.php');
?>

  <main class="checkout-main">
    <div class="pt-head">
      <h1 class="title">Park Tickets</h1>
      <div class="pt-hero">
        <img src="assets/hero-zebras.png" alt="Zebras on the savanna at sunset" />
      </div>
    </div>

    <?php customer_flash(); ?>

    <form id="tickets-form" action="payment.php" method="get" novalidate>
      <div class="visit-date">
        <label for="visit_date">Visit date</label>
        <input class="field" id="visit_date" name="visit_date" type="date" required
               min="<?= $today ?>" max="<?= $max ?>" value="<?= e(max($cart['visit_date'], $today)) ?>" />
        <small class="field-error" id="date-error" hidden></small>
      </div>

      <div class="pass-grid">
        <?php foreach ($types as $t): ?>
        <div class="pass-card">
          <div class="ticket <?= ticket_class($t['name']) ?>">
            <div class="body"><img src="assets/logo.png" alt="SafariLand" /></div>
            <div class="stub"><span><?= e($t['name']) ?></span></div>
          </div>
          <p class="pass-price"><?= money($t['price']) ?> · <?= (int)$t['guests'] ?> guest<?= $t['guests'] > 1 ? 's' : '' ?></p>
          <ul class="pass-includes">
            <?php foreach (array_filter(array_map('trim', explode("\n", $t['description']))) as $line): ?>
            <li><?= e($line) ?></li>
            <?php endforeach; ?>
          </ul>
          <div class="qty" data-pass="<?= (int)$t['id'] ?>">
            <button type="button" class="minus" aria-label="Remove one <?= e($t['name']) ?>">−</button>
            <input type="number" name="qty[<?= (int)$t['id'] ?>]" value="<?= (int)($cart['items'][$t['id']] ?? 0) ?>"
                   min="0" max="<?= MAX_TICKETS_PER_TYPE ?>" step="1" readonly aria-label="<?= e($t['name']) ?> quantity" />
            <button type="button" class="plus" aria-label="Add one <?= e($t['name']) ?>">+</button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <p class="msg-error" id="pass-error" hidden>Please choose at least one ticket to continue.</p>

      <div class="actions">
        <button type="submit" class="btn-primary" id="continue">Continue to Payment</button>
      </div>
    </form>
  </main>

<?php customer_foot(); ?>
