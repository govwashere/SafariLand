<?php
/**
 * CUSTOMER - Booking details (READ) + Cancel booking (UPDATE status).
 * Cancelling is a POST with a CSRF token; the server re-checks that the
 * booking belongs to the user and that the visit date is still in the future.
 */
require __DIR__ . '/../includes/customer_init.php';
require __DIR__ . '/../includes/booking.php';

$ref     = (string)($_GET['ref'] ?? $_POST['ref'] ?? '');
$booking = preg_match('/^SL-\d{4}-\d{5}$/', $ref) ? find_user_booking((int)$user['id'], $ref) : null;
if (!$booking) {
    flash('error', 'Booking not found.');
    redirect('booking-history.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancel') {
    verify_csrf();
    if (!can_cancel($booking)) {
        flash('error', 'This booking can no longer be cancelled.');
    } else {
        db()->prepare("UPDATE bookings SET status = 'Cancelled' WHERE id = ? AND user_id = ?")
            ->execute([$booking['id'], $user['id']]);
        flash('success', 'Booking ' . $booking['reference'] . ' has been cancelled. Your refund will be processed within 5 working days.');
    }
    redirect('booking-details.php?ref=' . urlencode($booking['reference']));
}

customer_head('Booking ' . $booking['reference']);
customer_topbar($user);
?>

  <div class="layout">
<?php customer_sidebar('booking-history'); ?>

    <main class="main">
      <a class="view-link" href="booking-history.php">← Back to Booking History</a>
      <h1 class="title">Booking <?= e($booking['reference']) ?></h1>
      <?php customer_flash(); ?>

      <div class="profile-grid">
        <section class="card">
          <div class="card-head">
            <h2>Tickets</h2>
            <span class="status-badge status-<?= strtolower(e($booking['status'])) ?>"><?= e($booking['status']) ?></span>
          </div>
          <?php foreach ($booking['items'] as $it): ?>
          <div class="line"><span><?= e($it['ticket_name']) ?> x <?= (int)$it['quantity'] ?> (<?= money($it['unit_price']) ?> each)</span><span><?= money($it['line_total']) ?></span></div>
          <?php endforeach; ?>
          <hr class="rule" />
          <div class="line"><span>Subtotal</span><span><?= money($booking['subtotal']) ?></span></div>
          <div class="line"><span>Service Fee</span><span><?= money($booking['service_fee']) ?></span></div>
          <div class="line total"><span>Total</span><span><?= money($booking['total']) ?></span></div>
        </section>

        <div class="profile-side">
          <section class="card">
            <h2>Visit</h2>
            <div class="line"><span>Visit date</span><span><?= nice_date($booking['visit_date'], 'D j M Y') ?></span></div>
            <div class="line"><span>Booked on</span><span><?= nice_date($booking['created_at'], 'j M Y, H:i') ?></span></div>
            <div class="line"><span>Paid with</span><span>Card •••• <?= e($booking['card_last4']) ?></span></div>
            <div class="card-actions">
              <?php if ($booking['status'] === 'Paid'): ?>
              <a class="btn-small" href="ticket.php?ref=<?= urlencode($booking['reference']) ?>" target="_blank" rel="noopener">Download Tickets</a>
              <?php endif; ?>
            </div>
          </section>

          <?php if (can_cancel($booking)): ?>
          <section class="card">
            <h2>Cancel booking</h2>
            <p class="subtitle">You can cancel up to the day before your visit.</p>
            <form method="post" action="booking-details.php" data-confirm="Cancel booking <?= e($booking['reference']) ?>? This cannot be undone.">
              <?= csrf_field() ?>
              <input type="hidden" name="ref" value="<?= e($booking['reference']) ?>" />
              <input type="hidden" name="action" value="cancel" />
              <div class="card-actions"><button type="submit" class="btn-small btn-danger">Cancel Booking</button></div>
            </form>
          </section>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>

<?php customer_foot(); ?>
