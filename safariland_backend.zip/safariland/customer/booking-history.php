<?php
/**
 * CUSTOMER - Booking History (READ) with search by reference / ticket name.
 * The search term is bound as a parameter (LIKE ?), never pasted into SQL.
 */
require __DIR__ . '/../includes/customer_init.php';

$q = trim((string)($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 40);

$sql = "SELECT b.created_at, b.reference, b.total, b.status, b.visit_date,
               GROUP_CONCAT(CONCAT(i.ticket_name, ' x', i.quantity) ORDER BY i.id SEPARATOR ', ') AS items
        FROM bookings b
        JOIN booking_items i ON i.booking_id = b.id
        WHERE b.user_id = ?";
$params = [$user['id']];
if ($q !== '') {
    $sql .= ' AND (b.reference LIKE ? OR i.ticket_name LIKE ?)';
    $like = '%' . addcslashes($q, '%_\\') . '%';
    array_push($params, $like, $like);
}
$sql .= ' GROUP BY b.id ORDER BY b.created_at DESC';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

customer_head('Booking History');
customer_topbar($user);
?>

  <div class="layout">
<?php customer_sidebar('booking-history'); ?>

    <main class="main has-hero">
      <div class="hero">
        <img src="assets/hero-giraffe.png" alt="Giraffe at sunrise" />
      </div>

      <h1 class="title">Booking History</h1>
      <?php customer_flash(); ?>
      <?php if ($q !== ''): ?>
        <p class="search-note">Results for “<?= e($q) ?>” · <a class="view-link" href="booking-history.php">Clear search</a></p>
      <?php endif; ?>

      <div class="table-card">
        <table class="history">
          <thead>
            <tr>
              <th>Date</th>
              <th>Booking Reference</th>
              <th>Item</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($bookings as $b): ?>
            <tr>
              <td><?= nice_date($b['created_at']) ?></td>
              <td><?= e($b['reference']) ?></td>
              <td><?= e($b['items']) ?></td>
              <td><?= money($b['total']) ?></td>
              <td><span class="status-badge status-<?= strtolower(e($b['status'])) ?>"><?= e($b['status']) ?></span></td>
              <td><a class="view-link" href="booking-details.php?ref=<?= urlencode($b['reference']) ?>">View Details</a></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$bookings): ?>
            <tr><td colspan="6"><?= $q !== '' ? 'No bookings match your search.' : 'You have not made any bookings yet.' ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>

<?php customer_foot(false); ?>
