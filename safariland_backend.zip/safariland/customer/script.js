/* =====================================================
   SafariLand – customer area (jQuery)
   Client-side validation gives instant feedback; the PHP
   pages validate everything again on the server.
   Each block only runs if its page elements exist.
   ===================================================== */
$(function () {

  /* ---------------------------------------------------
     Shared helpers
     --------------------------------------------------- */
  var NAME_RE = /^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .'\-]{1,99}$/;
  var PHONE_RE = /^\+?[0-9 ]{7,20}$/;
  var STRONG_PW = function (p) {
    return p.length >= 8 && p.length <= 72 && /[A-Z]/.test(p) && /[a-z]/.test(p) && /\d/.test(p);
  };

  // Show / clear an error under a field (works for .pay-field and .field-group)
  var showError = function ($input, message) {
    var $group = $input.closest('.pay-field, .field-group, .visit-date');
    $input.addClass('invalid').attr('aria-invalid', 'true');
    $group.find('.field-error').remove();
    $('<small class="field-error"></small>').text(message).appendTo($group);
  };
  var clearError = function ($input) {
    $input.removeClass('invalid').removeAttr('aria-invalid');
    $input.closest('.pay-field, .field-group, .visit-date').find('.field-error').remove();
  };

  // Forms with data-confirm ask before submitting (cancel booking, delete review ...)
  $('form[data-confirm]').on('submit', function (e) {
    if (!window.confirm($(this).data('confirm'))) { e.preventDefault(); }
  });


  /* ---------------------------------------------------
     MY TICKETS – Active / Past tabs
     --------------------------------------------------- */
  $('.tab[data-tab]').on('click', function () {
    var showActive = $(this).data('tab') === 'active';

    $('.tab').removeClass('active');
    $(this).addClass('active');

    $('#tab-active').toggleClass('is-hidden', !showActive);
    $('#tab-past').toggleClass('is-hidden', showActive);
  });


  /* ---------------------------------------------------
     PARK TICKETS – quantity buttons + visit date
     --------------------------------------------------- */
  var $qty = $('.qty');

  if ($qty.length) {
    var MAX_PER_PASS = 10;

    $qty.on('click', 'button', function () {
      var $input = $(this).siblings('input');
      var n = parseInt($input.val(), 10) || 0;

      n += $(this).hasClass('plus') ? 1 : -1;
      $input.val(Math.min(MAX_PER_PASS, Math.max(0, n)));

      $('#pass-error').prop('hidden', true);
    });

    $('#visit_date').on('input change', function () { clearError($(this)); });

    // Need at least one ticket and a valid date to go to the payment page
    $('#tickets-form').on('submit', function (e) {
      var total = 0;
      $qty.find('input').each(function () { total += parseInt($(this).val(), 10) || 0; });

      var $date = $('#visit_date');
      var ok = true;
      clearError($date);

      if (!$date.val()) {
        showError($date, 'Please choose the date of your visit.');
        ok = false;
      } else if ($date.val() < $date.attr('min') || $date.val() > $date.attr('max')) {
        showError($date, 'Choose a date between today and one year from now.');
        ok = false;
      }
      if (total === 0) {
        $('#pass-error').prop('hidden', false);
        ok = false;
      }
      if (!ok) { e.preventDefault(); }
    });
  }


  /* ---------------------------------------------------
     PAYMENT – input formatting + validation
     (order summary is now calculated by PHP from the database)
     --------------------------------------------------- */
  var $payForm = $('#payment-form');

  if ($payForm.length) {

    // --- Live formatting while typing ---
    $('#card').on('input', function () {
      var digits = $(this).val().replace(/\D/g, '').slice(0, 16);
      $(this).val(digits.replace(/(.{4})/g, '$1 ').trim());
    });

    $('#expiry').on('input', function () {
      var digits = $(this).val().replace(/\D/g, '').slice(0, 4);
      $(this).val(digits.length > 2 ? digits.slice(0, 2) + '/' + digits.slice(2) : digits);
    });

    $('#cvv').on('input', function () {
      $(this).val($(this).val().replace(/\D/g, '').slice(0, 4));
    });

    // Remove an error as soon as the person starts fixing the field
    $payForm.find('.input-lg').on('input', function () { clearError($(this)); });

    var isExpired = function (value) {
      var parts = value.split('/');
      var month = parseInt(parts[0], 10);
      var year = 2000 + parseInt(parts[1], 10);
      var now = new Date();
      return year < now.getFullYear() ||
             (year === now.getFullYear() && month < now.getMonth() + 1);
    };

    // Luhn checksum – the same check the server does
    var luhn = function (digits) {
      var sum = 0, alt = false;
      for (var i = digits.length - 1; i >= 0; i--) {
        var n = parseInt(digits.charAt(i), 10);
        if (alt) { n *= 2; if (n > 9) { n -= 9; } }
        sum += n;
        alt = !alt;
      }
      return sum % 10 === 0;
    };

    $payForm.on('submit', function (e) {
      var $holder = $('#holder'), $card = $('#card'), $expiry = $('#expiry'), $cvv = $('#cvv');
      var valid = true;
      var digits = $card.val().replace(/\s/g, '');

      $payForm.find('.input-lg').each(function () { clearError($(this)); });

      if (!NAME_RE.test($.trim($holder.val()))) {
        showError($holder, 'Enter the name shown on the card.');
        valid = false;
      }
      if (digits.length !== 16) {
        showError($card, 'Card number must be 16 digits.');
        valid = false;
      } else if (!luhn(digits)) {
        showError($card, 'This card number is not valid.');
        valid = false;
      }
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test($expiry.val())) {
        showError($expiry, 'Use the format MM/YY.');
        valid = false;
      } else if (isExpired($expiry.val())) {
        showError($expiry, 'This card has expired.');
        valid = false;
      }
      if (!/^\d{3,4}$/.test($cvv.val())) {
        showError($cvv, 'CVV must be 3 or 4 digits.');
        valid = false;
      }

      if (!valid) {
        e.preventDefault();
        $payForm.find('.invalid').first().trigger('focus');
      }
      // valid -> the form is posted to payment.php, which validates again and saves the booking
    });
  }


  /* ---------------------------------------------------
     MY PROFILE – edit/save, live name, password check, photo upload
     --------------------------------------------------- */
  var $editBtn = $('#edit-btn');

  if ($editBtn.length) {
    var $personal = $('#personal-form');
    var editing = $editBtn.data('editing') === 1;

    var validatePersonal = function () {
      var ok = true;
      $personal.find('.field').each(function () { clearError($(this)); });

      var $name = $('#full_name'), $email = $('#email'), $phone = $('#phone'), $dob = $('#dob'), $address = $('#address');
      if (!NAME_RE.test($.trim($name.val()))) { showError($name, 'Enter your full name (letters only).'); ok = false; }
      if (!$email[0].checkValidity() || !$.trim($email.val())) { showError($email, 'Enter a valid email address.'); ok = false; }
      if (!PHONE_RE.test($.trim($phone.val()))) { showError($phone, 'Enter a valid phone number.'); ok = false; }
      if ($dob.val() && !$dob[0].checkValidity()) { showError($dob, 'Enter a valid date of birth in the past.'); ok = false; }
      if ($address.val().length > 200) { showError($address, 'Address must be at most 200 characters.'); ok = false; }

      if (!ok) { $personal.find('.invalid').first().trigger('focus'); }
      return ok;
    };

    // "Edit" unlocks the fields, "Save" validates and sends them to PHP
    $editBtn.on('click', function () {
      if (!editing) {
        editing = true;
        $personal.find('.field').prop('readonly', false);
        $(this).text('Save');
        $('#profile-actions').removeClass('is-hidden');
        $('#full_name').trigger('focus');
        return;
      }
      if (validatePersonal()) {
        $(this).prop('disabled', true);
        $personal[0].submit();
      }
    });

    // Enter key inside the form also validates first
    $personal.on('submit', function (e) {
      if (!validatePersonal()) { e.preventDefault(); }
    });
    $personal.on('input', '.field', function () { clearError($(this)); });

    // The name in the top bar follows the Full Name field as you type
    $('#full_name').on('input', function () {
      $('#topbar-name').text($.trim($(this).val()));
    });

    // Password form
    $('#password-form').on('submit', function (e) {
      var current = $('#current-pw').val();
      var next = $('#new-pw').val();
      var confirm = $('#confirm-pw').val();
      var $msg = $('#pw-msg').removeClass('ok error');
      var error = '';

      if (!current || !next || !confirm) {
        error = 'Please fill in all three password fields.';
      } else if (!STRONG_PW(next)) {
        error = 'New password needs 8+ characters with an upper-case letter, a lower-case letter and a number.';
      } else if (next !== confirm) {
        error = 'New password and confirmation do not match.';
      }

      if (error) {
        e.preventDefault();
        $msg.addClass('error').text(error);
      }
    });

    // Change Photo – choose an image, preview it, then upload it
    $('.btn-photo').on('click', function () { $('#photo-input').trigger('click'); });

    $('#photo-input').on('change', function () {
      var file = this.files && this.files[0];
      var $msg = $('#photo-msg').removeClass('ok').addClass('error').text('');
      if (!file) { return; }
      if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) {
        $msg.text('Please choose a JPG, PNG, WEBP or GIF image.');
        this.value = '';
        return;
      }
      if (file.size > 2 * 1024 * 1024) {
        $msg.text('Image is too large (max 2 MB).');
        this.value = '';
        return;
      }

      var reader = new FileReader();
      reader.onload = function (ev) {
        $('#profile-avatar, #topbar-avatar')
          .addClass('has-photo')
          .css('background-image', 'url("' + ev.target.result + '")');
      };
      reader.readAsDataURL(file);

      $msg.removeClass('error').addClass('ok').text('Uploading…');
      $('#photo-form')[0].submit();
    });
  }


  /* ---------------------------------------------------
     MY REVIEW – required rating, title and text
     --------------------------------------------------- */
  var $review = $('#review-form');

  if ($review.length) {
    $review.on('input change', 'input, textarea', function () { clearError($(this)); });

    $review.on('submit', function (e) {
      var ok = true;
      var $title = $('#title'), $comment = $('#comment');
      $review.find('.field').each(function () { clearError($(this)); });
      $review.find('.rating-group .field-error').remove();

      if (!$review.find('input[name=rating]:checked').length) {
        $('<small class="field-error"></small>').text('Please choose a rating.').appendTo('.rating-group');
        ok = false;
      }
      if ($.trim($title.val()).length < 3) { showError($title, 'Title must be at least 3 characters.'); ok = false; }
      if ($.trim($comment.val()).length < 10) { showError($comment, 'Your review must be at least 10 characters.'); ok = false; }

      if (!ok) { e.preventDefault(); }
    });
  }


  /* ---------------------------------------------------
     Stop double clicks sending a form twice
     (bound last, so it only runs when validation passed)
     --------------------------------------------------- */
  $('form').on('submit', function (e) {
    if (e.isDefaultPrevented()) { return; }
    $(this).find('button[type=submit]').prop('disabled', true);
    $('button[form="' + this.id + '"]').prop('disabled', true);
  });

});
