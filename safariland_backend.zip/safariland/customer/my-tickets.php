<?php
/**
 * CUSTOMER - My Tickets (READ).
 * Active = paid bookings with a visit date today or later.
 * Past   = earlier visits, or cancelled / refunded bookings.
 * Only this customer's tickets are selected (WHERE b.user_id = ?).
 */
require __DIR__ . '/../includes/customer_init.php';

$stmt = db()->prepare("SELECT t.ticket_code, i.ticket_name, b.reference, b.visit_date, b.status
                       FROM tickets t
                       JOIN booking_items i ON i.id = t.booking_item_id
                       JOIN bookings b      ON b.id = i.booking_id
                       WHERE b.user_id = ?
                       ORDER BY b.visit_date, t.id");
$stmt->execute([$user['id']]);

$active = $past = [];
foreach ($stmt->fetchAll() as $t) {
    if ($t['status'] === 'Paid' && $t['visit_date'] >= date('Y-m-d')) {
        $active[] = $t;
    } else {
        $past[] = $t;
    }
}
$past = array_reverse($past);   // most recent first

/** One ticket row in the design's style. */
function ticket_row(array $t, bool $canDownload): void
{
    ?>
        <div class="ticket-row">
          <div class="ticket <?= ticket_class($t['ticket_name']) ?>">
            <div class="body"><img src="assets/logo.png" alt="SafariLand" /></div>
            <div class="stub"><span><?= e($t['ticket_name']) ?></span></div>
          </div>
          <div class="ticket-meta">
            <p><strong><?= nice_date($t['visit_date'], 'D j M Y') ?></strong></p>
            <p>Ticket <?= e($t['ticket_code']) ?> · <?= e($t['reference']) ?></p>
            <?php if ($t['status'] !== 'Paid'): ?><p class="status-badge status-<?= strtolower(e($t['status'])) ?>"><?= e($t['status']) ?></p><?php endif; ?>
            <?php if ($canDownload): ?>
            <a class="btn-outline" href="ticket.php?code=<?= urlencode($t['ticket_code']) ?>" target="_blank" rel="noopener">Download Ticket</a>
            <?php endif; ?>
          </div>
        </div>
<?php
}

customer_head('My Tickets');
customer_topbar($user);
?>

  <div class="layout">
<?php customer_sidebar('my-tickets'); ?>

    <main class="main has-hero">
      <div class="hero">
        <img src="assets/hero-elephants.png" alt="Elephants crossing a river" />
      </div>

      <h1 class="title">My Tickets</h1>
      <?php customer_flash(); ?>

      <div class="tabs">
        <button class="tab active" data-tab="active">Active Tickets (<?= count($active) ?>)</button>
        <button class="tab" data-tab="past">Past Tickets (<?= count($past) ?>)</button>
      </div>

      <div class="ticket-list" id="tab-active">
        <?php foreach ($active as $t) { ticket_row($t, true); } ?>
        <?php if (!$active): ?>
          <p class="empty-state">You have no upcoming tickets. <a class="view-link" href="park-tickets.php">Book your next visit →</a></p>
        <?php endif; ?>
      </div>

      <div class="ticket-list is-hidden" id="tab-past">
        <?php foreach ($past as $t) { ticket_row($t, false); } ?>
        <?php if (!$past): ?>
          <p class="empty-state">You have no past tickets yet.</p>
        <?php endif; ?>
      </div>
    </main>
  </div>

<?php customer_foot(); ?>
