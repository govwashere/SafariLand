<?php
/**
 * CUSTOMER - Step 3: confirmation (READ the booking just created).
 * The reference is taken from the session, not from the URL.
 */
require __DIR__ . '/../includes/customer_init.php';
require __DIR__ . '/../includes/booking.php';

$ref     = $_SESSION['last_booking'] ?? '';
$booking = $ref ? find_user_booking((int)$user['id'], $ref) : null;
if (!$booking) {
    redirect('my-tickets.php');
}

customer_head('Confirmation');
checkout_header($user, 3, 'my-tickets.php');
?>

  <main class="checkout-main">
    <div class="thanks">
      <div class="thanks-text">
        <h1>Thank You</h1>
        <p>Your Tickets have been successfully purchased.</p>
        <p class="thanks-ref">Booking reference <strong><?= e($booking['reference']) ?></strong> · Visit on <?= nice_date($booking['visit_date'], 'l j F Y') ?> · <?= money($booking['total']) ?></p>
        <small>Your tickets are saved in My Tickets under <?= e($user['email']) ?></small>
      </div>
      <a class="btn-download-lg" href="ticket.php?ref=<?= urlencode($booking['reference']) ?>" target="_blank" rel="noopener">Download Ticket</a>
    </div>
  </main>

<?php customer_foot(false); ?>
