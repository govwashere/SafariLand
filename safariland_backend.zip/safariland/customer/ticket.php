<?php
/**
 * CUSTOMER - Printable e-ticket ("Download Ticket").
 *   ticket.php?code=XXXX  -> one ticket
 *   ticket.php?ref=SL-... -> every ticket of a booking
 * Access control: the query always includes "b.user_id = current user",
 * so changing the code/ref in the URL cannot show someone else's ticket (IDOR).
 * The browser's "Save as PDF" turns the page into a downloadable PDF.
 */
require __DIR__ . '/../includes/customer_init.php';

$code = $_GET['code'] ?? '';
$ref  = $_GET['ref'] ?? '';
$sql  = "SELECT t.ticket_code, i.ticket_name, i.unit_price, b.reference, b.visit_date, b.status, tt.guests
         FROM tickets t
         JOIN booking_items i ON i.id = t.booking_item_id
         JOIN bookings b      ON b.id = i.booking_id
         LEFT JOIN ticket_types tt ON tt.id = i.ticket_type_id
         WHERE b.user_id = ? AND ";

if (is_string($code) && preg_match('/^[A-Z0-9]{12}$/', $code)) {
    $stmt = db()->prepare($sql . 't.ticket_code = ?');
    $stmt->execute([$user['id'], $code]);
} elseif (is_string($ref) && preg_match('/^SL-\d{4}-\d{5}$/', $ref)) {
    $stmt = db()->prepare($sql . 'b.reference = ? ORDER BY t.id');
    $stmt->execute([$user['id'], $ref]);
} else {
    $stmt = null;
}
$tickets = $stmt ? $stmt->fetchAll() : [];

if (!$tickets) {
    http_response_code(404);
    flash('error', 'Ticket not found.');
    redirect('my-tickets.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="robots" content="noindex, nofollow" />
  <title>SafariLand e-Ticket <?= e($tickets[0]['reference']) ?></title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body class="eticket-page">
  <div class="eticket-actions no-print">
    <a class="btn-back" href="my-tickets.php">Back</a>
    <button type="button" class="btn-primary" onclick="window.print()">Print / Save as PDF</button>
  </div>

  <?php foreach ($tickets as $t): ?>
  <article class="eticket">
    <div class="eticket-main">
      <img src="assets/logo.png" alt="SafariLand Nature Park" />
      <div>
        <p class="eticket-type"><?= e($t['ticket_name']) ?></p>
        <p><strong>Holder:</strong> <?= e($user['full_name']) ?></p>
        <p><strong>Visit date:</strong> <?= nice_date($t['visit_date'], 'l j F Y') ?></p>
        <p><strong>Admits:</strong> <?= (int)($t['guests'] ?? 1) ?> guest(s) · <strong>Price:</strong> <?= money($t['unit_price']) ?></p>
        <p><strong>Booking:</strong> <?= e($t['reference']) ?><?= $t['status'] !== 'Paid' ? ' · <strong class="status-cancelled">' . e(strtoupper($t['status'])) . '</strong>' : '' ?></p>
      </div>
    </div>
    <div class="eticket-stub ticket <?= ticket_class($t['ticket_name']) ?>">
      <span class="eticket-code"><?= e($t['ticket_code']) ?></span>
      <small>Show this code at the gate</small>
    </div>
  </article>
  <?php endforeach; ?>
</body>
</html>
