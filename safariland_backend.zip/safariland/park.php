<?php
/** VISITOR - park page (static content; PHP only for shared links/contact). */
require __DIR__ . '/includes/bootstrap.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Explore SafariLand Nature Park and view the park map.">
  <title>The Park | SafariLand Nature Park</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bayon&family=Baskervville+SC&family=Irish+Grover&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body class="park-page">
  <header class="park-header">
    <a class="park-home-button" href="index.php">Home</a>
    <a class="park-logo" href="index.php" aria-label="SafariLand home">
      <img src="images/safariland-logo.png" alt="SafariLand Nature Park">
    </a>
    <a class="park-ticket-button" href="customer/park-tickets.php">Buy Ticket</a>
  </header>

  <main class="park-main">
    <section class="park-intro" aria-labelledby="park-title">
      <div class="park-intro-copy">
        <h1 id="park-title">The Park</h1>
        <p class="park-name">SafariLand</p>
        <p class="park-tagline">
          A Wild World to Explore.<br>
          An Adventure That Brings Nature to Life.
        </p>
        <p>
          Beyond the river and beneath the mountains, a world of discovery is waiting.
          SafariLand is a place where winding trails lead to surprising encounters,
          where animals roam in habitats inspired by the wild, and where every bend
          in the river brings a new story.
        </p>
      </div>

      <div class="park-photo-stack">
        <span class="park-photo-backdrop" aria-hidden="true"></span>
        <img src="images/ThePark1.jpeg" alt="SafariLand Nature Park sign on a stone wall">
      </div>
    </section>

    <section class="park-story">
      <p>
        Set out on an adventure, take on exciting activities, and discover the
        wonders of the natural world at your own pace.
      </p>
      <p>
        But SafariLand is more than a day of fun. It's a journey into a living
        landscape, one that invites you to look closer, learn more, and leave with
        a deeper connection to nature.
      </p>
    </section>

    <section class="park-map-section" aria-labelledby="map-title">
      <h2 id="map-title">The Park &amp; Map</h2>

      <div class="park-map-frame">
        <img src="images/ThePark2.jpeg" alt="Illustrated map of SafariLand, showing park areas and attractions">
      </div>

      <a class="park-view-map" href="map.php">View Map</a>
    </section>
  </main>

  <?php $contactTag = 'footer'; $contactClass = 'park-contact'; include __DIR__ . '/includes/partials/visitor_contact.php'; ?>

  <script src="script.js" defer></script>
</body>
</html>