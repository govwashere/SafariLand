<?php
/**
 * VISITOR - Contact form (CREATE in messages table, read by admin in "Messages").
 * Anti-spam: hidden "website" honeypot field that humans never fill in,
 * plus a 30-second limit between two messages from the same session.
 */
require __DIR__ . '/includes/bootstrap.php';

$errors = [];
$old    = ['name' => '', 'email' => '', 'subject' => '', 'message' => ''];

// Pre-fill for a logged-in customer
if ($u = current_user()) {
    $old['name']  = $u['full_name'];
    $old['email'] = $u['email'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    // Honeypot: bots fill every field. Pretend success, store nothing.
    if (!empty($_POST['website'])) {
        flash('success', 'Thank you! Your message has been sent.');
        redirect('contact.php');
    }

    $v = new Validator($_POST);
    $v->required('name', 'Name')->name('name')
      ->required('email', 'Email')->email('email')
      ->required('subject', 'Subject')->minLength('subject', 3, 'Subject')->maxLength('subject', 120, 'Subject')
      ->required('message', 'Message')->minLength('message', 10, 'Message')->maxLength('message', 2000, 'Message');

    if (!$v->fails() && isset($_SESSION['last_contact']) && time() - $_SESSION['last_contact'] < 30) {
        $v->addError('form', 'Please wait a few seconds before sending another message.');
    }
    foreach ($old as $k => $_) {
        $old[$k] = $v->get($k);
    }

    if (!$v->fails()) {
        db()->prepare('INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)')
            ->execute([$old['name'], $old['email'], $old['subject'], $old['message']]);
        $_SESSION['last_contact'] = time();
        flash('success', 'Thank you! Your message has been sent. We will reply by email.');
        redirect('contact.php');                       // Post/Redirect/Get: no double submit on refresh
    }
    $errors = $v->errors();
}

$pageTitle = 'Contact us';
$indexable = true;                                     // public page, may be indexed
include __DIR__ . '/includes/partials/auth_header.php';
?>
    <h1 class="auth-title">Send us a message</h1>
    <p class="auth-sub">Questions about your visit, group bookings or events? We usually reply within one working day.</p>

    <?php if ($m = get_flash('success')): ?><p class="auth-alert ok" role="status"><?= e($m) ?></p><?php endif; ?>
    <?php if (!empty($errors['form'])): ?><p class="auth-alert error" role="alert"><?= e($errors['form']) ?></p><?php endif; ?>

    <form class="auth-form" method="post" action="contact.php" novalidate data-validate>
      <?= csrf_field() ?>
      <div class="hp-field" aria-hidden="true">
        <label for="website">Leave this empty</label>
        <input id="website" name="website" type="text" tabindex="-1" autocomplete="off">
      </div>

      <div class="auth-field<?= isset($errors['name']) ? ' has-error' : '' ?>">
        <label for="name">Your name</label>
        <input id="name" name="name" type="text" required minlength="2" maxlength="100" autocomplete="name" value="<?= e($old['name']) ?>">
        <?php if (isset($errors['name'])): ?><small class="auth-error"><?= e($errors['name']) ?></small><?php endif; ?>
      </div>
      <div class="auth-field<?= isset($errors['email']) ? ' has-error' : '' ?>">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" required maxlength="150" autocomplete="email" value="<?= e($old['email']) ?>">
        <?php if (isset($errors['email'])): ?><small class="auth-error"><?= e($errors['email']) ?></small><?php endif; ?>
      </div>
      <div class="auth-field<?= isset($errors['subject']) ? ' has-error' : '' ?>">
        <label for="subject">Subject</label>
        <input id="subject" name="subject" type="text" required minlength="3" maxlength="120" value="<?= e($old['subject']) ?>">
        <?php if (isset($errors['subject'])): ?><small class="auth-error"><?= e($errors['subject']) ?></small><?php endif; ?>
      </div>
      <div class="auth-field<?= isset($errors['message']) ? ' has-error' : '' ?>">
        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5" required minlength="10" maxlength="2000"><?= e($old['message']) ?></textarea>
        <?php if (isset($errors['message'])): ?><small class="auth-error"><?= e($errors['message']) ?></small><?php endif; ?>
      </div>

      <button class="green-pill auth-submit" type="submit">Send message</button>
    </form>
<?php include __DIR__ . '/includes/partials/auth_footer.php'; ?>
