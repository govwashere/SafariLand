<?php
/**
 * VISITOR - Attractions list (READ from the attractions table).
 * Only attractions the admin marked "Open" are shown.
 */
require __DIR__ . '/includes/bootstrap.php';

$attractions = db()->query("SELECT id, name, category, description, image FROM attractions
                            WHERE status = 'Open' ORDER BY category, name")->fetchAll();

// DB category -> filter key used by the existing script.js buttons
$filterKey = ['Adventure' => 'adventure', 'Animal' => 'animals'];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Explore attractions at SafariLand Nature Park.">
  <title>Attractions | SafariLand Nature Park</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bayon&family=Baskervville+SC&family=Irish+Grover&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="script.js" defer></script>
</head>
<body class="attractions-page">
  <header class="home-header attractions-header">
    <a class="home-logo" href="index.php" aria-label="SafariLand home">
      <img src="images/safariland-logo.png" alt="SafariLand Nature Park">
    </a>
    <button class="menu-toggle" aria-expanded="false" aria-controls="main-nav">Menu</button>
    <nav id="main-nav" class="home-nav" aria-label="Main navigation">
      <a href="index.php">Home</a>
      <a class="current-page" href="attractions.php" aria-current="page">Attractions</a>
      <a href="park.php">The Park</a>
      <a href="index.php#park-info">Plan Your Visit</a>
      <?php include __DIR__ . '/includes/partials/visitor_account_link.php'; ?>
      <a class="login-pill" href="customer/park-tickets.php">Buy Ticket</a>
    </nav>
  </header>

  <main>
    <section class="attractions-hero" aria-labelledby="attractions-title">
      <h1 id="attractions-title">Explore Our<br>Attractions</h1>
      <p>Fun For All Ages</p>
    </section>

    <section class="attractions-content" aria-label="SafariLand attractions">
      <div class="attraction-filters" role="group" aria-label="Filter attractions by category">
        <button type="button" class="filter-button is-active" data-filter="all" aria-pressed="true">All</button>
        <button type="button" class="filter-button" data-filter="adventure" aria-pressed="false">Adventure</button>
        <button type="button" class="filter-button" data-filter="animals" aria-pressed="false">Animals</button>
      </div>

      <p class="filter-status" aria-live="polite"></p>

      <div class="attraction-grid">
        <?php foreach ($attractions as $a): ?>
        <article class="attraction-card" data-category="<?= e($filterKey[$a['category']] ?? 'all') ?>">
          <img src="<?= e(upload_url($a['image'])) ?>" alt="<?= e($a['name']) ?>">
          <h2><?= e($a['name']) ?></h2>
          <p><?= e(mb_strimwidth((string)$a['description'], 0, 110, '…')) ?></p>
          <a class="attraction-read-more" href="attraction.php?id=<?= (int)$a['id'] ?>">Read More</a>
        </article>
        <?php endforeach; ?>
      </div>
      <?php if (!$attractions): ?>
        <p class="empty-note">No attractions are open at the moment.</p>
      <?php endif; ?>
    </section>
  </main>

  <?php $contactTag = 'footer'; $contactClass = 'attractions-contact'; include __DIR__ . '/includes/partials/visitor_contact.php'; ?>
</body>
</html>
