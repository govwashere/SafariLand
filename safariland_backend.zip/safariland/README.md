# SafariLand Nature Park – Back-end (PHP + MySQL)

Back-end for the three front-ends (Visitor, Customer, Admin). The original HTML/CSS/JS designs
were kept and turned into PHP pages that read from and write to a MySQL database.

---

## 1. How to run it (XAMPP)

1. Copy the whole `safariland` folder into `C:\xampp\htdocs\` (Mac: `/Applications/XAMPP/htdocs/`).
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open **phpMyAdmin** → *Import* → choose `database/safariland.sql` → *Go*.
   (The script creates the `safariland` database. It **drops** an existing one with the same name.)
4. If your MySQL user is not `root` with an empty password, edit `includes/config.php`.
5. Open:
   - Visitor site: <http://localhost/safariland/>
   - Customer area: <http://localhost/safariland/login.php>
   - Admin area: <http://localhost/safariland/admin/login.php>

| Account | Email | Password |
|---|---|---|
| Admin | admin@safariland.mu | Admin@123 |
| Customer | jp@gmail.com | Customer@123 |
| Customer (blocked – cannot log in) | mf@gmail.com | Customer@123 |

Test card for the (simulated) payment: **4242 4242 4242 4242**, any future expiry (e.g. 12/28), any 3-digit CVV.

Requirements: PHP 7.4+ (8.x recommended) with `pdo_mysql` and `fileinfo`, MySQL 5.7+/MariaDB 10.3+.

---

## 2. Folder structure

```
safariland/
├── index.php, attractions.php, attraction.php, park.php, map.php   VISITOR pages (public)
├── contact.php                                                      VISITOR contact form
├── login.php, register.php, logout.php                              accounts
├── styles.css, script.js, images/                                   visitor front-end
├── customer/                CUSTOMER area (login required, role = customer)
│   ├── dashboard.php, park-tickets.php, payment.php, confirmation.php
│   ├── my-tickets.php, ticket.php (printable e-ticket), booking-history.php, booking-details.php
│   ├── my-profile.php, my-review.php
│   └── styles.css, script.js, assets/
├── admin/                   ADMIN area (login required, role = admin)
│   ├── login.php, index.php, attractions.php, tickets.php, events.php,
│   │   customers.php, bookings.php, reviews.php, messages.php, settings.php
│   ├── api/*.php            JSON endpoints used by the admin tables (add / edit / delete)
│   └── assets/              admin CSS + JS (common.js holds the AJAX CRUD helper)
├── includes/                shared PHP – never served to the browser (.htaccess)
│   ├── config.php           database + security settings
│   ├── bootstrap.php        DB (PDO), secure session, CSRF, auth, helpers
│   ├── Validator.php        server-side validation rules
│   ├── upload.php           safe image upload
│   ├── booking.php          cart validation, pricing, booking transaction
│   ├── admin_*.php, customer_init.php, partials/   layouts and helpers
├── database/safariland.sql  schema + sample data
├── uploads/                 images uploaded by admin / customers (no scripts can run here)
└── robots.txt, .htaccess    search-engine and server rules
```

---

## 3. User groups and permissions

| Group | How they get in | What they can do | Enforced by |
|---|---|---|---|
| **Visitor** (not logged in) | – | Browse home, attractions, attraction details, park & map, events, reviews; send a contact message; register | Public pages |
| **Customer** | `register.php` or created by an admin; logs in at `login.php` | Book tickets, pay, download e-tickets, view/cancel bookings, edit profile, photo, password, write/edit/delete own reviews | `require_customer()` on every customer page; every query filtered by `user_id` of the logged-in user |
| **Admin** | Seeded account or created in *Settings → Admin accounts*; logs in at `admin/login.php` | Full CRUD on attractions, ticket types, events, customers, bookings, reviews, messages; park settings | `require_admin()` on every admin page and API; a customer gets **403** |

One `users` table with a `role` column (`customer` / `admin`). The role is set by the server –
registration always creates `customer`, whatever the browser sends. A **Blocked** customer is logged
out on the next request and cannot log back in.

---

## 4. Security decisions

**Server side (PHP)**
- **SQL injection** – every query uses PDO prepared statements (`ATTR_EMULATE_PREPARES = false`).
- **XSS** – every value printed in HTML goes through `e()` (`htmlspecialchars`). Admin JS uses `.text()`, never `.html()`.
- **CSRF** – each POST form has a secret token; AJAX sends it in the `X-CSRF-Token` header; logout links carry it too. Wrong/missing token → HTTP 419.
- **Passwords** – `password_hash()` / `password_verify()` (bcrypt); strength rule (8+ chars, upper, lower, digit) checked client- and server-side.
- **Brute force** – 5 wrong passwords lock the account for 15 minutes; same "Invalid email or password" message whether or not the email exists.
- **Sessions** – HttpOnly + SameSite cookies, strict mode, new session id on login and password change, 30-minute idle timeout, full destroy on logout.
- **Access control / IDOR** – customers only ever see rows `WHERE user_id = <their id>`; changing a booking reference or ticket code in the URL returns "not found".
- **Price tampering** – the browser only sends ticket type ids and quantities; prices, fee and total are recalculated from the database at payment.
- **Payment data** – card number and CVV are validated (format, Luhn checksum, expiry) but **never stored**; only the last 4 digits are kept.
- **Uploads** – real MIME type checked with `finfo` + `getimagesize`, 2 MB limit, random file names, and `uploads/.htaccess` blocks any script.
- **Transactions** – booking + items + tickets are saved all-or-nothing.
- **Data integrity** – a customer with bookings cannot be deleted (block instead); booking items keep a copy of ticket name and price so history survives ticket-type changes.
- **Post/Redirect/Get** after every successful form, so refreshing never re-submits.
- **Open redirects** – the `next` parameter after login only accepts local `.php` paths.
- **Spam** – honeypot field and 30-second limit on the contact form.
- **Headers** – `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`.

**Client side (HTML5 + jQuery)** – `required`, `type=email/tel/date/number`, `pattern`, `min/max`,
`minlength/maxlength`; jQuery shows messages under each field, formats card number/expiry, checks Luhn,
password match, image type/size, and blocks double submits. These are for user comfort only – everything
is validated again in PHP.

**Hidden from search engines** – customer, admin and login pages are kept out of search results in four ways:
1. `<meta name="robots" content="noindex, nofollow">` in their `<head>`;
2. the `X-Robots-Tag: noindex` HTTP header (`no_index()` in PHP and `customer/.htaccess`, `admin/.htaccess`);
3. `robots.txt` disallows `/customer/`, `/admin/`, login/register;
4. the pages require a login, so a crawler only ever gets a redirect.
Public visitor pages stay indexable (they have `meta description`s). `Cache-Control: no-store` on private pages
means the browser's Back button cannot show them after logout.

---

## 5. Functional requirements – status

Legend: **Complete** · **In progress** · **Not Started** · **N/A** (not applicable to that requirement)

### Visitor

| # | Functional requirement | HTML | CSS | Client-side / HTML5 validation | PHP server-side validation | PHP & DB operations (CRUD) |
|---|---|---|---|---|---|---|
| V1 | View home page (park status, closing time, "tickets from" price, featured activities) | Complete | Complete | N/A | N/A | Complete (Read: settings, ticket_types, attractions) |
| V2 | Browse attractions and filter by category | Complete | Complete | N/A | N/A | Complete (Read: attractions, Open only) |
| V3 | View attraction details *(new)* | Complete | Complete | N/A | Complete (id validated as integer, 404 if not found) | Complete (Read) |
| V4 | View upcoming events | Complete | Complete | N/A | N/A | Complete (Read: published events from today) |
| V5 | View park information and map | Complete | Complete | N/A | N/A | N/A (static content) |
| V6 | Read visitor reviews *(new)* | Complete | Complete | N/A | N/A | Complete (Read: visible reviews) |
| V7 | Send a contact message *(new)* | Complete | Complete | Complete | Complete | Complete (Create: messages) |
| V8 | Register a customer account | Complete | Complete | Complete | Complete | Complete (Create: users) |
| V9 | Log in / log out | Complete | Complete | Complete | Complete | Complete (Read + Update: last login, failed attempts) |
| V10 | Reset forgotten password by email | Not Started | Not Started | Not Started | Not Started | Not Started |

### Customer

| # | Functional requirement | HTML | CSS | Client-side / HTML5 validation | PHP server-side validation | PHP & DB operations (CRUD) |
|---|---|---|---|---|---|---|
| C1 | Dashboard (welcome, next visit, upcoming events) | Complete | Complete | N/A | N/A | Complete (Read) |
| C2 | Choose tickets and visit date | Complete | Complete | Complete | Complete | Complete (Read: ticket_types) |
| C3 | Pay for tickets (simulated card payment) | Complete | Complete | Complete | Complete | Complete (Create: bookings, booking_items, tickets) |
| C4 | Booking confirmation | Complete | Complete | N/A | Complete (booking must belong to user) | Complete (Read) |
| C5 | My Tickets – active / past | Complete | Complete | N/A | N/A | Complete (Read) |
| C6 | Download / print e-ticket | Complete | Complete | N/A | Complete (ticket code / reference format + ownership) | Complete (Read) |
| C7 | Booking history + search | Complete | Complete | Complete | Complete | Complete (Read) |
| C8 | Booking details and cancel booking *(new)* | Complete | Complete | Complete (confirm dialog) | Complete (owner, status, date rules) | Complete (Read + Update status) |
| C9 | Edit personal information | Complete | Complete | Complete | Complete | Complete (Update: users) |
| C10 | Change profile picture | Complete | Complete | Complete | Complete | Complete (Update + Delete old file) |
| C11 | Change password | Complete | Complete | Complete | Complete | Complete (Update) |
| C12 | Write / edit / delete my reviews *(new – "My review" link was a placeholder)* | Complete | Complete | Complete | Complete | Complete (Create, Read, Update, Delete) |
| C13 | Email confirmation of booking | N/A | N/A | N/A | N/A | Not Started |

### Admin

| # | Functional requirement | HTML | CSS | Client-side / HTML5 validation | PHP server-side validation | PHP & DB operations (CRUD) |
|---|---|---|---|---|---|---|
| A1 | Admin log in / log out | Complete | Complete | Complete | Complete | Complete (Read + Update) |
| A2 | Dashboard (live totals, recent bookings) | Complete | Complete | N/A | N/A | Complete (Read) |
| A3 | Manage attractions (with image upload) | Complete | Complete | Complete | Complete | Complete (Create, Read, Update, Delete) |
| A4 | Manage ticket types and prices | Complete | Complete | Complete | Complete | Complete (Create, Read, Update, Delete) |
| A5 | Manage events *(page was "not designed yet")* | Complete | Complete | Complete | Complete | Complete (Create, Read, Update, Delete) |
| A6 | Manage customers (add, edit, block, delete) | Complete | Complete | Complete | Complete | Complete (Create, Read, Update, Delete) |
| A7 | Manage bookings (status, visit date, delete) *(page was a copy of Customers)* | Complete | Complete | Complete | Complete | Complete (Read, Update, Delete) |
| A8 | Moderate reviews *(new)* | Complete | Complete | Complete | Complete | Complete (Read, Update, Delete) |
| A9 | Read / delete contact messages *(new)* | Complete | Complete | N/A | Complete | Complete (Read, Update read-flag, Delete) |
| A10 | Park settings (status, closing time, service fee, contact email) *(page was "not designed yet")* | Complete | Complete | Complete | Complete | Complete (Read, Update) |
| A11 | Admin account settings + create another admin *(new)* | Complete | Complete | Complete | Complete | Complete (Create, Update) |
| A12 | Sales reports / export | Not Started | Not Started | Not Started | Not Started | Not Started |

### Changes to the functional requirements – justifications

| Change | Why |
|---|---|
| **Added login & register pages** | The Customer front-end had no way in; booking needs an account so tickets belong to someone. |
| **Added visit date to Park Tickets** | A ticket is only valid for a day; the payment summary showed a fixed date ("15 Oct 2026"). |
| **Prices calculated on the server** | The front-end calculated prices in JavaScript from the URL, which anyone can change. |
| **Added attraction detail page** | "Read More" / "More Details" buttons were placeholder links. |
| **Added contact form + admin Messages** | Visitors could only email; messages are now stored and handled by the admin. |
| **Added reviews (customer CRUD + admin moderation + shown on home)** | "My review" was a placeholder link in the customer sidebar. |
| **Added cancel booking** | Customers need to manage bookings, not just view them. |
| **Built Events and Settings admin pages** | Both were "This page hasn't been designed yet"; events and park status shown to visitors need to be editable. |
| **Rebuilt admin Bookings page** | It was a copy of the Customers page. |
| **Admin can create other admins** | Shows the two user groups being managed from the system. |
| **Notification bell → Messages with unread count** | The bell had no function. |

---

## 6. Database tables

`users` · `attractions` · `ticket_types` · `events` · `bookings` → `booking_items` → `tickets` · `reviews` · `messages` · `settings`

Foreign keys: bookings → users (RESTRICT), booking_items → bookings (CASCADE), booking_items → ticket_types (SET NULL),
tickets → booking_items (CASCADE), reviews → users (CASCADE).
