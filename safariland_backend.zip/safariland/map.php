<?php
/** VISITOR - map page (static content; PHP only for shared links/contact). */
require __DIR__ . '/includes/bootstrap.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="View the full SafariLand Nature Park map.">
  <title>Full Park Map | SafariLand</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bayon&family=Baskervville+SC&family=Irish+Grover&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body class="full-map-page">
  <a class="map-back-button" href="park.php">Back</a>

  <main class="full-map-main">
    <p class="map-eyebrow">Explore SafariLand</p>
    <h1>Full Park Map</h1>
    <p class="map-description">
      Zoom in to explore all zones, attractions and facilities around the park
    </p>

    <a
      class="full-map-image-link"
      href="images/ThePark2.jpeg"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Open the full park map image"
    >
      <img
        src="images/ThePark2.jpeg"
        alt="Full illustrated map of SafariLand, including attractions, facilities and park zones"
      >
    </a>
  </main>
</body>
</html>