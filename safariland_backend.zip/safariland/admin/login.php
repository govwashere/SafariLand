<?php
/**
 * ADMIN - Log in. Only accounts with role = 'admin' can log in here
 * (a customer's correct password is still refused).
 */
require __DIR__ . '/../includes/bootstrap.php';
no_index();

$u = current_user();
if ($u && $u['role'] === 'admin') {
    redirect('index.php');
}

$error = get_flash('info');
$ok    = get_flash('success');
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $v = new Validator($_POST);
    $v->required('email', 'Email')->email('email')->required('password', 'Password');
    $email = $v->get('email');
    if ($v->fails()) {
        $errs  = $v->errors();
        $error = reset($errs) ?: 'Please fill in both fields.';
    } else {
        [$user, $error] = attempt_login($email, (string)$_POST['password'], 'admin');
        if ($user) {
            login_user($user);
            redirect('index.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow, noarchive">
  <title>Log in | SafariLand Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Baskervville:ital,wght@0,400..700;1,400..700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-body">
  <main class="login-card">
    <img src="assets/images/SafariLand_Toucan_Nature_Park_Logo.png" alt="SafariLand Nature Park" class="login-logo">
    <h1>Admin log in</h1>
    <?php if ($ok): ?><p class="alert alert-ok" role="status"><?= e($ok) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="alert alert-error" role="alert"><?= e($error) ?></p><?php endif; ?>
    <form method="post" action="login.php" class="js-validate" novalidate>
      <?= csrf_field() ?>
      <div class="field">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" required maxlength="150" autocomplete="username" value="<?= e($email) ?>">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-primary login-btn">Log in</button>
    </form>
    <a class="panel-link" href="../index.php">← Back to the website</a>
  </main>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/common.js"></script>
</body>
</html>
