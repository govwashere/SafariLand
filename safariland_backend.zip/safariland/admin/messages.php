<?php
/**
 * ADMIN - Messages sent through the visitor Contact form
 * (READ; mark as read = UPDATE; DELETE via api/messages.php).
 */
require __DIR__ . '/../includes/admin_init.php';

$rows = db()->query('SELECT * FROM messages ORDER BY created_at DESC')->fetchAll();

admin_head('Messages');
admin_topbar($admin);
admin_sidebar('messages');
?>
  <main class="content">
    <div class="page-head">
      <div>
        <h1>Messages</h1>
        <p class="lede">Questions sent by visitors through the Contact page.</p>
      </div>
    </div>

    <div class="tabs" role="group" aria-label="Filter messages">
      <button type="button" class="tab js-filter-tab" data-filter="*" aria-pressed="true">All (<span id="countAll"><?= count($rows) ?></span>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Unread" aria-pressed="false">Unread</button>
      <button type="button" class="tab js-filter-tab" data-filter="Read" aria-pressed="false">Read</button>
    </div>

    <div class="table-card">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">From</th>
              <th scope="col" class="t-left">Subject</th>
              <th scope="col">Received</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="messageRows">
<?php foreach ($rows as $m): $read = $m['is_read'] ? 'Read' : 'Unread'; ?>
        <tr data-row class="<?= $m['is_read'] ? '' : 'is-unread' ?>" data-category="<?= $read ?>" data-id="<?= (int)$m['id'] ?>"
            data-name="<?= e($m['name']) ?>" data-email="<?= e($m['email']) ?>" data-subject="<?= e($m['subject']) ?>"
            data-message="<?= e($m['message']) ?>" data-date="<?= e(nice_date($m['created_at'], 'j M Y, H:i')) ?>" data-read="<?= (int)$m['is_read'] ?>">
          <td class="t-left"><span class="cust-name"><?= e($m['name']) ?></span><span class="cust-email"><?= e($m['email']) ?></span></td>
          <td class="t-left"><?= e($m['subject']) ?></td>
          <td><?= e(nice_date($m['created_at'], 'd/m/y')) ?></td>
          <td class="c-read"><?= $read ?></td>
          <td class="actions"><button type="button" class="link-btn js-view">View</button><span aria-hidden="true">/</span><button type="button" class="link-btn js-delete">Delete</button></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="5">No messages.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

<div class="modal-overlay" id="messageModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="msgSubject">
    <h2 id="msgSubject"></h2>
    <p class="modal-note"><span id="msgFrom"></span> · <span id="msgDate"></span></p>
    <p class="message-body" id="msgBody"></p>
    <div class="modal-actions">
      <button type="button" class="btn btn-outline js-close">Close</button>
      <a class="btn btn-primary" id="msgReply" href="#">Reply by email</a>
    </div>
  </div>
</div>

<?php admin_delete_modal('deleteMessageModal', 'Message'); ?>

  </main>
<?php admin_foot(['messages.js']); ?>
