<?php
/**
 * ADMIN - Settings (classic POST forms with Post/Redirect/Get):
 *   park      -> UPDATE settings table (park status, closing time, service fee, contact email)
 *   account   -> UPDATE own name / email
 *   password  -> UPDATE own password (current password required)
 *   new_admin -> CREATE another admin account (user group management)
 */
require __DIR__ . '/../includes/admin_init.php';

$errors = ['park' => [], 'account' => [], 'password' => [], 'new_admin' => []];
$old    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $v = new Validator($_POST);

    if ($action === 'park') {
        $v->required('park_status', 'Park status')->in('park_status', ['Open', 'Closed'], 'park status')
          ->required('closing_time', 'Closing time')->time('closing_time', 'Closing time')
          ->required('service_fee', 'Service fee')->decimal('service_fee', 0, 10000, 'Service fee')
          ->required('contact_email', 'Contact email')->email('contact_email');
        if (!$v->fails()) {
            $stmt = db()->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
                                   ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
            foreach (['park_status', 'closing_time', 'service_fee', 'contact_email'] as $k) {
                $stmt->execute([$k, $v->get($k)]);
            }
            flash('success', 'Park settings saved.');
            redirect('settings.php');
        }
    }

    if ($action === 'account') {
        $v->required('full_name', 'Name')->name('full_name')
          ->required('email', 'Email')->email('email')
          ->unique('email', 'users', 'email', (int)$admin['id'], 'Another account already uses this email.');
        if (!$v->fails()) {
            db()->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?')
                ->execute([$v->get('full_name'), $v->get('email'), $admin['id']]);
            flash('success', 'Your account details have been saved.');
            redirect('settings.php');
        }
    }

    if ($action === 'password') {
        $v->required('current_pw', 'Current password')
          ->required('new_pw', 'New password')->strongPassword('new_pw')
          ->required('confirm_pw', 'Confirm password')->matches('confirm_pw', 'new_pw', 'Passwords do not match.');
        if (!$v->fails() && !password_verify((string)$_POST['current_pw'], $admin['password_hash'])) {
            $v->addError('current_pw', 'Current password is incorrect.');
        }
        if (!$v->fails()) {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($_POST['new_pw'], PASSWORD_DEFAULT), $admin['id']]);
            session_regenerate_id(true);
            flash('success', 'Your password has been changed.');
            redirect('settings.php');
        }
    }

    if ($action === 'new_admin') {
        $v->required('admin_name', 'Name')->name('admin_name')
          ->required('admin_email', 'Email')->email('admin_email')
          ->unique('admin_email', 'users', 'email', null, 'An account with this email already exists.')
          ->required('admin_pw', 'Password')->strongPassword('admin_pw');
        if (!$v->fails()) {
            db()->prepare("INSERT INTO users (full_name, email, password_hash, role, status) VALUES (?, ?, ?, 'admin', 'Active')")
                ->execute([$v->get('admin_name'), $v->get('admin_email'), password_hash($_POST['admin_pw'], PASSWORD_DEFAULT)]);
            flash('success', 'Admin account created for ' . $v->get('admin_email') . '.');
            redirect('settings.php');
        }
    }

    if (isset($errors[$action])) {
        $errors[$action] = $v->errors();
        $old = array_map(fn($x) => is_string($x) ? trim($x) : '', $_POST);
        unset($old['current_pw'], $old['new_pw'], $old['confirm_pw'], $old['admin_pw']);
    }
}

$values = [
    'park_status'   => $old['park_status']   ?? setting('park_status', 'Open'),
    'closing_time'  => $old['closing_time']  ?? setting('closing_time', '20:00'),
    'service_fee'   => $old['service_fee']   ?? setting('service_fee', '100'),
    'contact_email' => $old['contact_email'] ?? setting('contact_email'),
    'full_name'     => $old['full_name']     ?? $admin['full_name'],
    'email'         => $old['email']         ?? $admin['email'],
    'admin_name'    => $old['admin_name']    ?? '',
    'admin_email'   => $old['admin_email']   ?? '',
];
$admins = db()->query("SELECT full_name, email, last_login_at FROM users WHERE role = 'admin' ORDER BY id")->fetchAll();

/** One labelled input with its server error. */
function sfield(string $form, string $name, string $label, string $type, array $errors, array $values, string $attrs = ''): void
{
    $err = $errors[$form][$name] ?? null;
    echo '<div class="field' . ($err ? ' has-error' : '') . '">';
    echo '<label for="' . $name . '">' . e($label) . '</label>';
    echo '<input id="' . $name . '" name="' . $name . '" type="' . $type . '" value="' . e($values[$name] ?? '') . '" ' . $attrs . ($err ? ' aria-invalid="true"' : '') . '>';
    if ($err) {
        echo '<span class="field-error">' . e($err) . '</span>';
    }
    echo '</div>';
}

admin_head('Settings');
admin_topbar($admin);
admin_sidebar('settings');
?>
  <main class="content">
    <div class="page-head">
      <div>
        <h1>Settings</h1>
        <p class="lede">Park and account settings.</p>
      </div>
    </div>
    <?php admin_flash(); ?>

    <div class="settings-grid">
      <section class="panel">
        <div class="panel-head"><h2>Park</h2></div>
        <form method="post" action="settings.php" class="js-validate" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="park">
          <div class="form-grid">
            <div class="field<?= isset($errors['park']['park_status']) ? ' has-error' : '' ?>">
              <label for="park_status">Park status</label>
              <select id="park_status" name="park_status" required>
                <?php foreach (['Open', 'Closed'] as $s): ?>
                <option value="<?= $s ?>"<?= $values['park_status'] === $s ? ' selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
              </select>
              <?php if (isset($errors['park']['park_status'])): ?><span class="field-error"><?= e($errors['park']['park_status']) ?></span><?php endif; ?>
            </div>
            <?php
            sfield('park', 'closing_time', 'Closing time', 'time', $errors, $values, 'required');
            sfield('park', 'service_fee', 'Service fee per booking (Rs)', 'number', $errors, $values, 'required min="0" max="10000" step="0.01"');
            sfield('park', 'contact_email', 'Contact email (shown on the website)', 'email', $errors, $values, 'required maxlength="150"');
            ?>
          </div>
          <div class="modal-actions"><button type="submit" class="btn btn-primary">Save park settings</button></div>
        </form>
      </section>

      <section class="panel">
        <div class="panel-head"><h2>My account</h2></div>
        <form method="post" action="settings.php" class="js-validate" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="account">
          <div class="form-grid">
            <?php
            sfield('account', 'full_name', 'Name', 'text', $errors, $values, 'required maxlength="100"');
            sfield('account', 'email', 'Email', 'email', $errors, $values, 'required maxlength="150"');
            ?>
          </div>
          <div class="modal-actions"><button type="submit" class="btn btn-primary">Save account</button></div>
        </form>
      </section>

      <section class="panel">
        <div class="panel-head"><h2>Change password</h2></div>
        <form method="post" action="settings.php" class="js-validate" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="password">
          <div class="form-grid">
            <?php
            sfield('password', 'current_pw', 'Current password', 'password', $errors, [], 'required autocomplete="current-password"');
            sfield('password', 'new_pw', 'New password', 'password', $errors, [], 'required minlength="8" maxlength="72" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,72}" autocomplete="new-password"');
            sfield('password', 'confirm_pw', 'Confirm new password', 'password', $errors, [], 'required autocomplete="new-password"');
            ?>
          </div>
          <p class="form-hint">8+ characters with an upper-case letter, a lower-case letter and a number.</p>
          <div class="modal-actions"><button type="submit" class="btn btn-primary">Change password</button></div>
        </form>
      </section>

      <section class="panel">
        <div class="panel-head"><h2>Admin accounts</h2></div>
        <ul class="plain-list admin-list">
          <?php foreach ($admins as $a): ?>
          <li><strong><?= e($a['full_name']) ?></strong> – <?= e($a['email']) ?><?= $a['last_login_at'] ? ' · last login ' . nice_date($a['last_login_at'], 'j M Y') : '' ?></li>
          <?php endforeach; ?>
        </ul>
        <form method="post" action="settings.php" class="js-validate" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="new_admin">
          <div class="form-grid">
            <?php
            sfield('new_admin', 'admin_name', 'Name', 'text', $errors, $values, 'required maxlength="100"');
            sfield('new_admin', 'admin_email', 'Email', 'email', $errors, $values, 'required maxlength="150"');
            sfield('new_admin', 'admin_pw', 'Password', 'password', $errors, [], 'required minlength="8" maxlength="72" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,72}" autocomplete="new-password"');
            ?>
          </div>
          <div class="modal-actions"><button type="submit" class="btn btn-mint">+ Add admin</button></div>
        </form>
      </section>
    </div>
  </main>
<?php admin_foot(); ?>
