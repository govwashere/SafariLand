<?php
/**
 * ADMIN - Customers & Purchases (READ here; CREATE/UPDATE/DELETE via api/customers.php).
 * "Total purchases" and "last purchase" are counted from the bookings table.
 */
require __DIR__ . '/../includes/admin_init.php';
require __DIR__ . '/../includes/admin_rows.php';

$rows = array_map('customer_row', db()->query(customer_query())->fetchAll());

admin_head('Customers & Purchases');
admin_topbar($admin);
admin_sidebar('customers');
?>
  <main class="content">
    <div class="page-head">
      <h1>Customers &amp; Purchases</h1>
      <button type="button" class="btn btn-mint js-add">+Add Customer</button>
    </div>

    <div class="tabs" role="group" aria-label="Customer views">
      <button type="button" class="tab js-sort-tab" data-sort="all" aria-pressed="true">All Customers (<span id="countAll"><?= count($rows) ?></span>)</button>
      <button type="button" class="tab js-sort-tab" data-sort="recent" aria-pressed="false">Recent Purchases</button>
      <button type="button" class="tab js-sort-tab" data-sort="top" aria-pressed="false">Top Customers</button>
    </div>

    <div class="toolbar">
      <label class="pill-input">
        <span class="sr-only">Search customers</span>
        <input type="search" class="js-search" placeholder="Search customer ...">
      </label>
      <div class="filter-wrap">
        <button type="button" class="pill-btn js-filter-toggle" aria-expanded="false" aria-controls="filterMenu">Filter</button>
        <div class="filter-menu" id="filterMenu" role="group" aria-label="Filter by status" hidden>
          <button type="button" class="filter-opt" data-status="*" aria-pressed="true">All statuses</button>
          <button type="button" class="filter-opt" data-status="Active" aria-pressed="false">Active</button>
          <button type="button" class="filter-opt" data-status="Blocked" aria-pressed="false">Blocked</button>
        </div>
      </div>
    </div>

    <div class="table-card">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">Customer</th>
              <th scope="col">Contact</th>
              <th scope="col">Total purchases</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="customerRows">
<?php foreach ($rows as $r): ?>
        <tr data-row<?= data_attrs($r) ?>>
          <td class="t-left">
            <span class="cust-name c-name"><?= e($r['name']) ?></span>
            <span class="cust-email c-email"><?= e($r['email']) ?></span>
          </td>
          <td class="c-contact"><?= e($r['contact']) ?></td>
          <td class="c-purchases"><?= (int)$r['purchases'] ?></td>
          <td class="c-status"><?= e($r['status']) ?></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="5">No customers match your search.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <template id="customerRowTpl">
        <tr data-row data-id="" data-name="" data-email="" data-contact="" data-purchases="0" data-status="Active" data-last="" data-order="0">
          <td class="t-left">
            <span class="cust-name c-name"></span>
            <span class="cust-email c-email"></span>
          </td>
          <td class="c-contact"></td>
          <td class="c-purchases">0</td>
          <td class="c-status">Active</td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
    </template>

    <!-- Add / Edit Customer -->
<div class="modal-overlay" id="customerModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="customerModalTitle">
    <h2 id="customerModalTitle">Add Customer</h2>
    <form id="customerForm" novalidate>
      <input type="hidden" name="id">
      <div class="form-grid">
        <div class="field">
          <label for="cuName">Full name</label>
          <input id="cuName" type="text" name="name" required minlength="2" maxlength="100" pattern="[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .'\-]{1,99}">
        </div>
        <div class="field">
          <label for="cuEmail">Email</label>
          <input id="cuEmail" type="email" name="email" required maxlength="150">
        </div>
        <div class="field">
          <label for="cuContact">Contact</label>
          <input id="cuContact" type="tel" name="contact" required pattern="\+?[0-9 ]{7,20}">
        </div>
        <div class="field">
          <label for="cuStatus">Status</label>
          <select id="cuStatus" name="status" required><option value="Active">Active</option><option value="Blocked">Blocked</option></select>
        </div>
      </div>
      <p class="modal-note js-new-only">A temporary password will be generated and shown once, so you can give it to the customer.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline js-close">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<?php admin_delete_modal('deleteCustomerModal', 'Customer'); ?>

  </main>
<?php admin_foot(['customers.js']); ?>
