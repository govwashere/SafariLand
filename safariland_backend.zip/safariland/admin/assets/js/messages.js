$(function () {
  'use strict';
  var $current = null;

  // View a message: fill the modal from the row, then mark it as read on the server
  $('#messageRows').on('click', '.js-view', function () {
    $current = $(this).closest('tr');
    $('#msgFrom').text($current.attr('data-name') + ' <' + $current.attr('data-email') + '>');
    $('#msgSubject').text($current.attr('data-subject'));
    $('#msgDate').text($current.attr('data-date'));
    $('#msgBody').text($current.attr('data-message'));
    $('#msgReply').attr('href', 'mailto:' + encodeURIComponent($current.attr('data-email')) +
      '?subject=' + encodeURIComponent('Re: ' + $current.attr('data-subject')));
    SL.openModal('messageModal', this);

    if ($current.attr('data-read') === '0') {
      var $row = $current;
      SL.post('api/messages.php', { action: 'read', id: $row.attr('data-id') }).done(function () {
        $row.attr({ 'data-read': '1', 'data-category': 'Read' }).removeClass('is-unread').find('.c-read').text('Read');
        var $badge = $('.icon-box .badge');
        var n = (parseInt($badge.text(), 10) || 1) - 1;
        if (n > 0) { $badge.text(n); } else { $badge.remove(); }
      });
    }
  });

  // Delete a message
  $('#messageRows').on('click', '.js-delete', function () {
    $current = $(this).closest('tr');
    SL.openModal('deleteMessageModal', this);
  });
  $('#deleteMessageModal').on('click', '.js-confirm-delete', function () {
    if (!$current) { return; }
    SL.post('api/messages.php', { action: 'delete', id: $current.attr('data-id') })
      .done(function (res) {
        $current.remove();
        $current = null;
        $('#countAll').text(Math.max(0, (parseInt($('#countAll').text(), 10) || 1) - 1));
        SL.applyFilters();
        SL.closeModal();
        SL.toast(res.message);
      })
      .fail(function (xhr) { SL.closeModal(); SL.toast(SL.failMessage(xhr)); });
  });
});
