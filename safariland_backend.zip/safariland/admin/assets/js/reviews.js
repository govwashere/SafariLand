$(function () {
  'use strict';
  SL.crud({
    noun: 'Review',
    endpoint: 'api/reviews.php',
    body: '#reviewRows', form: '#reviewForm', modal: 'reviewModal', title: '#reviewModalTitle',
    deleteModal: 'deleteReviewModal', template: 'reviewRowTpl', count: '#countAll',
    fields: ['status'],
    attrs:  ['id', 'customer', 'rating', 'title', 'comment', 'status', 'date'],
    categoryFrom: 'status',                    // Visible / Hidden tabs
    onOpen: function ($form, $tr) {
      $('.js-review-preview').text('“' + $tr.attr('data-title') + '” – ' + $tr.attr('data-comment'));
    },
    render: function ($tr, d) {
      $tr.find('.c-status').text(d.status);
    }
  });
});
