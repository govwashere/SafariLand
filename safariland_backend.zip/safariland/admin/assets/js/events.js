$(function () {
  'use strict';
  var PLACEHOLDER = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="58"><rect width="100" height="58" fill="#d9d9d9"/></svg>');

  SL.crud({
    noun: 'Event',
    endpoint: 'api/events.php',
    body: '#eventRows', form: '#eventForm', modal: 'eventModal', title: '#eventModalTitle',
    deleteModal: 'deleteEventModal', template: 'eventRowTpl', count: '#countAll',
    fields: ['title', 'tagline', 'eventdate', 'location', 'status', 'description'],
    attrs:  ['id', 'title', 'tagline', 'eventdate', 'datelabel', 'location', 'status', 'description', 'image'],
    categoryFrom: 'status',                    // Published / Draft tabs
    defaults: { status: 'Published', location: 'SafariLand' },
    render: function ($tr, d) {
      $tr.find('.c-name').text(d.title);
      $tr.find('.c-date').text(d.datelabel);
      $tr.find('.c-location').text(d.location);
      $tr.find('.c-status').text(d.status);
      $tr.find('.thumb').attr({ src: d.image || PLACEHOLDER, alt: d.title });
    }
  });
});
