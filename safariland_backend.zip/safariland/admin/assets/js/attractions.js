$(function () {
  'use strict';
  var PLACEHOLDER = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="58"><rect width="100" height="58" fill="#d9d9d9"/></svg>');

  SL.crud({
    noun: 'Attraction',
    endpoint: 'api/attractions.php',
    body: '#attractionRows', form: '#attractionForm', modal: 'attractionModal', title: '#attractionModalTitle',
    deleteModal: 'deleteAttractionModal', template: 'attractionRowTpl', count: '#countAll',
    fields: ['name', 'category', 'price', 'minage', 'minheight', 'duration', 'status', 'description'],
    attrs:  ['id', 'name', 'category', 'price', 'minage', 'minheight', 'duration', 'status', 'description', 'image'],
    defaults: { status: 'Open' },
    // client-side check of the chosen image before it is uploaded
    onOpen: function ($form) {
      $form.find('[name="image"]').off('change.sl').on('change.sl', function () {
        var f = this.files[0];
        if (f && (!/^image\/(jpeg|png|webp|gif)$/.test(f.type) || f.size > 2 * 1024 * 1024)) {
          SL.showServerErrors($form, { image: 'Choose a JPG, PNG, WEBP or GIF image under 2 MB.' });
          this.value = '';
        }
      });
    },
    render: function ($tr, d) {
      $tr.find('.c-name').text(d.name);
      $tr.find('.c-category').text(d.category);
      $tr.find('.c-price').text(d.price);
      $tr.find('.c-status').text(d.status);
      $tr.find('.thumb').attr({ src: d.image || PLACEHOLDER, alt: d.name });
    }
  });
});
