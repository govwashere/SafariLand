$(function () {
  'use strict';
  SL.crud({
    noun: 'Booking',
    endpoint: 'api/bookings.php',
    body: '#bookingRows', form: '#bookingForm', modal: 'bookingModal', title: '#bookingModalTitle',
    deleteModal: 'deleteBookingModal', template: 'bookingRowTpl', count: '#countAll',
    fields: ['status', 'visitdate'],
    attrs:  ['id', 'reference', 'customer', 'email', 'visitdate', 'visitlabel', 'items', 'total', 'status', 'created'],
    categoryFrom: 'status',                    // Paid / Cancelled / Refunded tabs
    onOpen: function ($form, $tr) {
      $('.js-booking-summary').text($tr.attr('data-reference') + ' – ' + $tr.attr('data-customer') + ' – ' + $tr.attr('data-items'));
    },
    render: function ($tr, d) {
      $tr.find('.c-visit').text(d.visitlabel);
      $tr.find('.c-total').text(d.total);
      $tr.find('.c-status').text(d.status);
    }
  });
});
