<?php
/**
 * ADMIN - Bookings (READ here; UPDATE status/date and DELETE via api/bookings.php).
 * Bookings are only created by customers through the checkout, so there is no "Add".
 */
require __DIR__ . '/../includes/admin_init.php';
require __DIR__ . '/../includes/admin_rows.php';

$rows = array_map('booking_row', db()->query(booking_query())->fetchAll());
$counts = array_count_values(array_column($rows, 'status'));

admin_head('Bookings');
admin_topbar($admin);
admin_sidebar('bookings');
?>
  <main class="content">
    <div class="page-head">
      <h1>Bookings</h1>
    </div>

    <div class="tabs" role="group" aria-label="Filter bookings by status">
      <button type="button" class="tab js-filter-tab" data-filter="*" aria-pressed="true">All Bookings (<span id="countAll"><?= count($rows) ?></span>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Paid" aria-pressed="false">Paid (<?= $counts['Paid'] ?? 0 ?>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Cancelled" aria-pressed="false">Cancelled (<?= $counts['Cancelled'] ?? 0 ?>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Refunded" aria-pressed="false">Refunded (<?= $counts['Refunded'] ?? 0 ?>)</button>
    </div>

    <div class="toolbar">
      <label class="pill-input">
        <span class="sr-only">Search bookings</span>
        <input type="search" class="js-search" placeholder="Search reference, customer or ticket ...">
      </label>
    </div>

    <div class="table-card">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">Booking</th>
              <th scope="col" class="t-left">Customer</th>
              <th scope="col">Visit date</th>
              <th scope="col" class="t-left">Tickets</th>
              <th scope="col">(Rs) Total</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="bookingRows">
<?php foreach ($rows as $r): ?>
        <tr data-row data-category="<?= e($r['status']) ?>"<?= data_attrs($r) ?>>
          <td class="t-left"><span class="cust-name c-ref"><?= e($r['reference']) ?></span><span class="cust-email">Booked <?= e($r['created']) ?></span></td>
          <td class="t-left"><span class="cust-name c-customer"><?= e($r['customer']) ?></span><span class="cust-email c-email"><?= e($r['email']) ?></span></td>
          <td class="c-visit"><?= e($r['visitlabel']) ?></td>
          <td class="t-left c-items"><?= e($r['items']) ?></td>
          <td class="c-total"><?= e($r['total']) ?></td>
          <td class="c-status"><?= e($r['status']) ?></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="7">No bookings match your search.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <template id="bookingRowTpl"><tr data-row><td></td></tr></template>

    <!-- Edit Booking -->
<div class="modal-overlay" id="bookingModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="bookingModalTitle">
    <h2 id="bookingModalTitle">Edit Booking</h2>
    <p class="modal-note js-booking-summary"></p>
    <form id="bookingForm" novalidate>
      <input type="hidden" name="id">
      <div class="form-grid">
        <div class="field">
          <label for="bkStatus">Status</label>
          <select id="bkStatus" name="status" required><option value="Paid">Paid</option><option value="Cancelled">Cancelled</option><option value="Refunded">Refunded</option></select>
        </div>
        <div class="field">
          <label for="bkVisit">Visit date</label>
          <input id="bkVisit" type="date" name="visitdate" required>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline js-close">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<?php admin_delete_modal('deleteBookingModal', 'Booking'); ?>

  </main>
<?php admin_foot(['bookings.js']); ?>
