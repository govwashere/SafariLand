<?php
/**
 * ADMIN - Reviews moderation (READ; UPDATE visibility and DELETE via api/reviews.php).
 * Hidden reviews disappear from the visitor home page.
 */
require __DIR__ . '/../includes/admin_init.php';
require __DIR__ . '/../includes/admin_rows.php';

$rows = array_map('review_row', db()->query('SELECT r.*, u.full_name FROM reviews r JOIN users u ON u.id = r.user_id
                                             ORDER BY r.created_at DESC')->fetchAll());

admin_head('Reviews');
admin_topbar($admin);
admin_sidebar('reviews');
?>
  <main class="content">
    <div class="page-head">
      <div>
        <h1>Reviews</h1>
        <p class="lede">Hide reviews that break the rules; visible ones are shown on the home page.</p>
      </div>
    </div>

    <div class="tabs" role="group" aria-label="Filter reviews">
      <button type="button" class="tab js-filter-tab" data-filter="*" aria-pressed="true">All (<span id="countAll"><?= count($rows) ?></span>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Visible" aria-pressed="false">Visible</button>
      <button type="button" class="tab js-filter-tab" data-filter="Hidden" aria-pressed="false">Hidden</button>
    </div>

    <div class="table-card">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">Customer</th>
              <th scope="col">Rating</th>
              <th scope="col" class="t-left">Review</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="reviewRows">
<?php foreach ($rows as $r): ?>
        <tr data-row data-category="<?= e($r['status']) ?>"<?= data_attrs($r) ?>>
          <td class="t-left"><span class="cust-name"><?= e($r['customer']) ?></span><span class="cust-email"><?= e($r['date']) ?></span></td>
          <td class="stars-cell" aria-label="<?= (int)$r['rating'] ?> out of 5"><?= str_repeat('★', (int)$r['rating']) . str_repeat('☆', 5 - (int)$r['rating']) ?></td>
          <td class="t-left"><strong><?= e($r['title']) ?></strong><br><span class="review-text"><?= e($r['comment']) ?></span></td>
          <td class="c-status"><?= e($r['status']) ?></td>
          <td class="actions"><?= admin_row_actions(true, 'Moderate') ?></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="5">No reviews match your search.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <template id="reviewRowTpl"><tr data-row><td></td></tr></template>

<div class="modal-overlay" id="reviewModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="reviewModalTitle">
    <h2 id="reviewModalTitle">Moderate Review</h2>
    <p class="modal-note js-review-preview"></p>
    <form id="reviewForm" novalidate>
      <input type="hidden" name="id">
      <div class="form-grid">
        <div class="field">
          <label for="rvStatus">Visibility</label>
          <select id="rvStatus" name="status" required><option value="Visible">Visible</option><option value="Hidden">Hidden</option></select>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline js-close">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<?php admin_delete_modal('deleteReviewModal', 'Review'); ?>

  </main>
<?php admin_foot(['reviews.js']); ?>
