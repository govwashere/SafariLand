<?php
/**
 * ADMIN - Events (READ here; CREATE/UPDATE/DELETE via api/events.php).
 * Published events dated today or later appear on the visitor home page
 * and on the customer dashboard.
 */
require __DIR__ . '/../includes/admin_init.php';
require __DIR__ . '/../includes/admin_rows.php';

$rows = array_map('event_row', db()->query('SELECT * FROM events ORDER BY event_date DESC')->fetchAll());
$today = date('Y-m-d');

admin_head('Events');
admin_topbar($admin);
admin_sidebar('events');
?>
  <main class="content">
    <div class="page-head">
      <div>
        <h1>Events</h1>
        <p class="lede">Create and manage park events here.</p>
      </div>
      <button type="button" class="btn btn-mint js-add">+ Create Event</button>
    </div>

    <div class="tabs" role="group" aria-label="Filter events">
      <button type="button" class="tab js-filter-tab" data-filter="*" aria-pressed="true">All (<span id="countAll"><?= count($rows) ?></span>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Published" aria-pressed="false">Published</button>
      <button type="button" class="tab js-filter-tab" data-filter="Draft" aria-pressed="false">Draft</button>
    </div>

    <div class="table-card">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">Event</th>
              <th scope="col">Date</th>
              <th scope="col">Location</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="eventRows">
<?php foreach ($rows as $r): ?>
        <tr data-row data-category="<?= e($r['status']) ?>"<?= data_attrs($r) ?>>
          <td class="t-left">
            <div class="attr-cell">
              <img class="thumb" src="<?= e($r['image']) ?>" alt="<?= e($r['title']) ?>">
              <span class="c-name"><?= e($r['title']) ?></span>
            </div>
          </td>
          <td class="c-date"><?= e($r['datelabel']) ?><?= $r['eventdate'] < $today ? ' <small class="muted">(past)</small>' : '' ?></td>
          <td class="c-location"><?= e($r['location']) ?></td>
          <td class="c-status"><?= e($r['status']) ?></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="5">No events match your search.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <template id="eventRowTpl">
        <tr data-row data-category="" data-id="" data-title="" data-tagline="" data-eventdate="" data-datelabel="" data-location="" data-status="" data-description="" data-image="">
          <td class="t-left">
            <div class="attr-cell">
              <img class="thumb" src="" alt="">
              <span class="c-name"></span>
            </div>
          </td>
          <td class="c-date"></td>
          <td class="c-location"></td>
          <td class="c-status"></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
    </template>

<div class="modal-overlay" id="eventModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="eventModalTitle">
    <h2 id="eventModalTitle">Add Event</h2>
    <form id="eventForm" novalidate enctype="multipart/form-data">
      <input type="hidden" name="id">
      <div class="form-grid">
        <div class="field">
          <label for="evTitle">Event title</label>
          <input id="evTitle" type="text" name="title" required minlength="3" maxlength="120">
        </div>
        <div class="field">
          <label for="evTagline">Tagline</label>
          <input id="evTagline" type="text" name="tagline" maxlength="160">
        </div>
        <div class="field">
          <label for="evDate">Event date</label>
          <input id="evDate" type="date" name="eventdate" required min="2020-01-01" max="2035-12-31">
        </div>
        <div class="field">
          <label for="evLocation">Location</label>
          <input id="evLocation" type="text" name="location" required maxlength="120">
        </div>
        <div class="field">
          <label for="evStatus">Status</label>
          <select id="evStatus" name="status" required><option value="Published">Published</option><option value="Draft">Draft</option></select>
        </div>
        <div class="field">
          <label for="evImage">Image (JPG/PNG/WEBP, max 2 MB)</label>
          <input id="evImage" type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif">
        </div>
        <div class="field field--full">
          <label for="evDescription">Description</label>
          <textarea id="evDescription" name="description" rows="3" required minlength="10" maxlength="2000"></textarea>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline js-close">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<?php admin_delete_modal('deleteEventModal', 'Event'); ?>

  </main>
<?php admin_foot(['events.js']); ?>
