<?php
/**
 * ADMIN - Manage Attraction (READ here; CREATE/UPDATE/DELETE via api/attractions.php).
 */
require __DIR__ . '/../includes/admin_init.php';
require __DIR__ . '/../includes/admin_rows.php';

$rows = array_map('attraction_row', db()->query('SELECT * FROM attractions ORDER BY id')->fetchAll());

admin_head('Manage Attraction');
admin_topbar($admin);
admin_sidebar('attractions');
?>
  <main class="content">
    <div class="page-head">
      <h1>Manage Attraction</h1>
      <button type="button" class="btn btn-mint js-add">+ Add Attraction</button>
    </div>

    <div class="tabs" role="group" aria-label="Filter attractions">
      <button type="button" class="tab js-filter-tab" data-filter="*" aria-pressed="true">All (<span id="countAll"><?= count($rows) ?></span>)</button>
      <button type="button" class="tab js-filter-tab" data-filter="Adventure" aria-pressed="false">Adventure</button>
      <button type="button" class="tab js-filter-tab" data-filter="Animal" aria-pressed="false">Animals</button>
    </div>

    <div class="table-card">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">Attraction</th>
              <th scope="col">Category</th>
              <th scope="col">(Rs) Price</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="attractionRows">
<?php foreach ($rows as $r): ?>
        <tr data-row<?= data_attrs($r) ?>>
          <td class="t-left">
            <div class="attr-cell">
              <img class="thumb" src="<?= e($r['image']) ?>" alt="<?= e($r['name']) ?>">
              <span class="c-name"><?= e($r['name']) ?></span>
            </div>
          </td>
          <td class="c-category"><?= e($r['category']) ?></td>
          <td class="c-price"><?= e($r['price']) ?></td>
          <td class="c-status"><?= e($r['status']) ?></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="5">No attractions match your search.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <template id="attractionRowTpl">
        <tr data-row data-id="" data-name="" data-category="" data-price="" data-status="" data-minage="" data-minheight="" data-duration="" data-description="" data-image="">
          <td class="t-left">
            <div class="attr-cell">
              <img class="thumb" src="" alt="">
              <span class="c-name"></span>
            </div>
          </td>
          <td class="c-category"></td>
          <td class="c-price"></td>
          <td class="c-status"></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
    </template>

    <!-- Add / Edit Attraction -->
<div class="modal-overlay" id="attractionModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="attractionModalTitle">
    <h2 id="attractionModalTitle">Add Attraction</h2>
    <form id="attractionForm" novalidate enctype="multipart/form-data">
      <input type="hidden" name="id">
      <div class="form-grid">
        <div class="field">
          <label for="attName">Attraction Name</label>
          <input id="attName" type="text" name="name" required minlength="2" maxlength="100">
        </div>
        <div class="field">
          <label for="attCategory">Category</label>
          <select id="attCategory" name="category" required><option value="">Select category</option><option value="Adventure">Adventure</option><option value="Animal">Animal</option></select>
        </div>
        <div class="field">
          <label for="attMinage">Minimum Age (years)</label>
          <input id="attMinage" type="number" name="minage" min="0" max="99" step="1">
        </div>
        <div class="field">
          <label for="attMinheight">Minimum height (cm)</label>
          <input id="attMinheight" type="number" name="minheight" min="0" max="250" step="1">
        </div>
        <div class="field">
          <label for="attDuration">Duration (minutes)</label>
          <input id="attDuration" type="number" name="duration" min="0" max="600" step="1">
        </div>
        <div class="field">
          <label for="attPrice">Price (Rs)</label>
          <input id="attPrice" type="number" name="price" required min="0" max="100000" step="0.01">
        </div>
        <div class="field">
          <label for="attStatus">Availability</label>
          <select id="attStatus" name="status" required><option value="Open">Open</option><option value="Closed">Closed</option></select>
        </div>
        <div class="field">
          <label for="attImage">Image (JPG/PNG/WEBP, max 2 MB)</label>
          <input id="attImage" type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif">
        </div>
        <div class="field field--full">
          <label for="attDescription">Description</label>
          <textarea id="attDescription" name="description" rows="3" maxlength="1000"></textarea>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline js-close">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<?php admin_delete_modal('deleteAttractionModal', 'Attraction'); ?>

  </main>
<?php admin_foot(['attractions.js']); ?>
