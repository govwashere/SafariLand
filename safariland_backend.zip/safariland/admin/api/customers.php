<?php
/**
 * ADMIN API - customers: CREATE / UPDATE / DELETE.
 * Rules:
 *  - admins can only manage role = 'customer' accounts here (never other admins)
 *  - a new customer gets a random temporary password (shown once, stored hashed)
 *  - a customer with bookings cannot be deleted (we keep sales records) -> block instead
 */
require __DIR__ . '/../../includes/admin_api.php';
require __DIR__ . '/../../includes/admin_rows.php';

$id = posted_id();

/** Load a CUSTOMER by id (404 for admins or unknown ids). */
function find_customer(int $id): array
{
    $stmt = db()->prepare(customer_query('u.id = ?'));
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        json_response(['ok' => false, 'message' => 'Customer not found.'], 404);
    }
    return $row;
}

if ($action === 'delete') {
    $c = find_customer($id ?? 0);
    $count = db()->prepare('SELECT COUNT(*) FROM bookings WHERE user_id = ?');
    $count->execute([$c['id']]);
    if ($count->fetchColumn() > 0) {
        json_response(['ok' => false, 'message' => $c['full_name'] . ' has bookings and cannot be deleted. Set the status to Blocked instead.'], 409);
    }
    db()->prepare("DELETE FROM users WHERE id = ? AND role = 'customer'")->execute([$c['id']]);
    delete_upload($c['profile_photo']);
    json_response(['ok' => true, 'message' => 'Customer deleted.']);
}

if ($action === 'save') {
    if ($id) {
        find_customer($id);
    }
    $v = new Validator($_POST);
    $v->required('name', 'Full name')->name('name')
      ->required('email', 'Email')->email('email')
      ->unique('email', 'users', 'email', $id, 'Another account already uses this email.')
      ->required('contact', 'Contact')->phone('contact')
      ->required('status', 'Status')->in('status', ['Active', 'Blocked'], 'status');
    if ($v->fails()) {
        fail_validation($v->errors());
    }

    $message = 'Customer saved.';
    if ($id) {
        db()->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, status = ? WHERE id = ? AND role = 'customer'")
            ->execute([$v->get('name'), $v->get('email'), $v->get('contact'), $v->get('status'), $id]);
    } else {
        // Temporary password: 10 random characters + guaranteed upper/lower/digit
        $temp = substr(str_replace(['/', '+', '='], '', base64_encode(random_bytes(12))), 0, 8) . 'A7';
        db()->prepare("INSERT INTO users (full_name, email, phone, status, role, password_hash) VALUES (?, ?, ?, ?, 'customer', ?)")
            ->execute([$v->get('name'), $v->get('email'), $v->get('contact'), $v->get('status'), password_hash($temp, PASSWORD_DEFAULT)]);
        $id = (int)db()->lastInsertId();
        $message = 'Customer saved. Temporary password: ' . $temp . ' (ask them to change it after logging in).';
    }
    json_response(['ok' => true, 'row' => customer_row(find_customer($id)), 'message' => $message]);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
