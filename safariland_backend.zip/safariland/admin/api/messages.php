<?php
/**
 * ADMIN API - contact messages: mark as read (UPDATE) and DELETE.
 */
require __DIR__ . '/../../includes/admin_api.php';

$id  = posted_id();
$msg = find_or_404('messages', $id ?? 0);

if ($action === 'read') {
    db()->prepare('UPDATE messages SET is_read = 1 WHERE id = ?')->execute([$msg['id']]);
    json_response(['ok' => true]);
}

if ($action === 'delete') {
    db()->prepare('DELETE FROM messages WHERE id = ?')->execute([$msg['id']]);
    json_response(['ok' => true, 'message' => 'Message deleted.']);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
