<?php
/**
 * ADMIN API - bookings: UPDATE (status, visit date) and DELETE.
 * Deleting a booking also deletes its items and tickets (ON DELETE CASCADE).
 */
require __DIR__ . '/../../includes/admin_api.php';
require __DIR__ . '/../../includes/admin_rows.php';

$id = posted_id();

function find_booking(int $id): array
{
    $stmt = db()->prepare(booking_query('b.id = ?'));
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        json_response(['ok' => false, 'message' => 'Booking not found.'], 404);
    }
    return $row;
}

if ($action === 'delete') {
    $b = find_booking($id ?? 0);
    db()->prepare('DELETE FROM bookings WHERE id = ?')->execute([$b['id']]);
    json_response(['ok' => true, 'message' => 'Booking ' . $b['reference'] . ' deleted.']);
}

if ($action === 'save') {
    if (!$id) {
        json_response(['ok' => false, 'message' => 'Bookings are created by customers at checkout.'], 400);
    }
    $b = find_booking($id);
    $v = new Validator($_POST);
    $v->required('status', 'Status')->in('status', ['Paid', 'Cancelled', 'Refunded'], 'status')
      ->required('visitdate', 'Visit date')->date('visitdate', '2020-01-01', date('Y-m-d', strtotime('+' . MAX_DAYS_AHEAD . ' days')), 'Visit date');
    // Moving a visit is only allowed to today or later
    if ($v->get('visitdate') !== $b['visit_date'] && $v->get('visitdate') < date('Y-m-d')) {
        $v->addError('visitdate', 'A visit can only be moved to today or a later date.');
    }
    if ($v->fails()) {
        fail_validation($v->errors());
    }
    db()->prepare('UPDATE bookings SET status = ?, visit_date = ? WHERE id = ?')
        ->execute([$v->get('status'), $v->get('visitdate'), $id]);
    json_response(['ok' => true, 'row' => booking_row(find_booking($id)), 'message' => 'Booking ' . $b['reference'] . ' updated.']);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
