<?php
/**
 * ADMIN API - events: CREATE / UPDATE / DELETE.
 */
require __DIR__ . '/../../includes/admin_api.php';
require __DIR__ . '/../../includes/admin_rows.php';

$id = posted_id();

if ($action === 'delete') {
    $row = find_or_404('events', $id ?? 0);
    db()->prepare('DELETE FROM events WHERE id = ?')->execute([$row['id']]);
    delete_upload($row['image']);
    json_response(['ok' => true, 'message' => 'Event "' . $row['title'] . '" deleted.']);
}

if ($action === 'save') {
    $existing = $id ? find_or_404('events', $id) : null;

    $v = new Validator($_POST);
    $v->required('title', 'Event title')->minLength('title', 3, 'Event title')->maxLength('title', 120, 'Event title')
      ->maxLength('tagline', 160, 'Tagline')
      ->required('eventdate', 'Event date')->date('eventdate', '2020-01-01', '2035-12-31', 'Event date')
      ->required('location', 'Location')->maxLength('location', 120, 'Location')
      ->required('status', 'Status')->in('status', ['Published', 'Draft'], 'status')
      ->required('description', 'Description')->minLength('description', 10, 'Description')->maxLength('description', 2000, 'Description');

    // A brand-new event cannot be created in the past
    if (!$existing && $v->get('eventdate') !== '' && $v->get('eventdate') < date('Y-m-d')) {
        $v->addError('eventdate', 'A new event cannot be in the past.');
    }

    [$image, $imgErr] = upload_image($_FILES['image'] ?? null, 'events');
    if ($imgErr) {
        $v->addError('image', $imgErr);
    }
    if ($v->fails()) {
        delete_upload($image);
        fail_validation($v->errors());
    }

    $values = [$v->get('title'), $v->get('tagline') ?: null, $v->get('description'), $v->get('eventdate'), $v->get('location'), $v->get('status')];
    if ($existing) {
        $image = $image ?? $existing['image'];
        db()->prepare('UPDATE events SET title=?, tagline=?, description=?, event_date=?, location=?, status=?, image=? WHERE id = ?')
            ->execute([...$values, $image, $id]);
        if ($image !== $existing['image']) {
            delete_upload($existing['image']);
        }
    } else {
        db()->prepare('INSERT INTO events (title, tagline, description, event_date, location, status, image) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([...$values, $image]);
        $id = (int)db()->lastInsertId();
    }
    json_response(['ok' => true, 'row' => event_row(find_or_404('events', $id)), 'message' => 'Event saved.']);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
