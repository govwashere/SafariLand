<?php
/**
 * ADMIN API - ticket types: CREATE / UPDATE / DELETE.
 * Deleting a type keeps old bookings intact: booking_items store a copy
 * of the name and price, and the foreign key is set to NULL.
 */
require __DIR__ . '/../../includes/admin_api.php';
require __DIR__ . '/../../includes/admin_rows.php';

$id = posted_id();

if ($action === 'delete') {
    $row = find_or_404('ticket_types', $id ?? 0);
    $left = (int)db()->query('SELECT COUNT(*) FROM ticket_types')->fetchColumn();
    if ($left <= 1) {
        json_response(['ok' => false, 'message' => 'You must keep at least one ticket type for sale.'], 409);
    }
    db()->prepare('DELETE FROM ticket_types WHERE id = ?')->execute([$row['id']]);
    json_response(['ok' => true, 'message' => 'Ticket type "' . $row['name'] . '" deleted.']);
}

if ($action === 'save') {
    if ($id) {
        find_or_404('ticket_types', $id);
    }
    // normalise line endings so each line is one bullet
    $_POST['description'] = str_replace(["\r\n", "\r"], "\n", (string)($_POST['description'] ?? ''));

    $v = new Validator($_POST);
    $v->required('name', 'Ticket type')->minLength('name', 2, 'Ticket type')->maxLength('name', 60, 'Ticket type')
      ->unique('name', 'ticket_types', 'name', $id, 'A ticket type with this name already exists.')
      ->required('price', 'Price')->decimal('price', 1, 100000, 'Price')
      ->required('description', 'Description')->maxLength('description', 1000, 'Description')
      ->required('guests', 'Included guests')->integer('guests', 1, 20, 'Included guests');
    if ($v->fails()) {
        fail_validation($v->errors());
    }

    $values = [$v->get('name'), $v->get('price'), (int)$v->get('guests'), $v->get('description')];
    if ($id) {
        db()->prepare('UPDATE ticket_types SET name = ?, price = ?, guests = ?, description = ? WHERE id = ?')
            ->execute([...$values, $id]);
    } else {
        db()->prepare('INSERT INTO ticket_types (name, price, guests, description) VALUES (?, ?, ?, ?)')->execute($values);
        $id = (int)db()->lastInsertId();
    }
    json_response(['ok' => true, 'row' => ticket_row(find_or_404('ticket_types', $id)), 'message' => 'Ticket type saved.']);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
