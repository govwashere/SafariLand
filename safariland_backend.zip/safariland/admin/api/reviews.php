<?php
/**
 * ADMIN API - reviews: UPDATE visibility and DELETE.
 * The admin cannot rewrite a customer's words - only show/hide or delete them.
 */
require __DIR__ . '/../../includes/admin_api.php';
require __DIR__ . '/../../includes/admin_rows.php';

$id = posted_id();

function find_review(int $id): array
{
    $stmt = db()->prepare('SELECT r.*, u.full_name FROM reviews r JOIN users u ON u.id = r.user_id WHERE r.id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        json_response(['ok' => false, 'message' => 'Review not found.'], 404);
    }
    return $row;
}

if ($action === 'delete') {
    $r = find_review($id ?? 0);
    db()->prepare('DELETE FROM reviews WHERE id = ?')->execute([$r['id']]);
    json_response(['ok' => true, 'message' => 'Review deleted.']);
}

if ($action === 'save' && $id) {
    find_review($id);
    $v = new Validator($_POST);
    $v->required('status', 'Visibility')->in('status', ['Visible', 'Hidden'], 'visibility');
    if ($v->fails()) {
        fail_validation($v->errors());
    }
    db()->prepare('UPDATE reviews SET status = ? WHERE id = ?')->execute([$v->get('status'), $id]);
    json_response(['ok' => true, 'row' => review_row(find_review($id)), 'message' => 'Review is now ' . strtolower($v->get('status')) . '.']);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
