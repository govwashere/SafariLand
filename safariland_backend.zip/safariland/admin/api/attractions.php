<?php
/**
 * ADMIN API - attractions: CREATE / UPDATE (action=save) and DELETE (action=delete).
 */
require __DIR__ . '/../../includes/admin_api.php';
require __DIR__ . '/../../includes/admin_rows.php';

$id = posted_id();

if ($action === 'delete') {
    $row = find_or_404('attractions', $id ?? 0);
    db()->prepare('DELETE FROM attractions WHERE id = ?')->execute([$row['id']]);
    delete_upload($row['image']);
    json_response(['ok' => true, 'message' => 'Attraction "' . $row['name'] . '" deleted.']);
}

if ($action === 'save') {
    $existing = $id ? find_or_404('attractions', $id) : null;

    $v = new Validator($_POST);
    $v->required('name', 'Attraction name')->minLength('name', 2, 'Attraction name')->maxLength('name', 100, 'Attraction name')
      ->required('category', 'Category')->in('category', ['Adventure', 'Animal'], 'category')
      ->integer('minage', 0, 99, 'Minimum age')
      ->integer('minheight', 0, 250, 'Minimum height')
      ->integer('duration', 0, 600, 'Duration')
      ->required('price', 'Price')->decimal('price', 0, 100000, 'Price')
      ->required('status', 'Availability')->in('status', ['Open', 'Closed'], 'availability')
      ->maxLength('description', 1000, 'Description');

    [$image, $imgErr] = upload_image($_FILES['image'] ?? null, 'attractions');
    if ($imgErr) {
        $v->addError('image', $imgErr);
    }
    if ($v->fails()) {
        delete_upload($image);
        fail_validation($v->errors());
    }

    $values = [
        $v->get('name'), $v->get('category'), $v->get('price'),
        (int)$v->get('minage', 0), (int)$v->get('minheight', 0), (int)$v->get('duration', 0),
        $v->get('status'), $v->get('description'),
    ];

    if ($existing) {
        $image = $image ?? $existing['image'];          // keep the old picture if none uploaded
        db()->prepare('UPDATE attractions SET name=?, category=?, price=?, min_age=?, min_height=?, duration=?, status=?, description=?, image=?
                       WHERE id = ?')->execute([...$values, $image, $id]);
        if ($image !== $existing['image']) {
            delete_upload($existing['image']);
        }
    } else {
        db()->prepare('INSERT INTO attractions (name, category, price, min_age, min_height, duration, status, description, image)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute([...$values, $image]);
        $id = (int)db()->lastInsertId();
    }

    json_response(['ok' => true, 'row' => attraction_row(find_or_404('attractions', $id)), 'message' => 'Attraction saved.']);
}

json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
