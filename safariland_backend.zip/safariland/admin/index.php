<?php
/**
 * ADMIN - Dashboard: live figures from the database.
 */
require __DIR__ . '/../includes/admin_init.php';

/** "+12% from last week" style note comparing the last 7 days with the 7 days before. */
function week_change(string $table, string $where): string
{
    $sql = "SELECT
              SUM(created_at >= NOW() - INTERVAL 7 DAY) AS this_week,
              SUM(created_at <  NOW() - INTERVAL 7 DAY AND created_at >= NOW() - INTERVAL 14 DAY) AS last_week
            FROM `$table` WHERE $where";
    $r = db()->query($sql)->fetch();
    $now = (int)$r['this_week'];
    $before = (int)$r['last_week'];
    if ($before === 0) {
        return $now > 0 ? "+$now new this week" : 'No change from last week';
    }
    $pct = round(($now - $before) / $before * 100);
    return ($pct >= 0 ? '+' : '') . $pct . '% from last week';
}

$totalBookings  = (int)db()->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$totalCustomers = (int)db()->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$upcoming       = (int)db()->query("SELECT COUNT(*) FROM events WHERE status = 'Published' AND event_date >= CURDATE()")->fetchColumn();
$thisMonth      = (int)db()->query("SELECT COUNT(*) FROM events WHERE status = 'Published' AND event_date >= CURDATE()
                                    AND YEAR(event_date) = YEAR(CURDATE()) AND MONTH(event_date) = MONTH(CURDATE())")->fetchColumn();
$revenue        = (float)db()->query("SELECT COALESCE(SUM(total), 0) FROM bookings WHERE status = 'Paid'")->fetchColumn();

$recent = db()->query("SELECT b.id, b.reference, b.total, b.created_at, b.status, u.full_name
                       FROM bookings b JOIN users u ON u.id = b.user_id
                       ORDER BY b.created_at DESC LIMIT 5")->fetchAll();

admin_head('Dashboard');
admin_topbar($admin);
admin_sidebar('index');
?>
  <main class="content">
    <div class="page-head">
      <div>
        <h1>Dashboard</h1>
        <p class="lede">Welcome back, <?= e(strtok($admin['full_name'], ' ')) ?>! Here’s what’s happening</p>
      </div>
      <div class="date-card"><span>Date:</span><span id="todayDate"><?= date('j F Y') ?></span></div>
    </div>

    <section class="stats" aria-label="Summary">
      <article class="stat-card">
        <h2>Total Bookings</h2>
        <p class="stat-value"><?= $totalBookings ?></p>
        <p class="stat-note"><?= e(week_change('bookings', '1=1')) ?> · <?= money($revenue) ?> paid</p>
      </article>
      <article class="stat-card">
        <h2>Total Customers</h2>
        <p class="stat-value"><?= $totalCustomers ?></p>
        <p class="stat-note"><?= e(week_change('users', "role = 'customer'")) ?></p>
      </article>
      <article class="stat-card">
        <h2>Upcoming Events</h2>
        <p class="stat-value"><?= $upcoming ?></p>
        <p class="stat-note"><?= $thisMonth ?> this month</p>
      </article>
    </section>

    <div class="dash-lower">
      <section class="panel" aria-labelledby="recentTitle">
        <div class="panel-head">
          <h2 id="recentTitle">Recent Bookings</h2>
          <a class="panel-link" href="bookings.php">View all →</a>
        </div>
        <div class="table-scroll">
          <table class="data data--compact">
            <thead>
              <tr>
                <th scope="col" class="t-left">#</th>
                <th scope="col" class="t-left">Customer</th>
                <th scope="col">Amount (Rs)</th>
                <th scope="col">Date</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent as $b): ?>
              <tr data-row>
                <td class="t-left"><?= e($b['reference']) ?></td>
                <td class="t-left"><?= e($b['full_name']) ?></td>
                <td><?= number_format((float)$b['total']) ?></td>
                <td><?= nice_date($b['created_at'], 'd/m/y') ?></td>
                <td><?= e($b['status']) ?></td>
              </tr>
              <?php endforeach; ?>
              <tr class="empty-row" <?= $recent ? 'hidden' : '' ?>><td colspan="5">No bookings yet.</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <section class="panel" aria-labelledby="quickTitle">
        <div class="panel-head"><h2 id="quickTitle">Quick Action</h2></div>
        <div class="quick-list">
          <a class="quick-btn" href="attractions.php?add=1">Add Attraction</a>
          <a class="quick-btn" href="events.php?add=1">Create Event</a>
          <a class="quick-btn" href="tickets.php">Manage Tickets</a>
          <a class="quick-btn" href="customers.php">View Customer</a>
          <a class="quick-btn" href="../index.php" target="_blank" rel="noopener">View Website</a>
        </div>
      </section>
    </div>
  </main>
<?php admin_foot(); ?>
