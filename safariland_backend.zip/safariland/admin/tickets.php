<?php
/**
 * ADMIN - Manage Ticket Type (READ here; CREATE/UPDATE/DELETE via api/tickets.php).
 * Prices set here are the ones the customer is charged (payment.php reads them).
 */
require __DIR__ . '/../includes/admin_init.php';
require __DIR__ . '/../includes/admin_rows.php';

$rows = array_map('ticket_row', db()->query('SELECT * FROM ticket_types ORDER BY price')->fetchAll());

function desc_items(string $desc): string
{
    $html = '';
    foreach (array_filter(array_map('trim', explode("\n", $desc))) as $line) {
        $html .= '<li>' . e($line) . '</li>';
    }
    return $html;
}

admin_head('Manage Ticket Type');
admin_topbar($admin);
admin_sidebar('tickets');
?>
  <main class="content">
    <div class="page-head">
      <h1>Manage Ticket Type</h1>
      <button type="button" class="btn btn-mint js-add">+ Add Ticket Type</button>
    </div>

    <div class="table-card table-card--spaced">
      <div class="table-scroll">
        <table class="data">
          <thead>
            <tr>
              <th scope="col" class="t-left">Ticket Type</th>
              <th scope="col" class="t-left">Description</th>
              <th scope="col">Guests</th>
              <th scope="col">(Rs) Price</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="ticketRows">
<?php foreach ($rows as $r): ?>
        <tr data-row<?= data_attrs($r) ?>>
          <td class="t-left c-name"><?= e($r['name']) ?></td>
          <td class="t-left"><ul class="plain-list c-desc"><?= desc_items($r['description']) ?></ul></td>
          <td class="c-guests"><?= (int)$r['guests'] ?></td>
          <td class="c-price"><?= e($r['price']) ?></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
<?php endforeach; ?>
        <tr class="empty-row" hidden><td colspan="5">No ticket types match your search.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <template id="ticketRowTpl">
        <tr data-row data-id="" data-name="" data-price="" data-guests="" data-description="">
          <td class="t-left c-name"></td>
          <td class="t-left"><ul class="plain-list c-desc"></ul></td>
          <td class="c-guests"></td>
          <td class="c-price"></td>
          <td class="actions"><?= admin_row_actions() ?></td>
        </tr>
    </template>

    <!-- Add / Edit Ticket -->
<div class="modal-overlay" id="ticketModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="ticketModalTitle">
    <h2 id="ticketModalTitle">Add Ticket</h2>
    <form id="ticketForm" novalidate>
      <input type="hidden" name="id">
      <div class="form-grid">
        <div class="field">
          <label for="tkName">Ticket Type</label>
          <input id="tkName" type="text" name="name" required minlength="2" maxlength="60">
        </div>
        <div class="field">
          <label for="tkPrice">Price (Rs)</label>
          <input id="tkPrice" type="number" name="price" required min="1" max="100000" step="0.01">
        </div>
        <div class="field">
          <label for="tkDescription">Description (one item per line)</label>
          <textarea id="tkDescription" name="description" rows="3" required maxlength="1000"></textarea>
        </div>
        <div class="field">
          <label for="tkGuests">Included Guest</label>
          <input id="tkGuests" type="number" name="guests" required min="1" max="20" step="1">
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline js-close">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<?php admin_delete_modal('deleteTicketModal', 'Ticket'); ?>

  </main>
<?php admin_foot(['tickets.js']); ?>
